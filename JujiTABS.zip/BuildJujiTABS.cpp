#include <windows.h>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

namespace fs = std::filesystem;

static int run(const std::string& command) {
    std::cout << "\n> " << command << "\n";
    int rc = std::system(command.c_str());
    return rc;
}

static bool exists(const fs::path& p) {
    return fs::exists(p);
}

int main() {
    try {
        fs::path root = fs::current_path();

        std::cout << "==========================================\n";
        std::cout << "       JujiTABS C++ BUILD WRAPPER\n";
        std::cout << "==========================================\n\n";

        const fs::path bat = root / "build-all.bat";
        const fs::path pluginProject = root / "JujiTABS.csproj";
        const fs::path launcherProject = root / "JujiTABSLauncher.csproj";
        const fs::path src = root / "src";
        const fs::path lib = root / "lib";

        if (!exists(bat) || !exists(pluginProject) || !exists(launcherProject) ||
            !exists(src) || !exists(lib)) {
            std::cerr << "[ERROR] Project structure is incomplete.\n";
            std::cerr << "Expected:\n";
            std::cerr << "  JujiTABS.csproj\n";
            std::cerr << "  JujiTABSLauncher.csproj\n";
            std::cerr << "  build-all.bat\n";
            std::cerr << "  src\\\n";
            std::cerr << "  lib\\\n";
            return 10;
        }

        // Make sure the BAT runs relative to this project directory.
        std::string command = "cmd.exe /c \"\""
                            + bat.string()
                            + "\"\"";

        int rc = run(command);
        if (rc != 0) {
            std::cerr << "\n[ERROR] Build script returned code " << rc << ".\n";
            return rc;
        }

        fs::path exe = root / "release" / "JujiTABS.exe";

        if (!exists(exe)) {
            std::cerr << "[ERROR] JujiTABS.exe was not created.\n";
            return 20;
        }

        std::cout << "\n==========================================\n";
        std::cout << "             SUCCESS\n";
        std::cout << "==========================================\n";
        std::cout << "EXE: " << exe.string() << "\n";

        // Open the release folder.
        std::string openCmd = "explorer.exe /select,\"" + exe.string() + "\"";
        std::system(openCmd.c_str());

        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "[FATAL] " << e.what() << "\n";
        return 99;
    }
}
