// ============================================================
//  GuiManager.cs  –  JujiTABS  Custom GUI  v2.11.0
//  Hell-Pink / Frost / Black / Cyan / Toxic / Rainbow / Custom
// ============================================================
using System;
using UnityEngine;

namespace JujiTABS
{
    internal static class GuiManager
    {
        // ─── THEMES ──────────────────────────────────────────────────────────────
        public struct Theme
        {
            public string Name;
            public Color  BgDeep, BgPanel;
            public Color  Accent, AccentMid, AccentGlow;
            public Color  TxtMain, TxtDim, Red;
        }

        static readonly Theme[] _themes = new Theme[]
        {
            new Theme { // 0 – Hell Pink
                Name = "Hell Pink",
                BgDeep    = C(46,12,28,245), BgPanel   = C(28,8,20,238),
                Accent    = C(255,140,195,255), AccentMid = C(180,55,120,255), AccentGlow = C(255,90,165,255),
                TxtMain   = C(255,242,248,255), TxtDim    = C(205,150,180,255), Red = C(255,60,35,255),
            },
            new Theme { // 1 – Frost
                Name = "Frost",
                BgDeep    = C(16,22,30,245), BgPanel   = C(7,15,38,238),
                Accent    = C(190,225,255,255), AccentMid = C(70,125,175,255), AccentGlow = C(110,235,255,255),
                TxtMain   = C(235,250,255,255), TxtDim    = C(150,190,220,255), Red = C(255,60,35,255),
            },
            new Theme { // 2 – Black
                Name = "Black",
                BgDeep    = C(8,8,10,248), BgPanel   = C(26,26,28,238),
                Accent    = C(225,225,235,255), AccentMid = C(100,100,110,255), AccentGlow = C(255,255,255,255),
                TxtMain   = C(242,242,242,255), TxtDim    = C(145,145,150,255), Red = C(255,60,35,255),
            },
            new Theme { // 3 – Cyan
                Name = "Cyan",
                BgDeep    = C(5,16,22,245), BgPanel   = C(7,25,38,238),
                Accent    = C(90,225,255,255), AccentMid = C(20,120,155,255), AccentGlow = C(130,245,255,255),
                TxtMain   = C(225,250,255,255), TxtDim    = C(125,190,215,255), Red = C(255,60,35,255),
            },
            new Theme { // 4 – Toxic
                Name = "Toxic",
                BgDeep    = C(8,22,10,248), BgPanel   = C(8,34,14,240),
                Accent    = C(105,255,90,255), AccentMid = C(35,150,45,255), AccentGlow = C(160,255,115,255),
                TxtMain   = C(235,255,235,255), TxtDim    = C(150,205,150,255), Red = C(255,70,35,255),
            },
            new Theme { // 5 – Rainbow
                Name = "Rainbow",
                BgDeep    = C(28,10,34,248), BgPanel   = C(20,12,30,240),
                Accent    = C(255,90,210,255), AccentMid = C(90,140,255,255), AccentGlow = C(90,255,220,255),
                TxtMain   = C(250,250,255,255), TxtDim    = C(180,185,215,255), Red = C(255,70,90,255),
            },
        };

        static Color C(int r, int g, int b, int a) => new Color(r/255f, g/255f, b/255f, a/255f);

        public static int   ThemeIdx = 0;
        static Theme T
        {
            get
            {
                if (Plugin.UseCustomGui || ThemeIdx == 6)
                {
                    return new Theme { Name = "Custom", BgDeep = Plugin.CustomGuiBg, BgPanel = Bl(Plugin.CustomGuiBg, Color.black, 0.35f),
                        Accent = Plugin.CustomGuiAccent, AccentMid = Bl(Plugin.CustomGuiAccent, Color.black, 0.45f), AccentGlow = Plugin.CustomGuiAccent,
                        TxtMain = Color.white, TxtDim = Bl(Color.white, Plugin.CustomGuiAccent, 0.55f), Red = new Color(1f,0.18f,0.12f,1f) };
                }
                if (ThemeIdx == 5)
                {
                    return new Theme { Name = "Rainbow", BgDeep = new Color(0.035f,0.015f,0.05f,0.98f), BgPanel = new Color(0.055f,0.025f,0.07f,0.96f),
                        Accent = new Color(1f,0.25f,0.75f,1f), AccentMid = new Color(0.35f,0.55f,1f,1f), AccentGlow = new Color(0.25f,1f,0.80f,1f),
                        TxtMain = Color.white, TxtDim = new Color(0.78f,0.78f,0.86f,1f), Red = new Color(1f,0.18f,0.18f,1f) };
                }
                return _themes[Mathf.Clamp(ThemeIdx, 0, _themes.Length - 1)];
            }
        }

        public static Color Accent  => T.Accent;
        public static Color TextDim => T.TxtDim;

        // ─── ANIMATION ───────────────────────────────────────────────────────────
        static float _alpha = 0f;
        public static float Alpha => _alpha;
        public static void Tick(bool open) =>
            _alpha = Mathf.Lerp(_alpha, open ? 1f : 0f, Time.unscaledDeltaTime * 16f);

        // ─── SKIN / TEXTUREN ──────────────────────────────────────────────────────
        static GUISkin   _skin;
        static int       _builtFor = -1;

        static Texture2D _txBg, _txPanel;
        static Texture2D _txBtnN, _txBtnH, _txBtnA;
        static Texture2D _txTabA;
        static Texture2D _txTogN, _txTogA;
        static Texture2D _txSliderBg, _txSliderKnob;
        static Texture2D _txScrollThumb;
        static GUIStyle  _styleTabActive;

        static void EnsureBuilt()
        {
            int key = ThemeIdx + (Plugin.UseCustomGui ? 100 : 0) + Plugin.CustomGuiRevision * 1000;
            if (_skin != null && _builtFor == key) return;
            _builtFor = key;
            BuildTex();
            BuildSkin();
        }

        static void BuildTex()
        {
            var t = T;
            Kill(ref _txBg);          _txBg          = S(t.BgDeep);
            Kill(ref _txPanel);       _txPanel        = S(Bl(t.BgPanel, t.BgDeep, 0.35f));
            Kill(ref _txBtnN);        _txBtnN         = S(Bl(t.BgPanel, t.BgDeep, 0.5f));
            Kill(ref _txBtnH);        _txBtnH         = S(Bl(t.AccentMid, t.BgPanel, 0.5f));
            Kill(ref _txBtnA);        _txBtnA         = S(t.AccentMid);
            Kill(ref _txTabA);        _txTabA         = S(Bl(t.Accent, t.BgDeep, 0.20f));
            Kill(ref _txTogN);        _txTogN         = S(Bl(t.BgPanel, t.BgDeep, 0.65f));
            Kill(ref _txTogA);        _txTogA         = S(Bl(t.AccentMid, t.BgDeep, 0.55f));
            Kill(ref _txSliderBg);    _txSliderBg     = S(t.BgPanel);
            Kill(ref _txSliderKnob);  _txSliderKnob   = S(t.Accent);
            Kill(ref _txScrollThumb); _txScrollThumb  = S(t.AccentMid);
        }

        static void BuildSkin()
        {
            if (_skin == null) _skin = ScriptableObject.CreateInstance<GUISkin>();
            var t = T;

            // Window
            _skin.window.normal.background   = _txBg;
            _skin.window.onNormal.background = _txBg;
            _skin.window.border  = new RectOffset(4, 4, 4, 4);
            _skin.window.padding = new RectOffset(0, 0, 0, 6);

            // Label
            LabelStyle(_skin.label, t.TxtMain, 12);

            // Button
            BtnStyle(_skin.button, _txBtnN, _txBtnH, _txBtnA,
                     t.TxtMain, t.AccentGlow, t.BgDeep, 12);
            _skin.button.padding = new RectOffset(10, 10, 5, 5);
            _skin.button.margin  = new RectOffset(2, 2, 2, 2);
            _skin.button.border  = new RectOffset(2, 2, 2, 2);

            // Toggle
            _skin.toggle.normal.background   = _txTogN;
            _skin.toggle.onNormal.background = _txTogA;
            _skin.toggle.hover.background    = _txBtnH;
            _skin.toggle.onHover.background  = _txTabA;
            _skin.toggle.normal.textColor    = t.TxtDim;
            _skin.toggle.onNormal.textColor  = t.TxtMain;
            _skin.toggle.hover.textColor     = t.AccentGlow;
            _skin.toggle.onHover.textColor   = t.AccentGlow;
            _skin.toggle.fontSize = 12;
            _skin.toggle.padding  = new RectOffset(8, 8, 5, 5);
            _skin.toggle.margin   = new RectOffset(2, 2, 2, 2);
            _skin.toggle.border   = new RectOffset(2, 2, 2, 2);

            // Box (für Section-Header-BG)
            _skin.box.normal.background = _txPanel;
            _skin.box.normal.textColor  = t.Accent;
            _skin.box.fontSize = 11;
            _skin.box.padding  = new RectOffset(6, 6, 3, 3);
            _skin.box.border   = new RectOffset(2, 2, 2, 2);

            // Slider
            _skin.horizontalSlider.normal.background        = _txSliderBg;
            _skin.horizontalSlider.fixedHeight              = 6f;
            _skin.horizontalSlider.border                   = new RectOffset(2, 2, 2, 2);
            _skin.horizontalSliderThumb.normal.background   = _txSliderKnob;
            _skin.horizontalSliderThumb.fixedWidth          = 14f;
            _skin.horizontalSliderThumb.fixedHeight         = 14f;
            _skin.horizontalSliderThumb.border              = new RectOffset(4, 4, 4, 4);

            // Scrollbar
            _skin.verticalScrollbar.normal.background       = _txPanel;
            _skin.verticalScrollbar.fixedWidth              = 6f;
            _skin.verticalScrollbarThumb.normal.background  = _txScrollThumb;

            // Active-Tab Style (gecacht)
            _styleTabActive = new GUIStyle(_skin.button);
            _styleTabActive.normal.background  = _txTabA;
            _styleTabActive.normal.textColor   = T.AccentGlow;
            _styleTabActive.hover.background   = _txTabA;
            _styleTabActive.hover.textColor    = T.AccentGlow;
            _styleTabActive.active.background  = _txBtnA;
            _styleTabActive.active.textColor   = T.BgDeep;
        }

        static void LabelStyle(GUIStyle s, Color c, int sz)
        {
            s.normal.textColor = c; s.fontSize = sz;
            s.padding = new RectOffset(4, 4, 2, 2);
        }

        static void BtnStyle(GUIStyle s, Texture2D n, Texture2D h, Texture2D a,
                              Color cn, Color ch, Color ca, int sz)
        {
            s.normal.background  = n; s.normal.textColor  = cn;
            s.hover.background   = h; s.hover.textColor   = ch;
            s.active.background  = a; s.active.textColor  = ca;
            s.fontSize = sz;
        }

        // ─── ÖFFENTLICHE DRAW-HELPERS ─────────────────────────────────────────────

        public static bool Toggle(bool v, string label)
        {
            EnsureBuilt();
            Color p = GUI.color; GUI.color = Color.white;
            bool n = GUILayout.Toggle(v, (v ? "  ✦  " : "  ○  ") + label, _skin.toggle);
            GUI.color = p; return n;
        }

        public static bool Button(string label, bool danger = false, float w = -1)
        {
            EnsureBuilt();
            Color p = GUI.color; GUI.color = danger ? T.Red : Color.white;
            GUILayoutOption[] opt = w > 0
                ? new[] { GUILayout.Width(w) }
                : new[] { GUILayout.ExpandWidth(true) };
            bool hit = GUILayout.Button(label, _skin.button, opt);
            GUI.color = p; return hit;
        }

        public static float Slider(float v, float min, float max, string label, string fmt = "0.0")
        {
            EnsureBuilt();
            Color p = GUI.color;
            GUI.color = T.TxtDim;
            GUILayout.Label("  " + label + "   " + v.ToString(fmt), _skin.label);
            GUI.color = T.Accent;
            float n = GUILayout.HorizontalSlider(v, min, max, _skin.horizontalSlider, _skin.horizontalSliderThumb);
            GUI.color = p; return n;
        }

        public static int SliderInt(int v, int min, int max, string label) =>
            Mathf.RoundToInt(Slider(v, min, max, label, "0"));

        public static void Header(string title)
        {
            EnsureBuilt();
            GUILayout.Space(7);
            Color p = GUI.color;
            GUI.color = T.Accent;
            GUILayout.Label("  ▸  " + title, _skin.label);
            GUI.color = new Color(T.AccentMid.r, T.AccentMid.g, T.AccentMid.b, 0.75f);
            GUILayout.Box("", GUILayout.Height(1), GUILayout.ExpandWidth(true));
            GUI.color = p;
            GUILayout.Space(2);
        }

        public static void Info(string text)
        {
            EnsureBuilt();
            Color p = GUI.color; GUI.color = T.TxtDim;
            GUILayout.Label("  " + text, _skin.label);
            GUI.color = p;
        }

        public static void Divider()
        {
            EnsureBuilt();
            Color p = GUI.color;
            GUI.color = new Color(T.AccentMid.r, T.AccentMid.g, T.AccentMid.b, 0.5f);
            GUILayout.Box("", GUILayout.Height(1), GUILayout.ExpandWidth(true));
            GUI.color = p;
        }

        public static void Row(Action content) { GUILayout.BeginHorizontal(); content(); GUILayout.EndHorizontal(); }

        // ─── THEME-SELECTOR ───────────────────────────────────────────────────────

        public static void DrawThemeSelector()
        {
            EnsureBuilt();
            Header("Theme");
            GUILayout.BeginHorizontal();
            for (int i = 0; i < _themes.Length; i++)
            {
                Color p = GUI.color;
                GUI.color = i == ThemeIdx ? T.AccentGlow : T.TxtDim;
                if (GUILayout.Button(_themes[i].Name, _skin.button, GUILayout.ExpandWidth(true)))
                { ThemeIdx = i; _builtFor = -1; }
                GUI.color = p;
            }
            GUILayout.EndHorizontal();

            // Farbpunkte
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            for (int i = 0; i < _themes.Length; i++)
            {
                Color p = GUI.color;
                GUI.color = _themes[i].Accent;
                if (GUILayout.Button(i == ThemeIdx ? "✦" : "●", _skin.button,
                                     GUILayout.Width(32), GUILayout.Height(26)))
                { ThemeIdx = i; _builtFor = -1; }
                GUI.color = p;
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            Info("Aktiv: " + T.Name);
        }

        // ─── HAUPT-FENSTER-FRAME ──────────────────────────────────────────────────

        static readonly string[] _tabNames = { "Combat","Budget","Online","World","Aim","RAGE","Style" };

        /// <summary>
        /// Haupt-Fenster-Callback. Wird als GUI.Window-Delegate aufgerufen.
        /// Plugin muss CloseMenu via WantsClose prüfen.
        /// </summary>
        public static bool WantsClose;

        public static void DrawFrame(int id, ref int tab, ref Vector2 scroll,
                                     string status, Action<int> content)
        {
            EnsureBuilt();
            var prevSkin  = GUI.skin;
            var prevColor = GUI.color;
            GUI.skin = _skin;

            // ── Titelleiste ──────────────────────────────────────────────────────
            Color p = GUI.color;
            GUI.color = new Color(T.Accent.r, T.Accent.g, T.Accent.b, 0.22f);
            GUILayout.BeginHorizontal(_skin.box, GUILayout.Height(28));
            GUI.color = T.AccentGlow;
            GUILayout.Label("  ✦  JujiTABS  v2.11.0", _skin.label, GUILayout.ExpandWidth(true));

            // Theme-Dots in der Titelleiste
            for (int i = 0; i < _themes.Length; i++)
            {
                GUI.color = _themes[i].Accent;
                if (GUILayout.Button(i == ThemeIdx ? "✦" : "●", _skin.button,
                                     GUILayout.Width(22), GUILayout.Height(22)))
                { ThemeIdx = i; _builtFor = -1; }
            }
            GUILayout.Space(4);
            GUI.color = T.Red;
            if (GUILayout.Button("✕", _skin.button, GUILayout.Width(26), GUILayout.Height(26)))
                WantsClose = true;
            GUILayout.EndHorizontal();

            // ── Tab-Leiste ───────────────────────────────────────────────────────
            GUI.color = Color.white;
            GUILayout.BeginHorizontal();
            for (int i = 0; i < _tabNames.Length; i++)
            {
                bool active = i == tab;
                GUI.color = active ? T.AccentGlow : T.TxtDim;
                GUIStyle st = active ? _styleTabActive : _skin.button;
                if (GUILayout.Button(_tabNames[i], st, GUILayout.ExpandWidth(true), GUILayout.Height(22)))
                    tab = i;
            }
            GUILayout.EndHorizontal();

            // Akzent-Trennlinie unter Tabs
            GUI.color = new Color(T.AccentMid.r, T.AccentMid.g, T.AccentMid.b, 0.85f);
            GUILayout.Box("", GUILayout.Height(1), GUILayout.ExpandWidth(true));

            // ── Inhaltsbereich ───────────────────────────────────────────────────
            GUI.color = Color.white;
            scroll = GUILayout.BeginScrollView(scroll, false, false,
                GUIStyle.none, _skin.verticalScrollbar,
                GUILayout.ExpandHeight(true), GUILayout.MaxHeight(440));
            GUILayout.Space(4);
            content(tab);
            GUILayout.Space(8);
            GUILayout.EndScrollView();

            // ── Statusleiste ─────────────────────────────────────────────────────
            GUI.color = new Color(T.AccentMid.r, T.AccentMid.g, T.AccentMid.b, 0.5f);
            GUILayout.Box("", GUILayout.Height(1), GUILayout.ExpandWidth(true));
            GUI.color = T.TxtDim;
            GUILayout.Label("  " + status, _skin.label, GUILayout.Height(16));

            GUI.color = prevColor;
            GUI.skin  = prevSkin;

            GUI.DragWindow(new Rect(0, 0, 10000, 28));
        }

        public static GUIStyle WindowStyle()
        {
            EnsureBuilt();
            return _skin.window;
        }

        // ─── TEXTURE-HILFSMETHODEN ────────────────────────────────────────────────
        static Texture2D S(Color c)
        {
            var tx = new Texture2D(4, 4, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
            var px = new Color[16]; for (int i = 0; i < 16; i++) px[i] = c;
            tx.SetPixels(px); tx.Apply(); return tx;
        }
        static Color Bl(Color a, Color b, float t) =>
            new Color(a.r+(b.r-a.r)*t, a.g+(b.g-a.g)*t, a.b+(b.b-a.b)*t, a.a+(b.a-a.a)*t);
        static void Kill(ref Texture2D tx)
        { if (tx != null) { UnityEngine.Object.Destroy(tx); tx = null; } }
    }
}
