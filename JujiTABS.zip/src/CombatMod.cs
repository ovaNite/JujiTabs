using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace JujiTABS
{
    internal static class CombatMod
    {
        public static string Status = "";

        public static bool EspEnabled = false;
        public static int EspMode = 1;
        public static Color EspEnemy = new Color(1f, 0.25f, 0.15f, 1f);
        public static Color EspAlly  = new Color(0.2f, 0.85f, 1f, 1f);
        public static float EspBox   = 1f;
        public static bool EspName   = true;
        public static bool EspLine   = false;
        public static bool EspHealth = true;

        public static bool  Aimbot           = false;
        public static float AimbotSmooth     = 0.20f;
        public static float AimbotPredict    = 1f;
        public static float AimbotRange      = 80f;
        static bool _inPlacement;
        static bool _battleSeen;
        public static void SetPlacementState(bool inPlacement) { _inPlacement = inPlacement; }
        public static bool IsCombatActive() => _battleSeen && !_inPlacement;
        public static bool  AimbotAutoWeapon = true;

        public static bool PlaceEverywhere = false;

        class Tracked
        {
            public Component unit;
            public Transform  tr;
            public Rigidbody  hip;
            public bool       enemy;
            public string     name;
            public float      hp, maxHp, nextHp;
        }

        static readonly List<Tracked> _list = new List<Tracked>(32);
        static bool _espDirty = true;
        static Type[] _typesCache;

        static Type[] TypesCache()
        {
            if (_typesCache != null) return _typesCache;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (a.GetName().Name != "Assembly-CSharp") continue;
                try { _typesCache = a.GetTypes(); }
                catch (ReflectionTypeLoadException ex) { _typesCache = ex.Types; }
                catch { _typesCache = new Type[0]; }
                break;
            }
            return _typesCache ?? new Type[0];
        }

        static Type           _unitType;
        static Type           _hhType;
        static FieldInfo      _dataField;
        static PropertyInfo   _isPossessedProp;
        static bool           _refl;

        static readonly Dictionary<Type, List<FieldInfo>> _cdCache = new Dictionary<Type, List<FieldInfo>>();

        public static void ClearBattleState()
        {
            try
            {
                _list.Clear();
                _rageBodies.Clear();
                _originalScale.Clear();
                _gigaScaled.Clear();
                _battleSeen = false;
                _inPlacement = false;
                Status = "cleared";
            }
            catch { }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  PATCH
        // ═══════════════════════════════════════════════════════════════════════

        public static int Patch(Harmony h)
        {
            int n = 0;
            n += PType(h, "Landfall.TABS.Unit", "Start", nameof(PostStart), true);
            n += PType(h, "Unit",                "Start", nameof(PostStart), true);
            n += PName(h, "IsPlacementCursorStateValid", nameof(PostPlace),  true);
            n += PName(h, "InvalidPlacement",            nameof(PreInvalid), false);
            n += PatchAimMethods(h);
            n += PatchCooldownMethods(h);
            return n;
        }

        static int PatchAimMethods(Harmony h)
        {
            int n = 0;
            foreach (var name in new[] {
                "GetAimDirection","GetTargetDirection","CalculateAimDirection",
                "GetFireDirection","GetShootDirection","GetMuzzleDirection",
                "GetBulletDirection","GetProjectileDirection","GetLaunchDirection",
                "GetTargetPosition","GetAimPosition","GetShootTarget",
                "GetTarget","GetTargetPoint","GetAimPoint","AimAt","GetAimPos"
            }) n += PNameVector3(h, name, nameof(OverrideAimVector3));

            foreach (var name in new[] {
                "GetAimTarget","GetTarget","GetEnemyTarget","GetClosestEnemy",
                "FindTarget","SelectTarget","GetEnemy","GetNearestEnemy"
            }) n += PNameTransform(h, name, nameof(OverrideAimTransform));

            foreach (var name in new[] {
                "Shoot","Fire","LaunchProjectile","SpawnProjectile",
                "InstantiateProjectile","ShootWeapon","FireWeapon",
                "TriggerAttack","Attack","PerformAttack","DoAttack",
                "ThrowProjectile","RangedAttack","RangedShot"
            }) n += PName(h, name, nameof(PostShoot), true);

          return n;
     }

        static int PatchCooldownMethods(Harmony h)
     {
         int n = 0;

         foreach (var name in new[]
         {
             "GetCooldown",
             "GetAttackCooldown",
             "GetReloadTime",
             "GetFireRate",
             "GetCooldownTime",
             "GetAttackCooldownTime",
             "GetAbilityCooldown",
             "GetWeaponCooldown",
             "GetNextFireTime"
         })
         {
             n += PNameFloat(h, name, nameof(SetCooldownZero));
             n += PNameInt(h, name, nameof(SetCooldownZeroInt));
         }

         foreach (var name in new[]
         {
             "SetAttackCooldown",
             "SetCooldown",
             "SetReloadTime",
             "SetWaitTime",
             "SetNextFireTime",
             "SetCooldownTime",
             "SetFireRate"
         })
         {
             n += PNameSetFloat(h, name, nameof(PreSetCooldown));
         }

         return n;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  HARMONY HOOK IMPLEMENTIERUNGEN (EVENTBASIERT)
        // ═══════════════════════════════════════════════════════════════════════

        static void PostStart(object __instance)
        {
            var c = __instance as Component;
            if (c == null) return;
            _battleSeen = true;
            try { Actions.RegisterUnit(c); } catch { }
            try { RegisterRageUnit(c); } catch { }
            _espDirty = true;
            // LIGHT buffs only (no hierarchy scan) so Rapid/Speed/God work without APPLY button
            try { ApplyUnitEffectsOnce(c); } catch { }
            try { ApplyRageToUnit(c); } catch { }
        }

        /// <summary>Event: apply combat effects to one unit (call from UI toggle or after spawn batch).</summary>
        public static void ApplyUnitEffectsOnce(Component c)
        {
            if (c == null) return;
            int mine = Teams.MineCached();
            if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
            int team = Teams.OfUnit(c);
            if (team == mine)
            {
                ApplyBuffsTo(c);
                if (Plugin.GodMode || Plugin.SuperArmor) EnforceGodModeUnit(c);
                if (Plugin.RageJuggernaut) ApplyJuggernautToUnit(c);
                if (Plugin.RageGigaSize) ApplyGigaSizeToUnit(c);
            }
            else if (team >= 0)
            {
                if (Plugin.OneHit) EnforceOneHitUnit(c);
                if (Plugin.RageFreezeEnemies) FreezeUnit(c);
            }
        }

        /// <summary>Event: apply to all registered units once (UI button).</summary>
        public static void ApplyAllEffectsOnce()
        {
            foreach (var c in Actions.Units())
                try { ApplyUnitEffectsOnce(c); } catch { }
            Status = "effects applied";
        }

        static void PostPlace(ref bool __result)
        {
            if (Plugin.SafeOnline) return;
            if (PlaceEverywhere) __result = true;
        }

        static bool PreInvalid()
        {
            if (Plugin.SafeOnline) return true;
            return !PlaceEverywhere;
        }

        static void OverrideAimVector3(object __instance, ref Vector3 __result)
        {
            if (!Plugin.SilentAim || !IsCombatActive()) return;
            Component shooter = __instance as Component;
            if (shooter == null) return;
            int myTeam = Teams.MineCached();
            if (myTeam != 0 && myTeam != 1) myTeam = Plugin.LocalTeam;
            if (Teams.OfUnit(shooter) != myTeam) return;
            Component target = FindNearestEnemyToUnit(shooter);
            if (target == null) return;
            Vector3 head = target.transform.position + Vector3.up * 1.4f;
            __result = (head - shooter.transform.position).normalized;
        }

        static void OverrideAimTransform(object __instance, ref Transform __result)
        {
            if (!Plugin.SilentAim || !IsCombatActive()) return;
            Component shooter = __instance as Component;
            if (shooter == null) return;
            int myTeam = Teams.MineCached();
            if (myTeam != 0 && myTeam != 1) myTeam = Plugin.LocalTeam;
            if (Teams.OfUnit(shooter) != myTeam) return;
            Component target = FindNearestEnemyToUnit(shooter);
            if (target != null) __result = target.transform;
        }

        static void PostShoot(object __instance)
        {
            if (!IsCombatActive()) return;
            if (!Plugin.SilentAim && !Plugin.RapidFire && !Plugin.RageTornado && !Plugin.RageExplosiveTouch) return;
            Component shooter = __instance as Component;
            if (shooter == null) return;
            int myTeam = Teams.MineCached();
            if (myTeam != 0 && myTeam != 1) myTeam = Plugin.LocalTeam;
            if (Teams.OfUnit(shooter) != myTeam) return;

            if (Plugin.SilentAim)
            {
                Component target = FindNearestEnemyToUnit(shooter);
                if (target != null)
                    RedirectProjectilesNear(shooter.transform.position,
                                            target.transform.position + Vector3.up * 1.4f);
            }

            if (Plugin.RapidFire)
            {
                ZeroCooldownsDeep(shooter);
                ZeroRecoilDeep(shooter);
            }

            // Rage combat effects are event-driven: only the actual shot/attack invokes them.
            try { if (Plugin.RageTornado) TriggerTornadoEvent(); } catch { }
            try { if (Plugin.RageExplosiveTouch) TriggerExplosiveEvent(shooter); } catch { }
        }

        static void SetCooldownZero(object __instance, ref float __result)
        {
            if (!Plugin.RapidFire || !IsCombatActive()) return;
            if (!IsMyTeam(__instance)) return;
            __result = 0f;
        }

        static void SetCooldownZeroInt(object __instance, ref int __result)
        {
            if (!Plugin.RapidFire || !IsCombatActive()) return;
            if (!IsMyTeam(__instance)) return;
            __result = 0;
        }

        static bool PreSetCooldown(object __instance, ref float __0)
        {
            if (!Plugin.RapidFire || !IsCombatActive()) return true;
            if (!IsMyTeam(__instance)) return true;
            __0 = 0f;
            return true;
        }

        static readonly Dictionary<int, bool> _teamCache   = new Dictionary<int, bool>(64);
        static float                          _teamCacheTtl = 0f;

        static bool IsMyTeam(object inst)
        {
            Component c = inst as Component;
            if (c == null) return false;
            int mine = Teams.MineCached();
            if (mine != 0 && mine != 1) return false;

            float now = Time.unscaledTime;
            if (now > _teamCacheTtl) { _teamCache.Clear(); _teamCacheTtl = now + 2f; }

            int id = c.GetInstanceID();
            if (_teamCache.TryGetValue(id, out bool hit)) return hit;

            bool result = Teams.OfUnit(c) == mine;
            if (!result)
            {
                // Weapon components: walk up a few parents to find unit team
                try
                {
                    Transform t = c.transform;
                    for (int i = 0; i < 8 && t != null && !result; i++, t = t.parent)
                    {
                        foreach (var comp in t.GetComponents<Component>())
                        {
                            if (comp == null) continue;
                            if (Teams.OfUnit(comp) == mine) { result = true; break; }
                        }
                    }
                }
                catch { }
            }
            _teamCache[id] = result;
            return result;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  INPUT (NUR DIREKTE EINGABEN – KEINE PERIODISCHEN TICKS)
        // ═══════════════════════════════════════════════════════════════════════

        public static void OnInput()
        {
            bool ctrl = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
            if (Plugin.PossessTeleport && ctrl && !Plugin.IsMenuOpen && IsCombatActive() && Input.GetMouseButtonDown(0))
            {
                TeleportTeamToMouse();
                return;
            }

            // Aimbot runs only on an actual RMB press and only during battle.
            // No continuous aim loop is used.
            if (Aimbot && !ctrl && IsCombatActive() && Input.GetMouseButtonDown(1))
            {
                if (_list.Count == 0) { _espDirty = true; Scan(); }
                RunAimbot();
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  GODMODE / ONEHIT / BUFFS (werden bei Spawn und Events angewendet)
        // ═══════════════════════════════════════════════════════════════════════

        static void EnforceGodModeUnit(Component u)
        {
            if (u == null) return;
            if (_hhType == null) _hhType = AccessTools.TypeByName("HealthHandler");
            if (_hhType == null) return;
            try
            {
                var hh = u.GetComponent(_hhType) ?? u.GetComponentInChildren(_hhType, true);
                if (hh == null) return;

                var invF = AccessTools.Field(hh.GetType(), "isInvulnerable");
                if (invF != null && invF.FieldType == typeof(bool)) invF.SetValue(hh, true);
                try { AccessTools.Method(hh.GetType(), "SetInvulnerable", new[] { typeof(bool) })
                          ?.Invoke(hh, new object[] { true }); } catch { }

                object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? (object)hh;
                if (data != null)
                {
                    float max = 1000f;
                    foreach (var n in new[] { "maxHealth","MaxHealth","maxHP","m_maxHealth" })
                    {
                        var f = AccessTools.Field(data.GetType(), n);
                        if (f == null) continue;
                        if (f.FieldType == typeof(float)) { max = (float)f.GetValue(data); break; }
                        if (f.FieldType == typeof(int))   { max = (int)  f.GetValue(data); break; }
                    }
                    if (max < 1f) max = 1000f;
                    foreach (var n in new[] { "health","Health","currentHealth","m_health" })
                    {
                        var f = AccessTools.Field(data.GetType(), n);
                        if (f != null && f.FieldType == typeof(float)) f.SetValue(data, max);
                        else if (f != null && f.FieldType == typeof(int)) f.SetValue(data, (int)max);
                    }
                    var dead = AccessTools.Field(data.GetType(), "dead");
                    if (dead != null && dead.FieldType == typeof(bool)) dead.SetValue(data, false);
                }
                if (Plugin.SuperArmor)
                    foreach (var an in new[] { "armor","Armor","defence","Defense","resistance","damageReduction","armorPoints" })
                        SetF(u, an, 9999f);
            }
            catch { }
        }

        static void EnforceOneHitUnit(Component u)
        {
            if (u == null) return;
            if (_hhType == null) _hhType = AccessTools.TypeByName("HealthHandler");
            if (_hhType == null) return;
            try
            {
                var hh = u.GetComponent(_hhType) ?? u.GetComponentInChildren(_hhType, true);
                if (hh == null) return;
                object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? (object)hh;
                if (data == null) return;

                foreach (var n in new[] { "health","Health","currentHealth","m_health" })
                {
                    var f = AccessTools.Field(data.GetType(), n);
                    if (f == null) continue;
                    if (f.FieldType == typeof(float))
                    {
                        float hp = (float)f.GetValue(data);
                        if (hp > 1f) f.SetValue(data, 1f);
                        break;
                    }
                    if (f.FieldType == typeof(int))
                    {
                        int hp = (int)f.GetValue(data);
                        if (hp > 1) f.SetValue(data, 1);
                        break;
                    }
                }
            }
            catch { }
        }

        // ── Buffs auf eine einzelne Unit anwenden ─────────────────────────────
        static void ApplyBuffsTo(Component u)
        {
            if (u == null) return;
            int id = u.GetInstanceID();
            var st = GetRageState(u);
            var targets = st != null ? st.components : null;

            if (Plugin.PossessSpeed && Plugin.PossessSpeedMult > 1.01f)
            {
                float sm = Plugin.PossessSpeedMult;
                SetF(u, "moveSpeed", sm); SetF(u, "speed", sm); SetF(u, "m_speed", sm);
                SetF(u, "movementSpeed", sm); SetF(u, "unitSpeed", sm); SetF(u, "speedMultiplier", sm);
                SetF(u, "moveMultiplier", sm); SetF(u, "forceMultiplier", sm);
                if (targets != null)
                    foreach (var c in targets) if (c != null)
                    {
                        SetF(c, "moveSpeed", sm); SetF(c, "movementSpeed", sm); SetF(c, "unitSpeed", sm);
                        SetF(c, "speed", sm); SetF(c, "speedMultiplier", sm); SetF(c, "moveMultiplier", sm);
                    }
            }

            if (Plugin.RapidFire)
            {
                foreach (var n in _cdFieldNames) SetF(u, n, 0f);
                SetF(u, "fireRate", 0f);
                foreach (var n in _recoilFields) SetF(u, n, 0f);
                if (targets != null)
                    foreach (var c in targets) if (c != null)
                    {
                        foreach (var n in _cdFieldNames) SetF(c, n, 0f);
                        SetF(c, "fireRate", 0f);
                        foreach (var n in _recoilFields) SetF(c, n, 0f);
                    }
            }
            else if (Plugin.PossessAtkSpeed && Plugin.PossessAtkMult > 1.01f)
            {
                float am = Plugin.PossessAtkMult;
                SetF(u, "attackSpeed", am); SetF(u, "fireRate", am); SetF(u, "attackSpeedMultiplier", am);
                SetF(u, "attackspeedMulti", am); SetF(u, "attackSpeedM", am);
                if (targets != null)
                    foreach (var c in targets) if (c != null)
                    {
                        SetF(c, "attackSpeed", am); SetF(c, "attackSpeedMultiplier", am);
                        SetF(c, "attackSpeedM", am); SetF(c, "fireRate", am);
                    }
            }
        }

        static void SetFDeep(Component u, float val, string[] names)
        {
            foreach (var n in names) SetF(u, n, val);
            var mbs = u.GetComponentsInChildren<MonoBehaviour>(true);
            foreach (var mb in mbs)
            {
                if (mb == null) continue;
                foreach (var n in names) SetF(mb, n, val);
            }
        }

        static readonly string[] _cdFieldNames = {
            "cooldown","fireCooldown","fireTimer",
            "m_inRangeAttackCooldown","secondsTilAttack",
            "attackCooldown","delayTimer","waitTime","nextFireTime","abilityCooldown",
            "m_maxInRangeAttackCooldown","reloadTime","timeBetweenMeleeBlocks",
            "m_interval","m_minInterval","internalCooldown","randomCooldown",
            "extraCDInMelee","extraRandomCooldown","startCooldown"
        };

        static void ZeroCooldownsDeep(Component u)
        {
            if (u == null) return;
            // LIGHT: unit root only (no children scan)
            foreach (var n in _cdFieldNames) SetF(u, n, 0f);
        }

        static readonly string[] _recoilFields = {
            "recoil","m_recoil","recoilForce","m_recoilForce","weaponRecoil",
            "kickback","m_kickback","spread","m_spread","bulletSpread",
            "aimRecoil","recoilStrength","recoilAmount","pushBackForce",
            "m_pushBackForce","randomSpread","recoilMultiplier"
        };

        static void ZeroRecoilDeep(Component u)
        {
            if (u == null) return;
            foreach (var n in _recoilFields) SetF(u, n, 0f);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  RAGE FEATURES – EVENTBASIERT, KEINE TICKS / KEINE TIMER
        // ═══════════════════════════════════════════════════════════════════════

        static readonly Dictionary<int, bool> _gigaScaled = new Dictionary<int, bool>();

        sealed class RageBodyState
        {
            public Rigidbody[] bodies;
            public Component[] components;
            public readonly Dictionary<Rigidbody, float> mass = new Dictionary<Rigidbody, float>();
            public readonly Dictionary<Rigidbody, float> drag = new Dictionary<Rigidbody, float>();
            public readonly Dictionary<Rigidbody, bool> gravity = new Dictionary<Rigidbody, bool>();
            public readonly Dictionary<Rigidbody, bool> kinematic = new Dictionary<Rigidbody, bool>();
            public readonly Dictionary<Rigidbody, RigidbodyConstraints> constraints = new Dictionary<Rigidbody, RigidbodyConstraints>();
        }

        static readonly Dictionary<int, RageBodyState> _rageBodies = new Dictionary<int, RageBodyState>(64);
        static readonly Dictionary<int, Vector3> _originalScale = new Dictionary<int, Vector3>(64);

        public static void RegisterRageUnit(Component c)
        {
            if (c == null) return;
            int id = c.GetInstanceID();
            if (_rageBodies.ContainsKey(id)) return;
            try
            {
                var bodies = c.GetComponentsInChildren<Rigidbody>(true);
                var components = c.GetComponentsInChildren<Component>(true);
                var state = new RageBodyState { bodies = bodies ?? new Rigidbody[0], components = components ?? new Component[0] };
                foreach (var rb in state.bodies)
                {
                    if (rb == null) continue;
                    state.mass[rb] = rb.mass;
                    state.drag[rb] = rb.drag;
                    state.gravity[rb] = rb.useGravity;
                    state.kinematic[rb] = rb.isKinematic;
                    state.constraints[rb] = rb.constraints;
                }
                _rageBodies[id] = state;
                if (!_originalScale.ContainsKey(id)) _originalScale[id] = c.transform.localScale;
            }
            catch { }
        }

        static RageBodyState GetRageState(Component u)
        {
            if (u == null) return null;
            RegisterRageUnit(u);
            _rageBodies.TryGetValue(u.GetInstanceID(), out var state);
            return state;
        }

        static int MyTeam()
        {
            int mine = Teams.MineCached();
            if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
            return (mine == 0 || mine == 1) ? mine : -1;
        }

        static bool IsEnemy(Component c, int mine)
        {
            if (c == null || mine < 0) return false;
            int t = Teams.OfUnit(c);
            return t == 0 || t == 1 ? t != mine : false;
        }

        /// <summary>
        /// Called only from real events: unit spawn, UI toggle/apply and combat events.
        /// No Update/FixedUpdate/Coroutine is used for Rage processing.
        /// </summary>
        public static void ApplyRageEffectsOnce()
        {
            int mine = MyTeam();
            if (mine < 0) return;
            foreach (var c in Actions.Units())
                ApplyRageToUnit(c, mine);
        }

        public static void ApplyRageToUnit(Component c, int mine = -1)
        {
            if (c == null) return;
            if (mine < 0) mine = MyTeam();
            if (mine < 0) return;
            RegisterRageUnit(c);
            int team = Teams.OfUnit(c);

            if (team == mine)
            {
                if (Plugin.RageJuggernaut) ApplyJuggernautToUnit(c); else RestoreJuggernaut(c);
                if (Plugin.RageGigaSize) ApplyGigaSizeToUnit(c); else RestoreGigaSize(c);
            }
            else if (team == 0 || team == 1)
            {
                if (Plugin.RageFreezeEnemies) FreezeUnit(c); else RestoreFreeze(c);
                if (Plugin.RageAntiGravity) AntiGravityUnit(c, true); else AntiGravityUnit(c, false);
            }
        }

        static void ApplyJuggernautToUnit(Component u)
        {
            var st = GetRageState(u);
            if (st == null) return;
            try
            {
                foreach (var rb in st.bodies)
                {
                    if (rb == null) continue;
                    rb.mass = 99999f;
                    rb.drag = 10f;
                }
            }
            catch { }
        }

        static void RestoreJuggernaut(Component u)
        {
            var st = GetRageState(u);
            if (st == null) return;
            try
            {
                foreach (var rb in st.bodies)
                {
                    if (rb == null) continue;
                    if (st.mass.TryGetValue(rb, out var m)) rb.mass = m;
                    if (st.drag.TryGetValue(rb, out var d)) rb.drag = d;
                }
            }
            catch { }
        }

        static void FreezeUnit(Component u)
        {
            var st = GetRageState(u);
            if (st == null) return;
            try
            {
                foreach (var rb in st.bodies)
                {
                    if (rb == null) continue;
                    rb.velocity = Vector3.zero;
                    rb.angularVelocity = Vector3.zero;
                    rb.isKinematic = true;
                }
            }
            catch { }
        }

        static void RestoreFreeze(Component u)
        {
            var st = GetRageState(u);
            if (st == null) return;
            try
            {
                foreach (var rb in st.bodies)
                {
                    if (rb == null) continue;
                    if (st.kinematic.TryGetValue(rb, out var k)) rb.isKinematic = k;
                    if (st.constraints.TryGetValue(rb, out var co)) rb.constraints = co;
                }
            }
            catch { }
        }

        static void ApplyGigaSizeToUnit(Component u)
        {
            if (u == null) return;
            int id = u.GetInstanceID();
            if (!_originalScale.ContainsKey(id)) _originalScale[id] = u.transform.localScale;
            if (_gigaScaled.ContainsKey(id)) return;
            try
            {
                // Keep the unit as one coherent rig: scale the root once, never every bone.
                u.transform.localScale = _originalScale[id] * Mathf.Clamp(Plugin.GigaSizeMultiplier, 1.25f, 4f);
                Physics.SyncTransforms();
                _gigaScaled[id] = true;
            }
            catch { }
        }

        static void RestoreGigaSize(Component u)
        {
            if (u == null) return;
            int id = u.GetInstanceID();
            if (!_originalScale.TryGetValue(id, out var scale)) return;
            try { u.transform.localScale = scale; } catch { }
            _gigaScaled.Remove(id);
        }

        static void AntiGravityUnit(Component u, bool on)
        {
            var st = GetRageState(u);
            if (st == null) return;
            try
            {
                foreach (var rb in st.bodies)
                {
                    if (rb == null) continue;
                    rb.useGravity = on ? false : st.gravity[rb];
                }
            }
            catch { }
        }

        /// <summary>Event-triggered tornado impulse. Called by combat events, never by a timer.</summary>
        public static void TriggerTornadoEvent()
        {
            if (!Plugin.RageTornado) return;
            int mine = MyTeam();
            if (mine < 0) return;
            foreach (var c in Actions.Units())
            {
                if (!IsEnemy(c, mine)) continue;
                var st = GetRageState(c);
                if (st == null) continue;
                try
                {
                    foreach (var rb in st.bodies)
                    {
                        if (rb == null || rb.isKinematic) continue;
                        Vector3 radial = Vector3.Cross(Vector3.up, rb.position - c.transform.position);
                        if (radial.sqrMagnitude < 0.001f) radial = Vector3.right;
                        rb.AddForce(radial.normalized * 900f + Vector3.up * 320f, ForceMode.Impulse);
                        rb.AddTorque(Vector3.up * 450f, ForceMode.Impulse);
                    }
                }
                catch { }
            }
        }

        /// <summary>Event-triggered explosive touch. Called by a real attack/shoot event.</summary>
        public static void TriggerExplosiveEvent(Component source = null)
        {
            if (!Plugin.RageExplosiveTouch) return;
            int mine = MyTeam();
            if (mine < 0) return;
            const float radius = 7f;
            const float radiusSq = radius * radius;

            if (source != null && Teams.OfUnit(source) == mine)
            {
                ExplodeAt(source.transform.position, mine, radiusSq, radius);
                return;
            }

            foreach (var ally in Actions.Units())
                if (ally != null && Teams.OfUnit(ally) == mine)
                    ExplodeAt(ally.transform.position, mine, radiusSq, radius);
        }

        static void ExplodeAt(Vector3 center, int mine, float radiusSq, float radius)
        {
            foreach (var enemy in Actions.Units())
            {
                if (!IsEnemy(enemy, mine)) continue;
                Vector3 delta = enemy.transform.position - center;
                float sqr = delta.sqrMagnitude;
                if (sqr > radiusSq) continue;
                var st = GetRageState(enemy);
                if (st == null) continue;
                try
                {
                    float scale = Mathf.Clamp01(1f - Mathf.Sqrt(sqr) / radius);
                    Vector3 impulse = (sqr > 0.001f ? delta.normalized : Vector3.up) * (420f * (0.35f + scale)) + Vector3.up * 220f;
                    foreach (var rb in st.bodies)
                        if (rb != null && !rb.isKinematic) rb.AddForce(impulse, ForceMode.Impulse);
                }
                catch { }
            }
        }

        public static void RageResetGigaSize()
        {
            foreach (var c in Actions.Units()) RestoreGigaSize(c);
            _gigaScaled.Clear();
        }

        public static string RageInstantKillAll()
        {
            Refl();
            if (_hhType == null) _hhType = AccessTools.TypeByName("HealthHandler");
            int mine = MyTeam();
            if (mine < 0) return "no team";
            int n = 0;
            foreach (var c in Actions.Units())
            {
                if (!IsEnemy(c, mine)) continue;
                try
                {
                    if (_hhType != null)
                    {
                        var hh = c.GetComponent(_hhType) ?? c.GetComponentInChildren(_hhType);
                        if (hh != null) { Teams.ForceDie(hh); n++; }
                    }
                }
                catch { }
            }
            return "killed " + n;
        }

        public static string RageUltraBomb()
        {
            int mine = MyTeam();
            if (mine < 0) return "no team";
            int n = 0;
            foreach (var c in Actions.Units())
            {
                if (!IsEnemy(c, mine)) continue;
                var st = GetRageState(c);
                if (st == null) continue;
                try
                {
                    foreach (var rb in st.bodies)
                    {
                        if (rb == null || rb.isKinematic) continue;
                        rb.AddForce(Vector3.up * 2200f + UnityEngine.Random.insideUnitSphere * 1500f, ForceMode.Impulse);
                        n++;
                    }
                }
                catch { }
            }
            return "bombed " + n + " rbs";
        }

        public static void RageToggleAntiGravity(bool on)
        {
            int mine = MyTeam();
            if (mine < 0) return;
            foreach (var c in Actions.Units())
            {
                if (!IsEnemy(c, mine)) continue;
                RegisterRageUnit(c);
                AntiGravityUnit(c, on);
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  TELEPORT, AIMBOT, PROJEKTIL-REDIRECT
        // ═══════════════════════════════════════════════════════════════════════

        static void TeleportTeamToMouse()
        {
            int myTeam = Teams.MineCached();
            if (myTeam != 0 && myTeam != 1) myTeam = Plugin.LocalTeam;
            if (myTeam != 0 && myTeam != 1) myTeam = 0;

            Camera cam = Camera.main;
            if (cam == null)
            {
                var cams = UnityEngine.Object.FindObjectsOfType<Camera>();
                if (cams != null && cams.Length > 0) cam = cams[0];
            }
            if (cam == null) return;

            Vector3 screen = Input.mousePosition;
            if (Cursor.lockState == CursorLockMode.Locked)
                screen = new Vector3(Screen.width * 0.5f, Screen.height * 0.5f, 0f);

            Ray ray = cam.ScreenPointToRay(screen);
            Vector3 dest;
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 20000f, ~0, QueryTriggerInteraction.Ignore))
                dest = hit.point + Vector3.up * 0.35f;
            else
                dest = ray.GetPoint(80f);

            var list = new List<Component>();
            foreach (var u in Actions.Units())
                if (u != null) list.Add(u);
            if (list.Count == 0)
            {
                Refl();
                if (_unitType != null)
                {
                    try
                    {
                        foreach (var o in UnityEngine.Object.FindObjectsOfType(_unitType))
                        {
                            var c = o as Component;
                            if (c != null) { list.Add(c); Actions.RegisterUnit(c); }
                        }
                    }
                    catch { }
                }
            }

            int n = 0;
            foreach (var unit in list)
            {
                if (unit == null) continue;
                int ut = Teams.OfUnit(unit);
                if (ut != myTeam) continue;
                try
                {
                    unit.transform.position = dest + UnityEngine.Random.insideUnitSphere * 0.35f;
                    foreach (var rb in unit.GetComponentsInChildren<Rigidbody>())
                    {
                        if (rb == null) continue;
                        rb.velocity = Vector3.zero;
                        rb.angularVelocity = Vector3.zero;
                    }
                    n++;
                }
                catch { }
            }
            Status = "TP " + n + " @ mouse";
        }

        static readonly Collider[] _projectileHits = new Collider[48];
        static void RedirectProjectilesNear(Vector3 origin, Vector3 targetHead)
        {
            int hitCount = 0;
            try { hitCount = Physics.OverlapSphereNonAlloc(origin, 45f, _projectileHits); } catch { }
            for (int i = 0; i < hitCount; i++)
            {
                var col = _projectileHits[i];
                _projectileHits[i] = null;
                if (col == null) continue;
                var rb = col.attachedRigidbody;
                if (rb == null || rb.isKinematic || rb.mass >= 8f) continue;
                float spd2 = rb.velocity.sqrMagnitude;
                if (spd2 < 9f) continue;
                Vector3 dir = (targetHead - rb.position).normalized;
                float spd = Mathf.Max(Mathf.Sqrt(spd2), 30f);
                rb.velocity = dir * spd;
                rb.angularVelocity = Vector3.zero;
                rb.useGravity = false;
            }
        }

        static void RunAimbot()
        {
            // Aimbot = CAMERA/Maus zum Feind-Kopf (nicht Silent)
            if (_list.Count == 0) Scan();
            Camera cam = Camera.main;
            if (cam == null) return;

            Vector3 eye = cam.transform.position;
            Component best = null;
            float bestD = AimbotRange * AimbotRange;
            Vector3 bestPos = Vector3.zero;
            Vector3 bestVel = Vector3.zero;

            for (int i = 0; i < _list.Count; i++)
            {
                var t = _list[i];
                if (!t.enemy || t.unit == null || t.tr == null) continue;
                Vector3 head = BodyCenter(t) + Vector3.up * 0.35f;
                float d = (head - eye).sqrMagnitude;
                if (d >= bestD) continue;
                bestD = d;
                best = t.unit;
                bestPos = head;
                bestVel = t.hip != null ? t.hip.velocity : Vector3.zero;
            }
            if (best == null) return;

            Vector3 predicted = PredictPosition(eye, bestPos, bestVel, 25f);
            Vector3 dir = predicted - eye;
            if (dir.sqrMagnitude < 0.01f) return;

            float smooth = Mathf.Clamp(AimbotSmooth, 0.05f, 1f);
            Quaternion targetRot = Quaternion.LookRotation(dir.normalized, Vector3.up);
            cam.transform.rotation = Quaternion.Slerp(cam.transform.rotation, targetRot, smooth);

            // Possessed unit / weapon also face target
            Component me = FindPossessed();
            if (me != null)
            {
                try
                {
                    me.transform.rotation = Quaternion.Slerp(me.transform.rotation, targetRot, smooth);
                }
                catch { }
            }
        }

        static readonly Dictionary<int, float> _wpnCache    = new Dictionary<int, float>(16);
        static float                            _wpnCacheTtl = 0f;

        static float GetWeaponSpeed(Component unit)
        {
            if (!AimbotAutoWeapon) return 25f;
            float now = Time.unscaledTime;
            if (now > _wpnCacheTtl) { _wpnCache.Clear(); _wpnCacheTtl = now + 3f; }
            int id = unit.GetInstanceID();
            if (_wpnCache.TryGetValue(id, out float cached)) return cached;
            float found = 0f;
            try
            {
                var mbs = unit.GetComponentsInChildren<MonoBehaviour>(true);
                foreach (var mb in mbs)
                {
                    if (mb == null || found > 0f) continue;
                    foreach (var fname in new[] {
                        "projectileSpeed","bulletSpeed","launchSpeed","muzzleVelocity",
                        "shotSpeed","throwSpeed","fireSpeed","launchForce",
                        "projectileForce","arrowSpeed","boltSpeed","projectileVelocity"
                    })
                    {
                        var f = AccessTools.Field(mb.GetType(), fname);
                        if (f == null || f.FieldType != typeof(float)) continue;
                        float v = (float)f.GetValue(mb);
                        if (v > 5f && v < 800f) { found = v; break; }
                    }
                }
            }
            catch { }
            float result = found > 0f ? found : 25f;
            _wpnCache[id] = result;
            return result;
        }

        static Vector3 PredictPosition(Vector3 from, Vector3 targetPos, Vector3 targetVel, float projSpeed)
        {
            if (projSpeed < 1f) projSpeed = 25f;
            float tof = Vector3.Distance(from, targetPos) / projSpeed;
            for (int i = 0; i < 4; i++)
            {
                Vector3 pred = targetPos + targetVel * (tof * AimbotPredict);
                tof = Vector3.Distance(from, pred) / projSpeed;
            }
            return targetPos + targetVel * (tof * AimbotPredict);
        }

        static Component FindNearestEnemyToUnit(Component unit)
        {
            if (_list.Count == 0) Scan();
            Vector3 pos = unit != null ? unit.transform.position : Vector3.zero;
            Component best = null;
            float bestD = float.MaxValue;
            foreach (var t in _list)
            {
                if (!t.enemy || t.unit == null) continue;
                float d = Vector3.Distance(pos, t.unit.transform.position);
                if (d < bestD) { bestD = d; best = t.unit; }
            }
            return best;
        }

        static Component FindPossessed()
        {
            Refl();
            if (_unitType == null) return null;
            foreach (var c in Actions.Units())
                if (c != null && IsPossessed(c)) return c;
            return null;
        }

        static bool IsPossessed(Component u)
        {
            try
            {
                if (_isPossessedProp != null && _isPossessedProp.GetValue(u, null) is bool b && b)
                    return true;
            }
            catch { }
            try
            {
                var f = AccessTools.Field(u.GetType(), "<IsPossessed>k__BackingField")
                        ?? AccessTools.Field(u.GetType(), "isPossessed");
                if (f != null && f.FieldType == typeof(bool) && (bool)f.GetValue(u)) return true;
            }
            catch { }
            return false;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  HILFSMETHODEN: PATCHER (unverändert)
        // ═══════════════════════════════════════════════════════════════════════

        static int PType(Harmony h, string type, string method, string hook, bool post)
        {
            var t = AccessTools.TypeByName(type);
            if (t == null) return 0;
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (m.Name != method) continue;
                try
                {
                    if (post) h.Patch(m, postfix: new HarmonyMethod(hi));
                    else      h.Patch(m, prefix:  new HarmonyMethod(hi));
                    n++;
                }
                catch { }
            }
            return n;
        }

        static int PName(Harmony h, string methodName, string hook, bool post)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName) continue;
                    try
                    {
                        if (post) h.Patch(m, postfix: new HarmonyMethod(hi));
                        else      h.Patch(m, prefix:  new HarmonyMethod(hi));
                        n++;
                    }
                    catch { }
                }
            }
            return n;
        }

        static int PNameVector3(Harmony h, string methodName, string hook)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName || m.ReturnType != typeof(Vector3)) continue;
                    try { h.Patch(m, postfix: new HarmonyMethod(hi)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int PNameTransform(Harmony h, string methodName, string hook)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName || m.ReturnType != typeof(Transform)) continue;
                    try { h.Patch(m, postfix: new HarmonyMethod(hi)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int PNameFloat(Harmony h, string methodName, string hook)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName || m.ReturnType != typeof(float)) continue;
                    try { h.Patch(m, postfix: new HarmonyMethod(hi)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int PNameInt(Harmony h, string methodName, string hook)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName || m.ReturnType != typeof(int)) continue;
                    try { h.Patch(m, postfix: new HarmonyMethod(hi)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int PNameSetFloat(Harmony h, string methodName, string hook)
        {
            int n = 0;
            var hi = typeof(CombatMod).GetMethod(hook, BindingFlags.Static | BindingFlags.NonPublic);
            if (hi == null) return 0;
            Type[] types = TypesCache();
            foreach (var t in types)
            {
                if (t == null) continue;
                MethodInfo[] ms;
                try { ms = t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in ms)
                {
                    if (m.Name != methodName) continue;
                    var pars = m.GetParameters();
                    if (pars.Length == 0) continue;
                    if (pars[0].ParameterType != typeof(float) && pars[0].ParameterType != typeof(int)) continue;
                    try { h.Patch(m, prefix: new HarmonyMethod(hi)); n++; }
                    catch { }
                }
            }
            return n;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  REFLECTION + ESP (unverändert)
        // ═══════════════════════════════════════════════════════════════════════

        static void Refl()
        {
            if (_refl) return;
            _unitType = AccessTools.TypeByName("Landfall.TABS.Unit") ?? AccessTools.TypeByName("Unit");
            _hhType   = AccessTools.TypeByName("HealthHandler");
            if (_unitType != null)
            {
                _dataField       = AccessTools.Field(_unitType,    "data");
                _isPossessedProp = AccessTools.Property(_unitType, "IsPossessed");
            }
            _refl = true;
        }

        static object GetData(Component u)
        {
            Refl();
            return _dataField != null ? _dataField.GetValue(u) : null;
        }

        static void SetF(object o, string n, float v)
        {
            if (o == null) return;
            var f = AccessTools.Field(o.GetType(), n);
            if (f != null && f.FieldType == typeof(float))
                try { f.SetValue(o, v); } catch { }
        }

        static void InvokeF(object o, string m, float v)
        {
            try
            {
                var mi = AccessTools.Method(o.GetType(), m, new[] { typeof(float) });
                if (mi != null) mi.Invoke(o, new object[] { v });
            }
            catch { }
        }

        public static void NotifyHealthEvent(object hh)
        {
            if (hh == null) return;
            try
            {
                Component unit = null;
                var f = AccessTools.Field(hh.GetType(), "unit");
                if (f != null) unit = f.GetValue(hh) as Component;
                if (unit == null) unit = FindUnitForComponent(hh as Component);
                if (unit == null) return;
                float hp, max; ReadHp(unit, out hp, out max);
                for (int i = 0; i < _list.Count; i++)
                    if (_list[i] != null && _list[i].unit == unit) { _list[i].hp = hp; _list[i].maxHp = max; break; }
            }
            catch { }
        }

        static Component FindUnitForComponent(Component c)
        {
            if (c == null) return null;
            Transform t = c.transform;
            for (int depth = 0; depth < 8 && t != null; depth++, t = t.parent)
            {
                foreach (var u in Actions.Units())
                    if (u != null && u.transform == t) return u;
            }
            return null;
        }

        public static void DrawEsp()
        {
            if (!EspEnabled || EspMode < 1) return;
            if (!IsBattleContext())
            {
                if (_list.Count > 0) _list.Clear();
                return;
            }
            if (_espDirty || _list.Count == 0)
            {
                _espDirty = false;
                Scan();
            }
            Camera cam = Camera.main;
            if (cam == null) return;
            for (int i = _list.Count - 1; i >= 0; i--)
            {
                var trk = _list[i];
                if (trk.unit == null || trk.tr == null)          { _list.RemoveAt(i); continue; }
                try { if (!trk.unit.gameObject.activeInHierarchy) { _list.RemoveAt(i); continue; } }
                catch                                             { _list.RemoveAt(i); continue; }

                if (EspMode == 1 && !trk.enemy) continue;
                Vector3 center = BodyCenter(trk);
                float halfH = 0.95f * EspBox;
                Vector3 sf = cam.WorldToScreenPoint(center + Vector3.down * halfH);
                Vector3 sh = cam.WorldToScreenPoint(center + Vector3.up   * halfH);
                if (sf.z < 0.1f && sh.z < 0.1f) continue;
                if (sf.z < 0.1f) sf = sh;
                if (sh.z < 0.1f) sh = sf;
                float x1 = sf.x, y1 = Screen.height - sf.y;
                float x2 = sh.x, y2 = Screen.height - sh.y;
                float cx  = (x1 + x2) * 0.5f;
                float top = Mathf.Min(y1, y2), bot = Mathf.Max(y1, y2);
                float h   = Mathf.Max(bot - top, 12f);
                float w   = h * 0.38f * EspBox;
                float left = cx - w * 0.5f;
                Color col = trk.enemy ? EspEnemy : EspAlly;
                GUI.color = col;
                float th = 2f;
                GUI.DrawTexture(new Rect(left,         top,      w,  th), Texture2D.whiteTexture);
                GUI.DrawTexture(new Rect(left,         bot - th, w,  th), Texture2D.whiteTexture);
                GUI.DrawTexture(new Rect(left,         top,      th, h),  Texture2D.whiteTexture);
                GUI.DrawTexture(new Rect(left + w - th, top,    th, h),  Texture2D.whiteTexture);
                if (EspLine)
                {
                    Vector2 a = new Vector2(Screen.width * 0.5f, Screen.height - 2f);
                    Vector2 b = new Vector2(cx, bot);
                    float dx = b.x - a.x, dy = b.y - a.y;
                    float len = Mathf.Sqrt(dx * dx + dy * dy);
                    if (len > 4f)
                    {
                        Matrix4x4 bak = GUI.matrix;
                        GUIUtility.RotateAroundPivot(Mathf.Atan2(dy, dx) * Mathf.Rad2Deg, a);
                        GUI.DrawTexture(new Rect(a.x, a.y, len, 1f), Texture2D.whiteTexture);
                        GUI.matrix = bak;
                    }
                }
                if (EspName)
                    GUI.Label(new Rect(left, top - 14f, w + 80f, 16f), trk.name);
                if (EspHealth)
                {
                    if (trk.maxHp < 1f) trk.maxHp = trk.hp > 0f ? trk.hp : 1f;
                    if (trk.hp <= 0f && trk.nextHp > 0f) { _list.RemoveAt(i); continue; }
                    float pct = Mathf.Clamp01(trk.hp / trk.maxHp);
                    GUI.color = new Color(0f, 0f, 0f, 0.6f);
                    GUI.DrawTexture(new Rect(left, top - 5f, w, 3f), Texture2D.whiteTexture);
                    GUI.color = Color.Lerp(Color.red, Color.green, pct);
                    GUI.DrawTexture(new Rect(left, top - 5f, w * pct, 3f), Texture2D.whiteTexture);
                }
            }
            GUI.color = Color.white;
        }

        static Vector3 BodyCenter(Tracked trk)
        {
            if (trk.hip != null) return trk.hip.worldCenterOfMass;
            return trk.tr.position + Vector3.up * 0.9f;
        }

        static bool IsBattleContext()
        {
            try
            {
                var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name ?? "";
                var s = scene.ToLowerInvariant();
                if (s.Contains("menu") || s.Contains("main") || s.Contains("title")
                    || s.Contains("mars") || s.Contains("lobby"))
                    return false;
            }
            catch { }
            int n = 0;
            foreach (var u in Actions.Units())
            {
                if (u == null) continue;
                try
                {
                    if (!u.gameObject.activeInHierarchy) continue;
                    if (u.GetComponentInChildren<Rigidbody>() == null) continue;
                }
                catch { continue; }
                n++;
                if (n >= 2) return true;
            }
            return false;
        }

        static void Scan()
        {
            Refl();
            _list.Clear();
            if (_unitType == null) return;
            if (!IsBattleContext()) { Status = "esp: not in battle"; return; }
            var units = Actions.Units();
            int mine = Teams.MineCached();
            foreach (var c in units)
            {
                if (c == null || IsDead(c)) continue;
                int team = Teams.OfUnit(c);
                if (team != 0 && team != 1) continue;
                bool enemy = (mine == 0 || mine == 1) ? team != mine : team == 1;
                Rigidbody hip = null;
                try
                {
                    var rbs = c.GetComponentsInChildren<Rigidbody>();
                    if (rbs != null)
                    {
                        float best = -1f;
                        for (int r = 0; r < rbs.Length; r++)
                        {
                            if (rbs[r] == null || rbs[r].isKinematic) continue;
                            if (rbs[r].mass > best) { best = rbs[r].mass; hip = rbs[r]; }
                        }
                    }
                }
                catch { }
                float hp, mx;
                ReadHp(c, out hp, out mx);
                _list.Add(new Tracked {
                    unit = c, tr = c.transform, hip = hip,
                    enemy = enemy, name = ReadName(c),
                    hp = hp, maxHp = mx < 1f ? 1f : mx, nextHp = 0f
                });
            }
            Status = "units " + _list.Count;
        }

        static string ReadName(Component u)
        {
            try
            {
                object data = _dataField != null ? _dataField.GetValue(u) : null;
                if (data != null)
                {
                    foreach (var n in new[] { "unitName", "name" })
                    {
                        var f = AccessTools.Field(data.GetType(), n);
                        if (f != null && f.FieldType == typeof(string))
                        {
                            var s = f.GetValue(data) as string;
                            if (!string.IsNullOrEmpty(s)) return TrimName(s);
                        }
                    }
                }
                return TrimName(u.gameObject.name);
            }
            catch { return TrimName(u.name); }
        }

        static string TrimName(string s)
        {
            if (string.IsNullOrEmpty(s)) return "?";
            s = s.Replace("(Clone)", "").Trim();
            if (s.Length > 18) s = s.Substring(0, 18);
            return s;
        }

        static void ReadHp(Component u, out float hp, out float max)
        {
            hp  = -1f;
            max = -1f;
            try
            {
                if (_hhType == null) _hhType = AccessTools.TypeByName("HealthHandler");
                if (_hhType == null) { hp = 100f; max = 100f; return; }
                var hhComp = (u.GetComponent(_hhType) ?? u.GetComponentInChildren(_hhType)) as Component;
                if (hhComp == null) { hp = 100f; max = 100f; return; }

                try
                {
                    var pMax = AccessTools.Property(hhComp.GetType(), "MaxHealth");
                    var pCur = AccessTools.Property(hhComp.GetType(), "CurrentHealth");
                    if (pMax != null && pCur != null)
                    {
                        max = Convert.ToSingle(pMax.GetValue(hhComp, null));
                        hp  = Convert.ToSingle(pCur.GetValue(hhComp, null));
                        if (max > 0f && hp >= 0f) return;
                    }
                }
                catch { }

                object dataObj = null;
                try { dataObj = AccessTools.Field(hhComp.GetType(), "data")?.GetValue(hhComp); } catch { }
                var sources = new object[] { dataObj, (object)hhComp };

                foreach (var src in sources)
                {
                    if (src == null) continue;
                    var t = src.GetType();

                    if (hp < 0f)
                        foreach (var n in new[] { "health","currentHealth","m_health","Health",
                                                  "hp","HP","m_currentHealth","healthPoints","m_hp" })
                        {
                            var f = AccessTools.Field(t, n);
                            if (f == null) continue;
                            float v = -1f;
                            if      (f.FieldType == typeof(float)) v = (float)f.GetValue(src);
                            else if (f.FieldType == typeof(int))   v = (int)  f.GetValue(src);
                            if (v >= 0f) { hp = v; break; }
                        }

                    if (max < 0f)
                        foreach (var n in new[] { "maxHealth","maxHP","m_maxHealth","MaxHealth",
                                                  "startHealth","baseHealth","startingHealth",
                                                  "m_startHealth","fullHealth","maxHp","m_fullHealth" })
                        {
                            var f = AccessTools.Field(t, n);
                            if (f == null) continue;
                            float v = -1f;
                            if      (f.FieldType == typeof(float)) v = (float)f.GetValue(src);
                            else if (f.FieldType == typeof(int))   v = (int)  f.GetValue(src);
                            if (v > 0f) { max = v; break; }
                        }

                    if (hp >= 0f && max > 0f) break;
                }
            }
            catch { }

            if (hp  < 0f) hp  = 100f;
            if (max <= 0f) max = hp > 0f ? hp : 100f;
            if (hp > max && max > 0f) hp = max;
        }

        static bool IsDead(Component u)
        {
            try
            {
                var data = _dataField != null ? _dataField.GetValue(u) : null;
                if (data == null) return false;
                var f = AccessTools.Field(data.GetType(), "dead");
                return f != null && f.FieldType == typeof(bool) && (bool)f.GetValue(data);
            }
            catch { return false; }
        }
    }
}