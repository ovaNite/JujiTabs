using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace JujiTABS
{
    [BepInPlugin(Guid, Name, Version)]
    public class Plugin : BaseUnityPlugin
    {
        public const string Guid = "com.juji.tabs";
        public const string Name = "JujiTABS";
        public const string Version = "2.11.1";

        internal static ManualLogSource Log;

        public static bool GodMode = true;
        public static bool OneHit = false;
        public static bool SuperArmor = false;
        public static bool FriendlyFire = false;
        public static bool InfiniteBudget = true;
        public static bool AlwaysAfford = true;
        public static bool BlockSpend = true;
        public static bool InfiniteUnits = true;
        public static int BudgetAmount = 999999;
        public static float TimeScale = 1f;
        public static int LocalTeam = 0;
        public static bool AutoTeam = false;

        public static bool PossessSpeed = true;
        public static float PossessSpeedMult = 2.5f;
        public static bool PossessAtkSpeed = true;
        public static float PossessAtkMult = 3f;
        public static bool PossessTeleport = true;
        public static bool AutoTeleport = false;   // Standard AUS, wird bei Bedarf über Button aktiviert
        public static float AutoTeleportDelay = 0.3f;

        public static bool SilentAim = true;
        public static bool RapidFire = true;

        public static bool SafeOnline = true;

        // ── RAGE FEATURES ─────────────────────────────────────────────────────
        public static bool RageJuggernaut     = false; // Allies: Infinite Mass (kein Knockback)
        public static bool RageFreezeEnemies  = false; // Feinde eingefroren
        public static bool RageTornado        = false; // Feinde permanent geschleudert
        public static bool RageExplosiveTouch = false; // Allies explodieren in Nähe von Feinden
        public static bool RageGigaSize       = false; // Allies größer
        public static float GigaSizeMultiplier = 2.5f;
        public static bool RageAntiGravity    = false; // Feinde schweben

        // GUI themes: 0=Hellpink, 1=Frost, 2=Black, 3=Cyan, 4=Toxic, 5=Rainbow, 6=Custom
        public static int GuiTheme = 0;
        public static bool UseCustomGui = false;
        public static Color CustomGuiBg = new Color(0.07f, 0.02f, 0.05f, 0.98f);
        public static Color CustomGuiAccent = new Color(1f, 0.25f, 0.72f, 1f);
        public static Color CustomGuiButton = new Color(0.28f, 0.05f, 0.18f, 0.98f);
        public static int CustomGuiRevision = 0;
        public static bool RealisticGfx = false;
        public static float GfxShadowDist = 150f;
        public static bool SkinGameUi = false;
        public static bool VSync = true;
        public static int TargetFps = 60;

        static bool _menu;
        public static bool IsMenuOpen => _menu;   // für CombatMod TP-Check
        static bool _patched;
        Harmony _harmony;
        Rect _win = new Rect(24, 24, 380, 560);
        int _tab;
        string _status = "F5 Menue";
        Vector2 _scroll;
        string _players = "—";
        string _sessions = "press REFRESH";

        static Plugin _instance;

        void Awake()
        {
            // Survive map load / multiplayer join — otherwise menu vanishes mid-game
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            _instance = this;
            DontDestroyOnLoad(gameObject);
            try { DontDestroyOnLoad(this); } catch { }

            Log = Logger;
            if (_harmony == null)
                _harmony = new Harmony(Guid);
            Log.LogInfo(Name + " " + Version + " (persistent)");
        }

        float _patchAt = -1f;
        static float _sceneGrace;
        void Start()
        {
            // NEVER patch during splash — GetTypes freeze = "reagiert nicht"
            _patchAt = Time.realtimeSinceStartup + 4f;
            try
            {
                UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
            }
            catch { }
        }

        void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        {
            try
            {
                Actions.AllUnits.Clear();
                CombatMod.ClearBattleState();
                _sceneGrace = Time.realtimeSinceStartup + 2f;
                _status = "scene " + scene.name;
            }
            catch { }
        }

        void TryPatch()
        {
            if (_patched) return;
            // Wait until splash is gone
            if (_patchAt > 0f && Time.realtimeSinceStartup < _patchAt)
                return;
            if (AccessTools.TypeByName("HealthHandler") == null
                && AccessTools.TypeByName("Landfall.TABS.Unit") == null)
                return;
            try
            {
                int n = Patcher.Apply(_harmony);
                _patched = true;
                _status = "OK patches=" + n;
                Log.LogInfo(_status);
            }
            catch (Exception e)
            {
                Log.LogError("Patch failed: " + e);
                _patchAt = Time.realtimeSinceStartup + 5f; // retry later
            }
        }

        void Update()
        {
            // GetKeyUp = less double-toggle with game capturing keys
            if (Input.GetKeyUp(KeyCode.Insert) || Input.GetKeyUp(KeyCode.F5))
            {
                _menu = !_menu;
                _status = _menu ? "Menue AN" : "Menue AUS";
                if (!_patched) { _patchAt = 0f; TryPatch(); }
            }
            if (!_patched) TryPatch();
            if (TimeScale > 0.05f && Mathf.Abs(Time.timeScale - TimeScale) > 0.05f)
                Time.timeScale = TimeScale;

            if (Input.GetKeyDown(KeyCode.T))
            {
                int mine = Teams.MineCached();
                if (mine == 0 || mine == 1)
                    _status = "TP " + Actions.TeleportAlliesToEnemies(mine) + " Einheiten";
            }

            if (Input.GetKeyDown(KeyCode.F6))
                DumpTypes();

            if (Time.realtimeSinceStartup >= _sceneGrace)
            {
                try { CombatMod.OnInput(); } catch { }
            }
        }

        // Verzögerter Teleport, z.B. nach Spawn
        public static void DelayedTeleport(float delay)
        {
            int mine = Teams.MineCached();
            if (mine == 0 || mine == 1)
                Actions.TeleportAlliesToEnemies(mine);
        }

        void DumpTypes()
        {
            var sb = new StringBuilder();
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (!asm.GetName().Name.Contains("Assembly-CSharp")) continue;
                Type[] types;
                try { types = asm.GetTypes(); } catch { continue; }
                sb.AppendLine("=== Assembly: " + asm.FullName);
                foreach (var t in types)
                {
                    sb.AppendLine("  TYPE: " + t.FullName);
                    foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
                    {
                        if (m.Name.Contains("Damage") || m.Name.Contains("Shoot") || m.Name.Contains("Fire") ||
                            m.Name.Contains("Aim") || m.Name.Contains("Health") || m.Name.Contains("Place") ||
                            m.Name.Contains("CanPlace") || m.Name.Contains("Money") || m.Name.Contains("Budget") ||
                            m.Name.Contains("Team") || m.Name.Contains("Unit") || m.Name.Contains("Cooldown"))
                        {
                            sb.AppendLine("    METHOD: " + m.ReturnType.Name + " " + m.Name + "(" + string.Join(", ", Array.ConvertAll(m.GetParameters(), p => p.ParameterType.Name + " " + p.Name)) + ")");
                        }
                    }
                }
            }
            System.IO.File.WriteAllText(@"C:\Users\ovani\Downloads\JujiTABS\dump.txt", sb.ToString());
            _status = "Dump geschrieben!";
        }

        static GUIStyle _titleStyle, _btnStyle, _togStyle, _labStyle, _winStyle;
        static Texture2D _winTex, _btnTex, _btnHot, _togOn;
        static int _skinBuilt = -1;

        static Color ThemeBg()
        {
            switch (GuiTheme)
            {
                case 1: return new Color(0.10f, 0.14f, 0.18f, 0.96f); // Frost
                case 2: return new Color(0.03f, 0.03f, 0.04f, 0.98f); // Black
                case 3: return new Color(0.05f, 0.08f, 0.12f, 0.96f); // Cyan
                default: return new Color(0.18f, 0.06f, 0.12f, 0.95f); // Hellpink
            }
        }
        static Color ThemeAccent()
        {
            switch (GuiTheme)
            {
                case 1: return new Color(0.75f, 0.90f, 1f, 1f); // Frost
                case 2: return new Color(0.85f, 0.85f, 0.90f, 1f); // Black -> FIX: war Pink (Copy-Paste-Fehler), jetzt neutrales Hellgrau als Akzent
                case 3: return new Color(0.35f, 0.85f, 1f, 1f);
                default: return new Color(1f, 0.55f, 0.78f, 1f);
            }
        }
        static Texture2D Solid(Color c)
        {
            var t = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            t.SetPixels(new[] { c, c, c, c });
            t.Apply();
            return t;
        }
        void EnsureSkin()
        {
            if (_skinBuilt == GuiTheme && _winStyle != null) return;
            _skinBuilt = GuiTheme;
            var bg = ThemeBg();
            var ac = ThemeAccent();
            _winTex = Solid(bg);
            _btnTex = Solid(new Color(ac.r * 0.45f, ac.g * 0.45f, ac.b * 0.45f, 0.95f));
            _btnHot = Solid(new Color(ac.r * 0.7f, ac.g * 0.55f, ac.b * 0.65f, 1f));
            _togOn = Solid(new Color(ac.r, ac.g * 0.5f, ac.b * 0.7f, 0.9f));

            _winStyle = new GUIStyle(GUI.skin.window);
            _winStyle.normal.background = _winTex;
            _winStyle.onNormal.background = _winTex;
            _winStyle.normal.textColor = ac;
            _winStyle.fontSize = 14;
            _winStyle.fontStyle = FontStyle.Bold;
            _winStyle.alignment = TextAnchor.UpperCenter;
            _winStyle.padding = new RectOffset(10, 10, 22, 10);

            _btnStyle = new GUIStyle(GUI.skin.button);
            _btnStyle.normal.background = _btnTex;
            _btnStyle.hover.background = _btnHot;
            _btnStyle.active.background = _btnHot;
            _btnStyle.normal.textColor = Color.white;
            _btnStyle.hover.textColor = Color.white;
            _btnStyle.fontSize = 12;
            _btnStyle.fontStyle = FontStyle.Bold;
            _btnStyle.fixedHeight = 28;
            _btnStyle.margin = new RectOffset(2, 2, 2, 2);

            _togStyle = new GUIStyle(GUI.skin.toggle);
            _togStyle.normal.textColor = new Color(1f, 0.9f, 0.95f);
            _togStyle.onNormal.textColor = ac;
            _togStyle.fontSize = 12;

            _labStyle = new GUIStyle(GUI.skin.label);
            _labStyle.normal.textColor = new Color(1f, 0.85f, 0.92f);
            _labStyle.fontSize = 11;

            _titleStyle = new GUIStyle(_labStyle);
            _titleStyle.fontSize = 13;
            _titleStyle.fontStyle = FontStyle.Bold;
            _titleStyle.normal.textColor = ac;
        }

        // ── LoadUI: Ladebalken während der 4s Initialisierungs-Verzögerung ───────
        static Texture2D _loadTx;
        void DrawLoadUi()
        {
            if (_patched) return; // fertig geladen → nie mehr zeigen
            float remaining = _patchAt - Time.realtimeSinceStartup;
            if (remaining <= 0f) return;
            float pct = Mathf.Clamp01(1f - remaining / 4f);

            if (_loadTx == null)
            {
                _loadTx = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                _loadTx.SetPixel(0, 0, Color.white);
                _loadTx.Apply();
            }

            float bw = 320f, bh = 28f;
            float bx = (Screen.width  - bw) * 0.5f;
            float by = Screen.height  - 70f;

            // Hintergrund
            GUI.color = new Color(0.03f, 0.01f, 0.04f, 0.88f);
            GUI.DrawTexture(new Rect(bx - 3f, by - 3f, bw + 6f, bh + 6f), _loadTx);
            // Leere Leiste
            GUI.color = new Color(0.12f, 0.05f, 0.10f, 0.95f);
            GUI.DrawTexture(new Rect(bx, by, bw, bh), _loadTx);
            // Fortschritt (Pink)
            GUI.color = new Color(1f, 0.42f, 0.72f, 1f);
            GUI.DrawTexture(new Rect(bx, by, bw * pct, bh), _loadTx);
            // Text
            GUI.color = Color.white;
            GUI.Label(new Rect(bx + 10f, by + 5f, bw - 20f, bh - 10f),
                      "✦ JujiTABS lädt...  " + (int)(pct * 100f) + "%");
            GUI.color = Color.white;
        }

        void OnGUI()
        {
            try { DrawLoadUi(); } catch { }           // ← NEUER LoadUI-Balken
            try { CombatMod.DrawEsp(); } catch { }
            try { GameUiSkin.DrawLoading(); } catch { }
            if (!_menu) return;
            try
            {
                // Keep window on-screen after resolution / scene changes
                if (_win.x > Screen.width - 40f) _win.x = 20f;
                if (_win.y > Screen.height - 40f) _win.y = 20f;
                if (_win.x < -200f) _win.x = 20f;
                if (_win.y < -20f) _win.y = 20f;

                EnsureSkin();
                GUI.backgroundColor = ThemeBg();
                GUI.contentColor = Color.white;
                GUI.depth = -1000; // draw above game UI
                _win = GUI.Window(96218, _win, DrawSafe, "JujiTABS " + Version, _winStyle ?? GUI.skin.window);
            }
            catch (Exception e)
            {
                // never clear _menu on error — show fallback so menu never "vanishes"
                try
                {
                    GUI.Label(new Rect(20, 20, 400, 40), "JujiTABS menu error: " + e.Message);
                }
                catch { }
            }
        }

        void DrawSafe(int id)
        {
            try { Draw(id); }
            catch (Exception e)
            {
                GUILayout.Label("Draw error: " + e.Message);
                GUI.DragWindow(new Rect(0, 0, 10000, 24));
            }
        }

        void Draw(int id)
        {
            EnsureSkin();
            var B = _btnStyle ?? GUI.skin.button;
            var T = _togStyle ?? GUI.skin.toggle;
            var L = _labStyle ?? GUI.skin.label;
            var TT = _titleStyle ?? L;

            _scroll = GUILayout.BeginScrollView(_scroll, GUILayout.Height(500));
            GUILayout.Label(_status, L);

            GUILayout.BeginHorizontal();
            if (GUILayout.Toggle(_tab == 0, "Combat", B)) _tab = 0;
            if (GUILayout.Toggle(_tab == 1, "Budget", B)) _tab = 1;
            if (GUILayout.Toggle(_tab == 2, "Online", B)) _tab = 2;
            if (GUILayout.Toggle(_tab == 3, "World", B)) _tab = 3;
            if (GUILayout.Toggle(_tab == 4, "Aim", B)) _tab = 4;
            if (GUILayout.Toggle(_tab == 5, "RAGE", B)) _tab = 5;
            if (GUILayout.Toggle(_tab == 6, "Style", B)) _tab = 6;
            GUILayout.EndHorizontal();
            GUILayout.Space(6);

            if (_tab == 0)
            {
                GUILayout.Label("COMBAT", TT);
                GodMode = GUILayout.Toggle(GodMode, " Godmode", T);
                SuperArmor = GUILayout.Toggle(SuperArmor, " Super Armor", T);
                OneHit = GUILayout.Toggle(OneHit, " One-Hit", T);
                FriendlyFire = GUILayout.Toggle(FriendlyFire, " Friendly Fire", T);
                AutoTeam = GUILayout.Toggle(AutoTeam, " Auto-Team", T);
                int mine = Teams.MineCached();
                GUILayout.Label("Team: " + (mine == 0 ? "RED" : mine == 1 ? "BLUE" : "?"), L);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("RED", B)) { AutoTeam = false; LocalTeam = 0; }
                if (GUILayout.Button("BLUE", B)) { AutoTeam = false; LocalTeam = 1; }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("HEAL", B)) { Actions.RefreshUnitsEvent(); _status = "heal " + Actions.Heal(Plugin.LocalTeam); }
                if (GUILayout.Button("KILL ENEMY", B)) { Actions.RefreshUnitsEvent(); _status = "kill " + Actions.KillEnemies(); }
                GUILayout.EndHorizontal();
                PossessTeleport = GUILayout.Toggle(PossessTeleport, " CTRL+LMB Teleport", T);
                GUILayout.Label("CTRL + Linksklick = Team zum Mauspunkt", L);
                if (GUILayout.Button("APPLY EFFECTS (einmal)", B))
                {
                    CombatMod.ApplyAllEffectsOnce();
                    _status = "effects once";
                }
                GUILayout.Label("Buffs/God/Rage: nur bei APPLY oder Feature-Toggle — nicht pro Spawn.", L);
            }
            else if (_tab == 1)
            {
                GUILayout.Label("BUDGET", TT);
                SafeOnline = GUILayout.Toggle(SafeOnline, " Safe Online (Lobby)", T);
                InfiniteBudget = GUILayout.Toggle(InfiniteBudget, " Infinite", T);
                AlwaysAfford = GUILayout.Toggle(AlwaysAfford, " Always Afford", T);
                BlockSpend = GUILayout.Toggle(BlockSpend, " Block Spend", T);
                InfiniteUnits = GUILayout.Toggle(InfiniteUnits, " Infinite Units", T);
                CombatMod.PlaceEverywhere = GUILayout.Toggle(CombatMod.PlaceEverywhere, " Place Everywhere", T);
                GUILayout.Label("Budget " + BudgetAmount, L);
                BudgetAmount = (int)GUILayout.HorizontalSlider(BudgetAmount, 10000, 999999);
                if (GUILayout.Button("FORCE BUDGET", B))
                    _status = "budget " + Actions.ForceBudget(BudgetAmount);
            }
            else if (_tab == 2)
            {
                GUILayout.Label("ONLINE (nur Anzeige)", TT);
                GUILayout.Label("Matchmaking = nur Spiel-UI. Mod erzwingt keine Server.", L);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("OPEN MP", B)) _status = Online.OpenMP();
                if (GUILayout.Button("REFRESH", B))
                {
                    _players = Online.PlayerNames();
                    _sessions = Online.ListSessions();
                    _status = "refresh";
                }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("PLAYERS", B)) { _players = Online.PlayerNames(); _status = "players"; }
                if (GUILayout.Button("MATCHES", B)) { _sessions = Online.ListSessions(); _status = "matches"; }
                GUILayout.EndHorizontal();
                if (GUILayout.Button("BACK (soft)", B)) _status = Online.GoBackOnly();
                GUILayout.Label("--- Players ---", L);
                GUILayout.Label(string.IsNullOrEmpty(_players) ? "(noch keine Daten / nicht im Match)" : _players, L);
                GUILayout.Label("--- Matches ---", L);
                GUILayout.Label(string.IsNullOrEmpty(_sessions) ? "(0 = Server/API liefert nichts)" : _sessions, L);
            }
            else if (_tab == 3)
            {
                GUILayout.Label("SETTINGS / GFX", TT);
                GUILayout.Label("Ultra = max Unity-Quality. KEINE Custom-Shader / kein Foto-Realismus.", L);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("MITTEL", B))
                {
                    Gfx.ApplyMedium();
                    RealisticGraphics.SetEnabled(false);
                    RealisticGfx = false;
                    RealisticGraphics.Preset = 1;
                    _status = "GFX Mittel";
                }
                if (GUILayout.Button("ULTRA", B))
                {
                    Gfx.ApplyUltra();
                    RealisticGraphics.ShadowDist = GfxShadowDist;
                    RealisticGraphics.SetEnabled(true);
                    RealisticGfx = true;
                    RealisticGraphics.Preset = 3;
                    _status = "GFX Ultra";
                }
                GUILayout.EndHorizontal();
                GUILayout.Label("Shadow Dist " + (int)GfxShadowDist, L);
                GfxShadowDist = GUILayout.HorizontalSlider(GfxShadowDist, 50f, 300f);
                VSync = GUILayout.Toggle(VSync, " VSync", T);
                GUILayout.Label("FPS Cap " + (TargetFps <= 0 ? "Unlimited" : TargetFps.ToString()), L);
                TargetFps = (int)GUILayout.HorizontalSlider(TargetFps, 0, 240);
                if (GUILayout.Button("APPLY FPS/VSYNC", B))
                {
                    Gfx.ApplyFpsVsync();
                    _status = "fps/vsync";
                }
                GUILayout.Space(8);
                GUILayout.Label("REALISTIC GRAPHICS", TT);
                RealisticGraphics.DrawSettingsGUI();
                GUILayout.Space(8);
                GUILayout.Label("Speed x" + TimeScale.ToString("0.00"), L);
                TimeScale = GUILayout.HorizontalSlider(TimeScale, 0.25f, 2.5f);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("1x", B)) TimeScale = 1f;
                if (GUILayout.Button("1.5x", B)) TimeScale = 1.5f;
                if (GUILayout.Button("2x", B)) TimeScale = 2f;
                GUILayout.EndHorizontal();
                PossessSpeed = GUILayout.Toggle(PossessSpeed, " Team Speed x" + PossessSpeedMult.ToString("0.0"), T);
                PossessSpeedMult = GUILayout.HorizontalSlider(PossessSpeedMult, 1f, 5f);
                PossessAtkSpeed = GUILayout.Toggle(PossessAtkSpeed, " Atk Speed x" + PossessAtkMult.ToString("0.0"), T);
                PossessAtkMult = GUILayout.HorizontalSlider(PossessAtkMult, 1f, 8f);
                if (GUILayout.Button("APPLY TEAM SPEED/ATK", B))
                {
                    CombatMod.ApplyAllEffectsOnce();
                    _status = "team buffs";
                }

            }
            else if (_tab == 4)
            {
                GUILayout.Label("AIM / ESP", TT);
                SilentAim = GUILayout.Toggle(SilentAim, " Silent Aim (Kugeln zum Kopf, Maus bleibt)", T);
                RapidFire = GUILayout.Toggle(RapidFire, " Rapid Fire (kein Cooldown, kein Rückstoß)", T);
                CombatMod.Aimbot = GUILayout.Toggle(CombatMod.Aimbot, " Aimbot (MB2: Kamera/Maus zum Kopf)", T);
                GUILayout.Label("Smooth " + CombatMod.AimbotSmooth.ToString("0.00"), L);
                CombatMod.AimbotSmooth = GUILayout.HorizontalSlider(CombatMod.AimbotSmooth, 0.05f, 1f);
                GUILayout.Label("Predict " + CombatMod.AimbotPredict.ToString("0.0"), L);
                CombatMod.AimbotPredict = GUILayout.HorizontalSlider(CombatMod.AimbotPredict, 0f, 2.5f);
                GUILayout.Label("Range " + (int)CombatMod.AimbotRange, L);
                CombatMod.AimbotRange = GUILayout.HorizontalSlider(CombatMod.AimbotRange, 20f, 200f);
                CombatMod.EspEnabled = GUILayout.Toggle(CombatMod.EspEnabled, " ESP", T);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Enemy", B)) CombatMod.EspMode = 1;
                if (GUILayout.Button("Both", B)) CombatMod.EspMode = 2;
                GUILayout.EndHorizontal();
                CombatMod.EspHealth = GUILayout.Toggle(CombatMod.EspHealth, " HP Bar", T);
                CombatMod.EspLine = GUILayout.Toggle(CombatMod.EspLine, " Linie", T);
                GUILayout.Label(CombatMod.Status, L);
            }
            else if (_tab == 5)
            {
                GUILayout.Label("⚡ RAGE MODUS ⚡", TT);
                GUILayout.Label("TOGGLE FEATURES:", L);
                bool rj = RageJuggernaut, rf = RageFreezeEnemies, rt = RageTornado, re = RageExplosiveTouch;
                RageJuggernaut = GUILayout.Toggle(RageJuggernaut, " JUGGERNAUT  (Allies: kein Knockback, ∞ Masse)", T);
                RageFreezeEnemies = GUILayout.Toggle(RageFreezeEnemies, " FREEZE ENEMIES  (Feinde eingefroren)", T);
                RageTornado = GUILayout.Toggle(RageTornado, " TORNADO  (Feinde permanent schleudern)", T);
                RageExplosiveTouch = GUILayout.Toggle(RageExplosiveTouch, " EXPLOSIVE TOUCH  (Allies explodieren Feinde)", T);
                bool gigaBefore = RageGigaSize;
                RageGigaSize = GUILayout.Toggle(RageGigaSize, " GIGA SIZE  (Allies größer)", T);
                GigaSizeMultiplier = GUILayout.HorizontalSlider(GigaSizeMultiplier, 1.25f, 4f);
                GUILayout.Label("Giga x" + GigaSizeMultiplier.ToString("0.00"), L);
                if (!RageGigaSize && gigaBefore) CombatMod.RageResetGigaSize();
                bool agBefore = RageAntiGravity;
                RageAntiGravity = GUILayout.Toggle(RageAntiGravity, " ANTI-GRAVITY  (Feinde schweben)", T);
                if (RageAntiGravity != agBefore) CombatMod.RageToggleAntiGravity(RageAntiGravity);
                // Toggle changes are immediate events; no background Rage loop.
                if ((RageJuggernaut != rj) || (RageFreezeEnemies != rf) || (RageTornado != rt)
                    || (RageExplosiveTouch != re) || (RageGigaSize != gigaBefore))
                {
                    Actions.RefreshUnitsEvent();
                    CombatMod.ApplyRageEffectsOnce();
                    _status = "rage applied";
                }
                if (GUILayout.Button("APPLY RAGE NOW", B))
                {
                    Actions.RefreshUnitsEvent();
                    CombatMod.ApplyRageEffectsOnce();
                    _status = "rage applied to " + Actions.AllUnits.Count + " units";
                }
                GUILayout.Space(8);
                GUILayout.Label("EINMALIG AKTIONEN:", L);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("☠ INSTA KILL ALL", B))
                {
                    Actions.RefreshUnitsEvent();
                    _status = CombatMod.RageInstantKillAll();
                }
                if (GUILayout.Button("💥 ULTRA BOMB", B))
                {
                    Actions.RefreshUnitsEvent();
                    _status = CombatMod.RageUltraBomb();
                }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("HEAL TEAM", B)) { Actions.RefreshUnitsEvent(); _status = "heal " + Actions.Heal(LocalTeam); }
                if (GUILayout.Button("KILL ENEMY", B)) { Actions.RefreshUnitsEvent(); _status = "kill " + Actions.KillEnemies(); }
                GUILayout.EndHorizontal();
                if (GUILayout.Button("RESET GIGA SIZE", B)) { CombatMod.RageResetGigaSize(); RageGigaSize = false; }
                GUILayout.Label("⚠ Rage Features: NUR im aktiven Battle nutzen!", L);
            }
            else // Style (Tab 6)
            {
                GUILayout.Label("THEME / INGAME UI", TT);
                bool skinBefore = SkinGameUi;
                SkinGameUi = GUILayout.Toggle(SkinGameUi, " Skin ALL GAME Buttons", T);
                if (SkinGameUi && !skinBefore) GameUiSkin.RequestRescan(this);

                GUILayout.Label("Theme:", L);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Hellpink", B)) { GuiTheme = 0; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                if (GUILayout.Button("Frost", B)) { GuiTheme = 1; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                if (GUILayout.Button("Black", B)) { GuiTheme = 2; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Cyan", B)) { GuiTheme = 3; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                if (GUILayout.Button("Toxic", B)) { GuiTheme = 4; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                if (GUILayout.Button("Rainbow", B)) { GuiTheme = 5; UseCustomGui = false; GameUiSkin.RequestRescan(this); }
                GUILayout.EndHorizontal();
                if (GUILayout.Button("Custom", B)) { GuiTheme = 6; UseCustomGui = true; GameUiSkin.RequestRescan(this); }

                GUILayout.Label("Aktiv: " + (UseCustomGui ? "Custom" : GuiThemeName()), L);
                if (UseCustomGui)
                {
                    CustomGuiBg = GuiColorSliders("Background", CustomGuiBg);
                    CustomGuiButton = GuiColorSliders("Buttons", CustomGuiButton);
                    CustomGuiAccent = GuiColorSliders("Accent", CustomGuiAccent);
                    if (GUILayout.Button("APPLY CUSTOM TO ALL GAME BUTTONS", B)) GameUiSkin.RequestRescan(this);
                }
                else if (GUILayout.Button("APPLY STYLE TO ALL GAME BUTTONS", B))
                {
                    GameUiSkin.RequestRescan(this);
                }
                GUILayout.Label("Alle sichtbaren und neu aktivierten Ingame-Buttons nutzen den gewählten Style.", L);
                GUILayout.Label("F5/Insert = Menü | CTRL+LMB = Team-Teleport | RMB = Aimbot im Kampf", L);
            }

            GUILayout.EndScrollView();
            GUI.DragWindow(new Rect(0, 0, 10000, 24));
        }

        static string GuiThemeName()
        {
            switch (GuiTheme)
            {
                case 1: return "Frost";
                case 2: return "Black";
                case 3: return "Cyan";
                case 4: return "Toxic";
                case 5: return "Rainbow";
                case 6: return "Custom";
                default: return "Hellpink";
            }
        }

        static Color GuiColorSliders(string label, Color c)
        {
            Color before = c;
            GUILayout.Label(label + "  R " + c.r.ToString("0.00") + "  G " + c.g.ToString("0.00") + "  B " + c.b.ToString("0.00"), _labStyle ?? GUI.skin.label);
            c.r = GUILayout.HorizontalSlider(c.r, 0f, 1f);
            c.g = GUILayout.HorizontalSlider(c.g, 0f, 1f);
            c.b = GUILayout.HorizontalSlider(c.b, 0f, 1f);
            c.a = 0.98f;
            if (Mathf.Abs(c.r-before.r) > 0.0001f || Mathf.Abs(c.g-before.g) > 0.0001f || Mathf.Abs(c.b-before.b) > 0.0001f) CustomGuiRevision++;
            return c;
        }

        void OnDestroy()
        {
            // Never unpatch on scene change — only if this is truly the last instance
            if (_instance == this)
                _instance = null;
            // Keep Harmony patches alive across scene loads
        }
    }

    // =================== ONLINE ===================
    internal static class Online
    {
        public static string OpenMP()
        {
            try
            {
                var t = AccessTools.TypeByName("MainMenuButtons");
                var o = Find(t);
                var m = t != null ? AccessTools.Method(t, "OpenMultiplayerMenu") : null;
                if (o != null && m != null) { m.Invoke(o, null); return "OpenMultiplayerMenu"; }
                var pm = Mars();
                if (pm != null)
                {
                    Invoke0(pm, "OnOpenMultiplayer");
                    return "ProjectMars open";
                }
                return "open Multiplayer manually";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string Quick()
        {
            try
            {
                Plugin.SafeOnline = false; // Hooks MÜSSEN aktiv sein im Match!
                OpenMP();
                var pm = Mars();
                if (pm != null)
                {
                    foreach (var m in new[] {
                        "QuickMatch","JoinQuickMatch","FindMatch","StartQuickMatch",
                        "OnQuickMatchButtonClicked","OnQuickPlayButtonClicked",
                        "JoinAnySession","FindAndJoinSession","JoinPublicSession",
                        "SearchForBattle","StartMatchmaking","FindOpponent"
                    }) { if (Invoke0(pm, m)) return "QM OK: " + m; }
                }
                var ns = Net();
                if (ns != null)
                {
                    if (InvokeAny(ns, "JoinRandomSessionAsync","JoinRandomSession",
                                      "QuickMatch","FindSession","MatchmakeAsync"))
                        return "Network QuickMatch OK";
                }
                return "Quick Match: Bitte im MP-Menue auf Quick Match klicken (SafeOnline=OFF)";
            }
            catch (Exception e) { return "QM Fehler: " + e.Message; }
        }

        public static string CreateGame()
        {
            try
            {
                Plugin.SafeOnline = false; // Hooks MÜSSEN aktiv sein!
                OpenMP();
                var pm = Mars();
                if (pm != null)
                {
                    foreach (var m in new[] {
                        "CreateGame","CreateRoom","CreateSession","StartGame","HostGame",
                        "OnCreateGameButtonClicked","OnCreateButtonClicked",
                        "CreatePublicRoom","CreatePrivateRoom","OnHostButtonClicked",
                        "CreateBattle","HostBattle","StartHosting","CreateOnlineGame"
                    }) { if (Invoke0(pm, m)) return "Create OK: " + m; }
                }
                var ns = Net();
                if (ns != null)
                {
                    if (InvokeAny(ns, "CreateSessionAsync","CreateSession",
                                      "CreateGame","HostSession","CreateRoom"))
                        return "Network Create OK";
                }
                return "Create Game: Bitte im MP-Menue auf Create klicken (SafeOnline=OFF)";
            }
            catch (Exception e) { return "Create Fehler: " + e.Message; }
        }

        static void SetPublic(object pm, bool v)
        {
            try
            {
                var p = AccessTools.Property(pm.GetType(), "IsPublicSession");
                p?.SetValue(pm, v, null);
            }
            catch { }
        }

        public static string ListSessions()
        {
            try
            {
                var ns = Net();
                if (ns == null) return "NetworkService missing";
                InvokeAny(ns, "GetSessionsAsync", "GetSessions");
                var sb = new StringBuilder();
                int count = 0;
                foreach (var f in ns.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    object val;
                    try { val = f.GetValue(ns); } catch { continue; }
                    if (val == null) continue;
                    if (val is System.Collections.IEnumerable en && !(val is string))
                    {
                        foreach (var item in en)
                        {
                            if (item == null) continue;
                            string line = SessionLine(item);
                            if (line == null) continue;
                            sb.AppendLine(line);
                            count++;
                            if (count >= 30) break;
                        }
                    }
                }
                if (count == 0)
                    return "0 sessions (still searching / empty)\nTip: wait on Quick Match then REFRESH";
                return count + " sessions:\n" + sb;
            }
            catch (Exception e) { return "list err: " + e.Message; }
        }

        public static string JoinFirstPublic()
        {
            try
            {
                var ns = Net();
                if (ns == null) return "no NetworkService";
                if (InvokeAny(ns, "JoinRandomSessionAsync", "JoinRandomSession"))
                    return "JoinRandom called";
                return "Join: use game Quick Match UI";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string PlayerNames()
        {
            try
            {
                var sb = new StringBuilder();
                var t = AccessTools.TypeByName("TFBGames.ProjectMarsBattleUserUIManager");
                var mgr = Find(t);
                if (mgr != null)
                {
                    object local = InvokeRet(mgr, "GetLocalPlayerInfo");
                    object remote = InvokeRet(mgr, "GetRemotePlayerInfo");
                    sb.AppendLine("Local:  " + ProfileName(local));
                    sb.AppendLine("Remote: " + ProfileName(remote));
                }
                else sb.AppendLine("BattleUserUIManager: not in battle");

                var pt = AccessTools.TypeByName("TFBGames.PlayerProfile");
                if (pt != null && typeof(UnityEngine.Object).IsAssignableFrom(pt))
                {
                    var arr = Resources.FindObjectsOfTypeAll(pt);
                    int i = 0;
                    foreach (var o in arr)
                    {
                        if (o == null) continue;
                        string n = null;
                        try
                        {
                            var p = AccessTools.Property(pt, "PlayerName");
                            if (p != null) n = p.GetValue(o, null) as string;
                        }
                        catch { }
                        if (string.IsNullOrEmpty(n))
                        {
                            var f = AccessTools.Field(pt, "PlayerName") ?? AccessTools.Field(pt, "m_playerName");
                            if (f != null) n = f.GetValue(o) as string;
                        }
                        if (!string.IsNullOrEmpty(n))
                            sb.AppendLine("Profile[" + i + "]: " + n);
                        i++;
                        if (i > 8) break;
                    }
                }

                var nb = AccessTools.TypeByName("TFBGames.NetworkBattleController");
                var nbc = Find(nb);
                if (nbc != null)
                {
                    try
                    {
                        var both = AccessTools.Property(nb, "AreBothPlayersInBattleScene");
                        if (both != null) sb.AppendLine("BothInBattle: " + both.GetValue(nbc, null));
                    }
                    catch { }
                }

                return sb.Length > 0 ? sb.ToString() : "Keine Spieler-Daten.\n(Nur sichtbar IN einem Match / wenn API Profiles liefert)";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string Spectate()
        {
            try
            {
                var pm = Mars();
                if (pm == null) { OpenMP(); pm = Mars(); }
                if (pm == null) return "no ProjectMarsHandler";
                if (Invoke0(pm, "SpectateMars")) return "SpectateMars";
                if (Invoke0(pm, "StartSpectate")) return "StartSpectate";
                if (Invoke0(pm, "JoinAsSpectator")) return "JoinAsSpectator";
                if (Invoke0(pm, "OnSpectateButtonClicked")) return "OnSpectateButtonClicked";
                var ns = Net();
                if (ns != null && InvokeAny(ns, "SpectateSession", "SpectateAsync"))
                    return "Network spectate";
                return "Spectate: im Spiel-UI Spectator nutzen";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string KickOrDrop()
        {
            try
            {
                var nb = Find(AccessTools.TypeByName("TFBGames.NetworkBattleController"));
                if (nb != null)
                {
                    if (Invoke0(nb, "SetPrematureBattleEnd")) return "PrematureBattleEnd";
                    if (Invoke0(nb, "PlayerPrematurelyEndedBattle")) return "PlayerPrematurelyEndedBattle";
                }
                var pm = Mars();
                if (pm != null && Invoke0(pm, "GoBack")) return "GoBack";
                return "not in a match";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string GoBackOnly()
        {
            try
            {
                Plugin.SafeOnline = true;
                var pm = Mars();
                if (pm == null) return "no ProjectMarsHandler — BACK in Spiel-UI nutzen";
                // Soft back only — CloseProjectMarsWaiting often causes "Check your Network Connection"
                if (Invoke0(pm, "GoBack")) return "GoBack soft";
                if (Invoke0(pm, "OnBackButton")) return "OnBackButton";
                if (Invoke0(pm, "ReturnToMultiplayerMenu")) return "ReturnToMultiplayerMenu";
                return "BACK in der Spiel-UI druecken (sicherer)";
            }
            catch (Exception e) { return e.Message; }
        }

        public static string CancelAndLeave() => GoBackOnly();

        static string SessionLine(object item)
        {
            try
            {
                string host = ReadStr(item, "HostPlayerDisplayName")
                              ?? ReadStr(item, "hostPlayerDisplayName")
                              ?? ReadStr(item, "HostName")
                              ?? ReadStr(item, "hostName");
                string map = ReadStr(item, "RoomMapType") ?? ReadStr(item, "Map");
                string pub = ReadStr(item, "HostRoomIsPublic");
                if (host == null)
                {
                    foreach (var f in item.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                    {
                        object v;
                        try { v = f.GetValue(item); } catch { continue; }
                        if (v == null || v is string || v.GetType().IsPrimitive) continue;
                        host = ReadStr(v, "HostPlayerDisplayName");
                        if (host != null) break;
                    }
                }
                if (host == null) host = item.ToString();
                if (host != null && host.Length > 80) host = host.Substring(0, 80);
                return host + (map != null ? " | " + map : "") + (pub != null ? " | pub=" + pub : "");
            }
            catch { return null; }
        }

        static string ProfileName(object profile)
        {
            if (profile == null) return "(null)";
            string n = ReadStr(profile, "PlayerName") ?? ReadStr(profile, "Name") ?? ReadStr(profile, "DisplayName");
            return n ?? profile.ToString();
        }

        static string ReadStr(object o, string name)
        {
            if (o == null) return null;
            try
            {
                var p = AccessTools.Property(o.GetType(), name);
                if (p != null)
                {
                    var v = p.GetValue(o, null);
                    if (v is string s && s.Length > 0) return s;
                    if (v != null && !(v is string)) return v.ToString();
                }
            }
            catch { }
            try
            {
                var f = AccessTools.Field(o.GetType(), name);
                if (f != null)
                {
                    var v = f.GetValue(o);
                    if (v is string s && s.Length > 0) return s;
                }
            }
            catch { }
            return null;
        }

        static object Mars()
        {
            var t = AccessTools.TypeByName("TFBGames.ProjectMarsHandler")
                    ?? AccessTools.TypeByName("ProjectMarsHandler");
            if (t == null) return null;
            var p = AccessTools.Property(t, "Instance");
            if (p != null)
            {
                try { var v = p.GetValue(null, null); if (v != null) return v; } catch { }
            }
            return Find(t);
        }

        static object Net()
        {
            foreach (var n in new[] { "TFBGames.NetworkService", "NetworkService", "TFBGames.PlatformSyncedNetworkService" })
            {
                var t = AccessTools.TypeByName(n);
                var o = Find(t);
                if (o != null) return o;
            }
            return null;
        }

        static object Find(Type t)
        {
            if (t == null) return null;
            if (typeof(UnityEngine.Object).IsAssignableFrom(t))
            {
                try
                {
                    var arr = Resources.FindObjectsOfTypeAll(t);
                    if (arr != null && arr.Length > 0) return arr[0];
                }
                catch { }
            }
            try
            {
                var go = GameObject.FindObjectOfType(t);
                if (go != null) return go;
            }
            catch { }
            return null;
        }

        static bool Invoke0(object o, string method)
        {
            if (o == null) return false;
            try
            {
                var m = AccessTools.Method(o.GetType(), method);
                if (m == null || m.GetParameters().Length != 0) return false;
                m.Invoke(o, null);
                return true;
            }
            catch { return false; }
        }

        static bool InvokeAny(object o, params string[] methods)
        {
            foreach (var name in methods)
            {
                if (o == null) return false;
                foreach (var m in o.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (m.Name != name) continue;
                    try
                    {
                        var p = m.GetParameters();
                        if (p.Length == 0) { m.Invoke(o, null); return true; }
                        if (p.Length == 1 && p[0].ParameterType.IsClass && !p[0].ParameterType.IsAbstract)
                        {
                            m.Invoke(o, new[] { Activator.CreateInstance(p[0].ParameterType) });
                            return true;
                        }
                    }
                    catch { }
                }
            }
            return false;
        }

        static object InvokeRet(object o, string method)
        {
            try
            {
                var m = AccessTools.Method(o.GetType(), method);
                if (m == null || m.GetParameters().Length != 0) return null;
                return m.Invoke(o, null);
            }
            catch { return null; }
        }
    }

    // =================== PATCHER ===================
    internal static class Patcher
    {
        static Type[] _csharpTypes;
        static Type[] CSharpTypes()
        {
            if (_csharpTypes != null) return _csharpTypes;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (a.GetName().Name != "Assembly-CSharp") continue;
                try { _csharpTypes = a.GetTypes(); }
                catch (ReflectionTypeLoadException ex) { _csharpTypes = ex.Types; }
                catch { _csharpTypes = new Type[0]; }
                break;
            }
            if (_csharpTypes == null) _csharpTypes = new Type[0];
            return _csharpTypes;
        }

        public static int Apply(Harmony h)
        {
            int n = 0;
            // touch cache once
            try { CSharpTypes(); } catch { }
            n += HookBudget(h, "CanAfford", typeof(Hooks), nameof(Hooks.CanAfford));
            n += HookBudget(h, "SpendAmount", typeof(Hooks), nameof(Hooks.Spend));
            n += HookBudget(h, "IsInfinite", typeof(Hooks), nameof(Hooks.IsInf));
            n += HookBudget(h, "GetBudget", typeof(Hooks), nameof(Hooks.GetBud));
            n += HookBudget(h, "GetMaxBudget", typeof(Hooks), nameof(Hooks.GetBud));

            // Schaden & Tod – lokal + online (alle bekannten Methodennamen)
            foreach (var dmgMethod in new[] {
                "TakeDamage","AddDamage","ApplyDamage","DoDamage","RemoveHealth",
                "TakeDamageFromEnemy","TakeDamageNet","TakeDamageServer","OnTakeDamage",
                "ReceiveDamage","HandleDamage","ProcessDamage","DealDamage"
            })
            {
                n += HookType(h, "HealthHandler",       dmgMethod, typeof(Hooks), nameof(Hooks.TakeDmg));
                n += HookType(h, "HealthHandlerClient", dmgMethod, typeof(Hooks), nameof(Hooks.TakeDmg));
                n += HookType(h, "PlayerHealth",        dmgMethod, typeof(Hooks), nameof(Hooks.TakeDmg));
                n += HookNameExact(h, dmgMethod, typeof(Hooks), nameof(Hooks.TakeDmg));
            }
            foreach (var dieMethod in new[] { "Die","Death","OnDeath","Kill","HandleDeath" })
            {
                n += HookType(h, "HealthHandler",       dieMethod, typeof(Hooks), nameof(Hooks.Die));
                n += HookType(h, "HealthHandlerClient", dieMethod, typeof(Hooks), nameof(Hooks.Die));
                n += HookType(h, "PlayerHealth",        dieMethod, typeof(Hooks), nameof(Hooks.Die));
            }

            n += HookNameExact(h, "GetMaxUnits", typeof(Hooks), nameof(Hooks.MaxUnits));
            n += HookNameExact(h, "GetMaxUnitsForMultiplayer", typeof(Hooks), nameof(Hooks.MaxUnits));
            n += HookNameExact(h, "CanPlace", typeof(Hooks), nameof(Hooks.CanPlaceTrue));
            n += HookNameExact(h, "CanPlaceUnits", typeof(Hooks), nameof(Hooks.CanPlaceTrue));
            n += HookNameExact(h, "CanPlayerPlaceUnits", typeof(Hooks), nameof(Hooks.CanPlaceTrue));

            n += CombatMod.Patch(h);
            n += HookTypePost(h, "Landfall.TABS.PlacementCameraMovement", "OnEnterPlacementState", typeof(Hooks), nameof(Hooks.EnterPlacement));
            n += HookTypePost(h, "Landfall.TABS.PlacementCameraMovement", "OnExitPlacementState", typeof(Hooks), nameof(Hooks.ExitPlacement));
            n += HookTypePost(h, "Landfall.TABS.UnitPlacement.PlacementCursor", "OnEnterPlacementState", typeof(Hooks), nameof(Hooks.EnterPlacement));
            n += HookTypePost(h, "Landfall.TABS.UnitPlacement.PlacementCursor", "OnExitPlacementState", typeof(Hooks), nameof(Hooks.ExitPlacement));
            n += HookNameExactPost(h, "DamageFeedback", typeof(Hooks), nameof(Hooks.HealthFeedbackPostfix));
            try { GameUiSkin.Install(h); } catch { }

            n += HookType(h, "Landfall.TABS.Unit", "Start", typeof(Hooks), nameof(Hooks.UnitStart));
            n += HookType(h, "Unit", "Start", typeof(Hooks), nameof(Hooks.UnitStart));
            return n;
        }

        static int HookType(Harmony h, string typeName, string method, Type ht, string hn)
        {
            int n = 0;
            var t = AccessTools.TypeByName(typeName);
            if (t == null) return 0;
            foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (m.Name != method) continue;
                try { h.Patch(m, prefix: new HarmonyMethod(ht.GetMethod(hn))); n++; }
                catch { }
            }
            return n;
        }

        static int HookNameExact(Harmony h, string method, Type ht, string hn)
        {
            int n = 0;
            var hm = ht.GetMethod(hn);
            if (hm == null) return 0;
            Assembly csharp = null;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
                if (a.GetName().Name == "Assembly-CSharp") { csharp = a; break; }
            if (csharp == null) return 0;
            Type[] types;
            try { types = csharp.GetTypes(); } catch { return 0; }
            foreach (var ty in types)
            {
                if (ty == null) continue;
                MethodInfo[] methods;
                try { methods = ty.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in methods)
                {
                    if (m.Name != method) continue;
                    try { h.Patch(m, prefix: new HarmonyMethod(hm)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int HookBudget(Harmony h, string method, Type ht, string hn)
        {
            int n = 0;
            Assembly csharp = null;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
                if (a.GetName().Name == "Assembly-CSharp") { csharp = a; break; }
            if (csharp == null) return 0;
            Type[] types;
            try { types = csharp.GetTypes(); } catch { return 0; }
            var hm = ht.GetMethod(hn);
            if (hm == null) return 0;
            foreach (var ty in types)
            {
                if (ty == null) continue;
                string tn = ty.FullName ?? ty.Name ?? "";
                if (tn.IndexOf("Wallet", StringComparison.OrdinalIgnoreCase) < 0
                    && tn.IndexOf("Budget", StringComparison.OrdinalIgnoreCase) < 0
                    && tn.IndexOf("UnitPlacement", StringComparison.OrdinalIgnoreCase) < 0
                    && tn.IndexOf("PlacementCost", StringComparison.OrdinalIgnoreCase) < 0)
                    continue;
                MethodInfo[] methods;
                try { methods = ty.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in methods)
                {
                    if (m.Name != method) continue;
                    try { h.Patch(m, prefix: new HarmonyMethod(hm)); n++; }
                    catch { }
                }
            }
            return n;
        }

        static int HookTypePost(Harmony h, string typeName, string method, Type ht, string hn)
        {
            int n = 0;
            var t = AccessTools.TypeByName(typeName);
            if (t == null) return 0;
            var hook = ht.GetMethod(hn);
            foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (m.Name != method) continue;
                try { h.Patch(m, postfix: new HarmonyMethod(hook)); n++; } catch { }
            }
            return n;
        }

        static int HookNameExactPost(Harmony h, string method, Type ht, string hn)
        {
            int n = 0;
            var hm = ht.GetMethod(hn);
            if (hm == null) return 0;
            Assembly csharp = null;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
                if (a.GetName().Name == "Assembly-CSharp") { csharp = a; break; }
            if (csharp == null) return 0;
            Type[] types;
            try { types = csharp.GetTypes(); } catch { return 0; }
            foreach (var ty in types)
            {
                if (ty == null) continue;
                MethodInfo[] methods;
                try { methods = ty.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                catch { continue; }
                foreach (var m in methods)
                {
                    if (m.Name != method) continue;
                    try { h.Patch(m, postfix: new HarmonyMethod(hm)); n++; } catch { }
                }
            }
            return n;
        }

    }

    // =================== HOOKS ===================
    public static class Hooks
    {
        public static bool CanAfford(ref bool __result)
        {
            if (Plugin.SafeOnline || !Plugin.AlwaysAfford) return true;
            __result = true;
            return false;
        }

        public static bool Spend()
        {
            if (Plugin.SafeOnline) return true;
            return !Plugin.BlockSpend;
        }

        public static bool IsInf(ref bool __result)
        {
            if (Plugin.SafeOnline || !Plugin.InfiniteBudget) return true;
            __result = true;
            return false;
        }

        public static void GetBud(ref int __result)
        {
            if (!Plugin.SafeOnline && Plugin.InfiniteBudget)
                __result = Plugin.BudgetAmount;
        }

        public static void EnterPlacement() { CombatMod.SetPlacementState(true); }
        public static void ExitPlacement() { CombatMod.SetPlacementState(false); }
        public static void HealthFeedbackPostfix(object __instance)
        {
            try { CombatMod.NotifyHealthEvent(__instance); } catch { }
        }

        public static bool TakeDmg(object __instance, object[] __args)
        {
            try
            {
                int targetTeam = Teams.OfHealth(__instance);
                if (targetTeam < 0) targetTeam = Teams.OfUnit(HealthToUnit(__instance));

                int mine = Teams.MineCached();
                if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
                if (mine != 0 && mine != 1) mine = 0;

                // Friendly fire block
                if (!Plugin.FriendlyFire && __args != null)
                {
                    foreach (var arg in __args)
                    {
                        if (arg == null) continue;
                        int attackerTeam = Teams.OfUnit(arg);
                        if (attackerTeam < 0) attackerTeam = Teams.OfHealth(arg);
                        if (attackerTeam >= 0 && targetTeam >= 0 && attackerTeam == targetTeam)
                            return false;
                    }
                }

                bool targetIsMine = targetTeam == mine;
                // If team unknown but GodMode: still try protect if unit registered as ally
                if (targetTeam < 0 && Plugin.GodMode)
                {
                    var u = HealthToUnit(__instance);
                    if (u != null && Teams.OfUnit(u) == mine) targetIsMine = true;
                }

                if (targetIsMine && (Plugin.GodMode || Plugin.SuperArmor))
                {
                    RestoreFull(__instance);
                    try
                    {
                        AccessTools.Method(__instance.GetType(), "SetInvulnerable", new[] { typeof(bool) })
                            ?.Invoke(__instance, new object[] { true });
                    }
                    catch { }
                    return false; // block damage client-side
                }
                if (!targetIsMine && targetTeam >= 0 && Plugin.OneHit)
                {
                    ZeroHp(__instance);
                    Teams.ForceDie(__instance);
                    return false;
                }
            }
            catch { }
            return true;
        }

        public static bool Die(object __instance)
        {
            try
            {
                int team = Teams.OfHealth(__instance);
                if (team < 0) team = Teams.OfUnit(HealthToUnit(__instance));
                int mine = Teams.MineCached();
                if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
                if ((Plugin.GodMode || Plugin.SuperArmor) && team == mine)
                {
                    RestoreFull(__instance);
                    return false;
                }
            }
            catch { }
            return true;
        }

        public static void MaxUnits(ref int __result)
        {
            if (!Plugin.SafeOnline && Plugin.InfiniteUnits)
                __result = 9999;
        }

        public static bool CanPlaceTrue(ref bool __result)
        {
            if (Plugin.SafeOnline) return true;
            if (!Plugin.InfiniteUnits && !CombatMod.PlaceEverywhere) return true;
            __result = true;
            return false;
        }

        static Component HealthToUnit(object hh)
        {
            if (hh == null) return null;
            try
            {
                var f = AccessTools.Field(hh.GetType(), "unit");
                if (f != null) return f.GetValue(hh) as Component;
            }
            catch { }
            try
            {
                var c = hh as Component;
                if (c != null)
                {
                    var ut = AccessTools.TypeByName("Landfall.TABS.Unit") ?? AccessTools.TypeByName("Unit");
                    if (ut != null)
                        return c.GetComponentInParent(ut) as Component;
                }
            }
            catch { }
            return null;
        }

        static void RestoreFull(object hh)
        {
            if (hh == null) return;
            try
            {
                var pMax = AccessTools.Property(hh.GetType(), "MaxHealth");
                var pCur = AccessTools.Property(hh.GetType(), "CurrentHealth");
                if (pMax != null && pCur != null && pCur.CanWrite)
                {
                    float max = Convert.ToSingle(pMax.GetValue(hh, null));
                    if (max > 0f) pCur.SetValue(hh, max, null);
                }
                else
                {
                    object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? hh;
                    float max = 1000f;
                    foreach (var n in new[] { "maxHealth", "MaxHealth", "maxHP", "m_maxHealth" })
                    {
                        var f = AccessTools.Field(data.GetType(), n);
                        if (f != null && (f.FieldType == typeof(float) || f.FieldType == typeof(int)))
                        { max = Convert.ToSingle(f.GetValue(data)); break; }
                    }
                    foreach (var n in new[] { "health", "Health", "currentHealth", "m_health" })
                    {
                        var f = AccessTools.Field(data.GetType(), n);
                        if (f != null && f.FieldType == typeof(float)) { f.SetValue(data, max); break; }
                        if (f != null && f.FieldType == typeof(int)) { f.SetValue(data, (int)max); break; }
                    }
                }
                var inv = AccessTools.Field(hh.GetType(), "isInvulnerable");
                if (inv != null && inv.FieldType == typeof(bool) && (Plugin.GodMode || Plugin.SuperArmor))
                    inv.SetValue(hh, true);
            }
            catch { }
        }

        static void ZeroHp(object hh)
        {
            try
            {
                object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? hh;
                foreach (var n in new[] { "health", "Health", "currentHealth", "m_health" })
                {
                    var f = AccessTools.Field(data.GetType(), n);
                    if (f != null && f.FieldType == typeof(float)) f.SetValue(data, 0f);
                    else if (f != null && f.FieldType == typeof(int)) f.SetValue(data, 0);
                }
            }
            catch { }
        }

        public static void UnitStart(object __instance)
        {
            var c = __instance as Component;
            if (c != null)
            {
                // Einheit zur Liste hinzufügen
                Actions.RegisterUnit(c);

                // Buffs direkt anwenden
                Actions.ApplyBuffToUnit(c);

                // Auto-Teleport nach kurzer Verzögerung
                if (Plugin.AutoTeleport)
                {
                    Plugin.DelayedTeleport(0.3f);
                }
            }
        }
    }

    // =================== TEAMS ===================
    internal static class Teams
    {
        static float _mineAt;
        static int _mineCache = -1;

        public static int MineCached()
        {
            if (!Plugin.AutoTeam)
                return Plugin.LocalTeam == 0 || Plugin.LocalTeam == 1 ? Plugin.LocalTeam : 0;
            float now = UnityEngine.Time.unscaledTime;
            if (_mineCache >= 0 && (now - _mineAt) < 5f)
                return _mineCache;
            _mineCache = Mine();
            _mineAt = now;
            return _mineCache;
        }

        public static int Mine()
        {
            if (!Plugin.AutoTeam)
                return Plugin.LocalTeam == 0 || Plugin.LocalTeam == 1 ? Plugin.LocalTeam : 0;

            int t = ReadPlayerTeam("TFBGames.NetworkService", "PlayerTeam");
            if (t == 0 || t == 1) { Plugin.LocalTeam = t; return t; }
            t = ReadPlayerTeam("TFBGames.PlayerProfile", "PlayerTeam");
            if (t == 0 || t == 1) { Plugin.LocalTeam = t; return t; }
            t = ReadPlayerTeam("Landfall.TABS.GameMode.LocalMultiplayerGameMode", "CurrentPlayerTeam");
            if (t == 0 || t == 1) { Plugin.LocalTeam = t; return t; }
            // FIX: Erkennung fehlgeschlagen (Singleplayer/Sandbox hat diese Types oft nicht).
            // Vorher: still auf Team 0 geraten -> bei Team 1 wurden eigene Einheiten
            // als "Feind" behandelt (OneHit/GodMode auf falschem Team). Jetzt: -1
            // zurückgeben, Aufrufer sollen dann auf Plugin.LocalTeam (manuell im GUI
            // gesetzt via RED/BLUE) zurückfallen statt zu raten.
            return -1;
        }

        static int ReadPlayerTeam(string typeName, string prop)
        {
            try
            {
                var t = AccessTools.TypeByName(typeName);
                if (t == null) return -1;
                object inst = null;
                var pInst = AccessTools.Property(t, "Instance");
                if (pInst != null) inst = pInst.GetValue(null, null);
                var p = AccessTools.Property(t, prop) ?? AccessTools.Property(t, "get_" + prop);
                object v = null;
                if (p != null)
                    v = p.GetGetMethod(true) != null && p.GetGetMethod(true).IsStatic
                        ? p.GetValue(null, null)
                        : (inst != null ? p.GetValue(inst, null) : null);
                if (v == null)
                {
                    var m = AccessTools.Method(t, prop);
                    if (m != null)
                        v = m.IsStatic ? m.Invoke(null, null) : (inst != null ? m.Invoke(inst, null) : null);
                }
                if (v == null) return -1;
                int i = Convert.ToInt32(v);
                return (i == 0 || i == 1) ? i : -1;
            }
            catch { return -1; }
        }

        public static int OfHealth(object hh)
        {
            if (hh == null) return -1;
            int t = OfObj(Get(hh, "data"));
            if (t >= 0) return t;
            object unit = Get(hh, "unit");
            t = OfObj(unit);
            if (t >= 0) return t;
            if (unit != null)
            {
                t = OfObj(Get(unit, "data"));
                if (t >= 0) return t;
            }
            return -1;
        }

        public static int OfUnit(object unit)
        {
            if (unit == null) return -1;
            int t = OfObj(unit);
            if (t >= 0) return t;
            t = OfObj(Get(unit, "data"));
            if (t >= 0) return t;
            var hh = Get(unit, "healthHandler");
            if (hh != null) return OfHealth(hh);
            return -1;
        }

        static int OfObj(object o)
        {
            if (o == null) return -1;
            foreach (var name in new[] { "team", "Team", "m_team", "TeamColor", "teamID", "TeamID", "m_Team" })
            {
                try
                {
                    var f = AccessTools.Field(o.GetType(), name);
                    if (f == null) continue;
                    var v = f.GetValue(o);
                    if (v == null) continue;
                    int i = Convert.ToInt32(v);
                    if (i == 0 || i == 1) return i;
                }
                catch { }
            }
            return -1;
        }

        static object Get(object o, string field)
        {
            if (o == null) return null;
            var f = AccessTools.Field(o.GetType(), field);
            return f != null ? f.GetValue(o) : null;
        }

        public static void ForceDie(object hh)
        {
            if (hh == null) return;
            try
            {
                var f = AccessTools.Field(hh.GetType(), "isInvulnerable");
                if (f != null && f.FieldType == typeof(bool)) f.SetValue(hh, false);
            }
            catch { }
            try
            {
                AccessTools.Method(hh.GetType(), "SetInvulnerable", new[] { typeof(bool) })
                    ?.Invoke(hh, new object[] { false });
            }
            catch { }
            foreach (var m in hh.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (m.Name != "Die") continue;
                try
                {
                    var p = m.GetParameters();
                    if (p.Length == 0) { m.Invoke(hh, null); return; }
                    if (p.Length == 1 && p[0].ParameterType == typeof(bool))
                    { m.Invoke(hh, new object[] { true }); return; }
                }
                catch { }
            }
        }
    }

    // =================== ACTIONS ===================
    internal static class Actions
    {
        // Gecachte Einheitenliste, um FindObjectsOfType zu vermeiden
        internal static List<Component> AllUnits = new List<Component>();

        public static void RegisterUnit(Component unit)
        {
            if (unit == null) return;
            try { if (unit.gameObject == null) return; } catch { return; }
            // prune dead refs occasionally
            if (AllUnits.Count > 200)
            {
                AllUnits.RemoveAll(u => u == null);
            }
            if (!AllUnits.Contains(unit))
                AllUnits.Add(unit);
        }

        internal static IEnumerable<Component> Units()
        {
            for (int i = AllUnits.Count - 1; i >= 0; i--)
            {
                var u = AllUnits[i];
                if (u == null) { AllUnits.RemoveAt(i); continue; }
                yield return u;
            }
        }

        public static int ForceBudget(int amount)
        {
            int hits = 0;
            foreach (var name in new[]
            {
                "Landfall.TABS.Budget.Wallets.CampaignWallet",
                "Landfall.TABS.Budget.Wallets.LocalMultiplayerWallet",
                "Landfall.TABS.Budget.Wallets.SandboxWallet",
                "Landfall.TABS.Budget.BattleBudget",
                "CampaignWallet", "LocalMultiplayerWallet", "SandboxWallet", "BattleBudget"
            })
            {
                var t = AccessTools.TypeByName(name);
                if (t == null || !typeof(UnityEngine.Object).IsAssignableFrom(t)) continue;
                UnityEngine.Object[] arr;
                try { arr = Resources.FindObjectsOfTypeAll(t); } catch { continue; }
                foreach (var o in arr)
                {
                    if (o == null) continue;
                    hits += Set(o, "m_InfBudget", true);
                    hits += Set(o, "m_budget", amount);
                    hits += Set(o, "m_maxBudget", amount);
                }
            }
            return hits;
        }

        public static int Heal(int team)
        {
            int n = 0;
            foreach (var u in Units())
            {
                if (Teams.OfUnit(u) != team) continue;
                var hh = HH(u);
                if (hh == null) continue;
                try
                {
                    float max = -1f;
                    var pMax = AccessTools.Property(hh.GetType(), "MaxHealth");
                    var pCur = AccessTools.Property(hh.GetType(), "CurrentHealth");
                    if (pMax != null) max = Convert.ToSingle(pMax.GetValue(hh, null));
                    if (max > 0f && pCur != null && pCur.CanWrite)
                    { pCur.SetValue(hh, max, null); }
                    else
                    {
                        object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? (object)hh;
                        if (data != null)
                        {
                            var dt = data.GetType();
                            foreach (var name in new[] { "maxHealth", "MaxHealth", "maxHP", "m_maxHealth" })
                            {
                                var f = AccessTools.Field(dt, name);
                                if (f != null && (f.FieldType == typeof(float) || f.FieldType == typeof(int)))
                                { max = Convert.ToSingle(f.GetValue(data)); break; }
                            }
                            if (max < 1f) max = 100f;
                            foreach (var name in new[] { "health", "Health", "currentHealth", "m_health" })
                            {
                                var f = AccessTools.Field(dt, name);
                                if (f != null && f.FieldType == typeof(float)) { f.SetValue(data, max); break; }
                                if (f != null && f.FieldType == typeof(int)) { f.SetValue(data, (int)max); break; }
                            }
                            var dead = AccessTools.Field(dt, "dead");
                            if (dead != null && dead.FieldType == typeof(bool)) dead.SetValue(data, false);
                        }
                    }
                    AccessTools.Method(hh.GetType(), "SetInvulnerable", new[] { typeof(bool) })
                        ?.Invoke(hh, new object[] { Plugin.GodMode });
                }
                catch { }
                SetBool(Get(u, "data") ?? (object)u, "dead", false);
                n++;
            }
            return n;
        }


        public static void MaintainGod()
        {
            int mine = Teams.MineCached();
            if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
            if (mine != 0 && mine != 1) mine = 0;
            // Never FindObjectsOfType here — freezes main thread. Units register via Start hooks only.
            if (AllUnits.Count == 0) return;
            foreach (var u in Units())
            {
                if (u == null) continue;
                if (Teams.OfUnit(u) != mine) continue;
                var hh = HH(u);
                if (hh == null) continue;
                try
                {
                    object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? (object)hh;
                    float max = 5000f;
                    foreach (var name in new[] { "maxHealth", "MaxHealth", "maxHP", "m_maxHealth" })
                    {
                        var f = AccessTools.Field(data.GetType(), name);
                        if (f != null && (f.FieldType == typeof(float) || f.FieldType == typeof(int)))
                        { max = Convert.ToSingle(f.GetValue(data)); break; }
                    }
                    if (max < 1f) max = 5000f;
                    foreach (var name in new[] { "health", "Health", "currentHealth", "m_health" })
                    {
                        var f = AccessTools.Field(data.GetType(), name);
                        if (f != null && f.FieldType == typeof(float)) f.SetValue(data, max);
                        else if (f != null && f.FieldType == typeof(int)) f.SetValue(data, (int)max);
                    }
                    var dead = AccessTools.Field(data.GetType(), "dead");
                    if (dead != null && dead.FieldType == typeof(bool)) dead.SetValue(data, false);
                    AccessTools.Method(hh.GetType(), "SetInvulnerable", new[] { typeof(bool) })
                        ?.Invoke(hh, new object[] { true });
                    var inv = AccessTools.Field(hh.GetType(), "isInvulnerable");
                    if (inv != null && inv.FieldType == typeof(bool)) inv.SetValue(hh, true);
                }
                catch { }
            }
        }

        /// <summary>Event: one-shot unit list refresh (no timer).</summary>
        public static void RefreshUnitsEvent()
        {
            try
            {
                var ut = AccessTools.TypeByName("Landfall.TABS.Unit") ?? AccessTools.TypeByName("Unit");
                if (ut == null) return;
                AllUnits.Clear();
                foreach (var o in UnityEngine.Object.FindObjectsOfType(ut))
                {
                    var c = o as Component;
                    if (c != null) RegisterUnit(c);
                }
            }
            catch { }
        }

        /// <summary>Kill only the opposite team of Plugin.LocalTeam (manual RED/BLUE).</summary>
        public static int KillEnemies()
        {
            int myTeam = Plugin.LocalTeam;
            if (myTeam != 0 && myTeam != 1) myTeam = 0;
            int enemy = myTeam == 0 ? 1 : 0;
            int n = 0;
            foreach (var u in Units())
            {
                if (u == null) continue;
                int ut = Teams.OfUnit(u);
                if (ut != enemy) continue; // ONLY enemies
                var hh = HH(u);
                if (hh == null) continue;
                try
                {
                    object data = AccessTools.Field(hh.GetType(), "data")?.GetValue(hh) ?? (object)hh;
                    foreach (var name in new[] { "health", "Health", "currentHealth", "m_health" })
                    {
                        var f = AccessTools.Field(data.GetType(), name);
                        if (f != null && f.FieldType == typeof(float)) f.SetValue(data, 0f);
                        else if (f != null && f.FieldType == typeof(int)) f.SetValue(data, 0);
                    }
                    var dead = AccessTools.Field(data.GetType(), "dead");
                    if (dead != null && dead.FieldType == typeof(bool)) dead.SetValue(data, true);
                }
                catch { }
                Teams.ForceDie(hh);
                SetBool(Get(u, "data") ?? (object)u, "dead", true);
                n++;
            }
            return n;
        }

        public static int Kill(int myTeam) => KillEnemies();

        public static int TeleportAlliesToEnemies(int myTeam)
        {
            if (myTeam != 0 && myTeam != 1) return 0;
            var allies = new List<Component>();
            var enemies = new List<Component>();

            foreach (var u in Units())
            {
                int t = Teams.OfUnit(u);
                if (t == myTeam) allies.Add(u);
                else if (t == 0 || t == 1) enemies.Add(u);
            }

            if (enemies.Count == 0) return 0;

            int tpCount = 0;
            foreach (var ally in allies)
            {
                float bestDist = float.MaxValue;
                Component bestEnemy = null;
                Vector3 allyPos = ally.transform.position;
                foreach (var enemy in enemies)
                {
                    if (enemy == null || enemy.transform == null) continue;
                    float d = Vector3.Distance(allyPos, enemy.transform.position);
                    if (d < bestDist) { bestDist = d; bestEnemy = enemy; }
                }
                if (bestEnemy != null)
                {
                    Vector3 targetPos = bestEnemy.transform.position + Vector3.up * 3.5f;
                    ally.transform.position = targetPos;

                    Rigidbody[] bodies = ally.GetComponentsInChildren<Rigidbody>(true);
                    foreach (var rb in bodies)
                    {
                        if (rb == null) continue;
                        rb.velocity = Vector3.zero;
                        rb.angularVelocity = Vector3.zero;
                    }
                    tpCount++;
                }
            }
            return tpCount;
        }

        public static void ApplyTeamBuffs()
        {
            int myTeam = Teams.MineCached();
            if (myTeam != 0 && myTeam != 1) return;

            foreach (var u in Units())
            {
                if (Teams.OfUnit(u) != myTeam) continue;
                ApplyBuffToUnit(u);
            }
        }

        public static void ApplyBuffToUnit(Component u)
        {
            if (u == null) return;
            int mine = Teams.MineCached();
            if (mine != 0 && mine != 1) mine = Plugin.LocalTeam;
            if (Teams.OfUnit(u) != mine) return;
            try { CombatMod.ApplyUnitEffectsOnce(u); } catch { }
        }

        static Component HH(Component u)
        {
            var t = AccessTools.TypeByName("HealthHandler");
            if (t == null) return null;
            return (u.GetComponent(t) as Component) ?? (u.GetComponentInChildren(t) as Component);
        }

        static object Get(object o, string field)
        {
            if (o == null) return null;
            var f = AccessTools.Field(o.GetType(), field);
            return f != null ? f.GetValue(o) : null;
        }

        static int Set(object o, string field, object value)
        {
            var f = AccessTools.Field(o.GetType(), field);
            if (f == null) return 0;
            try
            {
                if (f.FieldType == typeof(bool) && value is bool) { f.SetValue(o, value); return 1; }
                if (f.FieldType == typeof(int) && value is int) { f.SetValue(o, value); return 1; }
            }
            catch { }
            return 0;
        }

        static void SetField(object o, string name, float value)
        {
            if (o == null) return;
            var f = AccessTools.Field(o.GetType(), name);
            if (f != null && f.FieldType == typeof(float))
                try { f.SetValue(o, value); } catch { }
        }

        static void InvokeF(object o, string m, float v)
        {
            try
            {
                var mi = AccessTools.Method(o.GetType(), m, new[] { typeof(float) });
                if (mi != null) mi.Invoke(o, new object[] { v });
            }
            catch { }
        }

        static void SetBool(object o, string field, bool v)
        {
            var f = AccessTools.Field(o.GetType(), field);
            if (f != null && f.FieldType == typeof(bool))
                try { f.SetValue(o, v); } catch { }
        }
    }

    /// <summary>
    /// Button-only skin, applied in small batches per frame so Windows never shows "not responding".
    /// Shows a simple loading bar while working.
    /// </summary>
    /// <summary>
    /// Event-driven button skin: Harmony OnEnable on UI.Button.
    /// No full-scene scans, no freeze. Theme change only updates colors for next OnEnable + light pass.
    /// </summary>
    internal static class GameUiSkin
    {
        static bool _hooked;
        static Type _btnType;

        // FIX (Batch-Rescan statt "wartet aufs naechste OnEnable"):
        // Vorher wurden nur NEU aktivierte Buttons geskinnt (PostButtonEnable-Hook).
        // Bereits sichtbare Buttons blieben ungefaerbt, bis der Spieler das jeweilige
        // Spiel-Menue schloss/wieder oeffnete. Jetzt: ein einmaliger
        // FindObjectsOfType-Scan pro Rescan-Anfrage, aber die eigentliche Styling-
        // Arbeit (Reflection pro Button) laeuft ueber mehrere Frames verteilt via
        // Coroutine -> kein Freeze, kein "not responding".
        static int _total, _done;
        public static bool   IsBusy      => false;
        public static string PercentText => _total > 0 ? (_done * 100 / _total) + "% (" + _done + "/" + _total + ")" : "0%";

        public static void Install(Harmony h)
        {
            if (_hooked) return;
            try
            {
                var tBtn = AccessTools.TypeByName("UnityEngine.UI.Button");
                if (tBtn == null) return;
                _btnType = tBtn;
                var onEnable = AccessTools.Method(tBtn, "OnEnable");
                if (onEnable != null)
                {
                    h.Patch(onEnable, postfix: new HarmonyMethod(typeof(GameUiSkin), nameof(PostButtonEnable)));
                    _hooked = true;
                }
            }
            catch { }
        }

        public static void PostButtonEnable(object __instance)
        {
            if (!Plugin.SkinGameUi) return;
            try { StyleOne(__instance as Component); } catch { }
        }

        public static void RequestRefresh() => ApplyThemeLive();

        public static void Tick() { }

        /// <summary>Startet/erneuert den gebatchten Rescan aller aktuell existierenden Game-Buttons.
        /// FIX: kein Scan, solange schon einer laeuft -> verhindert Stapel-Freezes bei Spam-Klicks.</summary>
        public static void RequestRescan(MonoBehaviour host)
        {
            if (_btnType == null) _btnType = AccessTools.TypeByName("UnityEngine.UI.Button");
            if (_btnType == null || !Plugin.SkinGameUi) return;
            UnityEngine.Object[] all = null;
            try { all = UnityEngine.Object.FindObjectsOfType(_btnType); } catch { }
            _total = all != null ? all.Length : 0;
            _done = 0;
            if (all == null) return;
            foreach (var o in all)
            {
                var c = o as Component;
                if (c != null) { try { StyleOne(c); } catch { } }
                _done++;
            }
        }

        /// <summary>Zeichnet den %-Ladebalken unten links, solange RequestRescan laeuft.</summary>
        public static void DrawLoading() { }

        /// <summary>Theme click: nur Flag setzen. Fuer echten Rescan siehe RequestRescan(host).</summary>
        public static void ApplyThemeLive()
        {
            Plugin.SkinGameUi = true;
            // Existing buttons keep old colors until they re-OnEnable (open/close menu)
            // OR until RequestRescan(host) is called explicitly.
        }

        // FIX: Reflection-Lookups gecacht statt bei JEDEM Button-Enable-Event neu
        // gesucht -> wenn ein Spiel-Button ein Untermenu mit vielen Buttons auf
        // einen Schlag aktiviert, feuern alle OnEnable-Events im selben Frame.
        // Ohne Cache war das vorher pro Button ~5 AccessTools-Lookups -> Spike/Lag.
        static readonly Dictionary<Type, PropertyInfo> _pTargetGraphic = new Dictionary<Type, PropertyInfo>();
        static readonly Dictionary<Type, PropertyInfo> _pColors       = new Dictionary<Type, PropertyInfo>();
        static readonly Dictionary<Type, PropertyInfo> _pGraphicColor = new Dictionary<Type, PropertyInfo>();
        static readonly Dictionary<Type, PropertyInfo> _pTextColor    = new Dictionary<Type, PropertyInfo>();

        static PropertyInfo CachedProp(Dictionary<Type, PropertyInfo> cache, Type t, string name)
        {
            if (t == null) return null;
            if (cache.TryGetValue(t, out var p)) return p;
            p = AccessTools.Property(t, name);
            cache[t] = p; // auch null cachen -> kein wiederholter Fehlschlags-Lookup
            return p;
        }

        static void StyleOne(Component btn)
        {
            if (btn == null) return;
            var btnType = btn.GetType();
            var normal = BtnNormal();
            var hi = Accent();
            var pressed = new Color(hi.r * 0.75f, hi.g * 0.45f, hi.b * 0.6f, 1f);
            SetButtonColors(btnType, btn, normal, hi, pressed);
            try
            {
                var pTg = CachedProp(_pTargetGraphic, btnType, "targetGraphic");
                if (pTg != null)
                {
                    var g = pTg.GetValue(btn, null) as Component;
                    if (g != null)
                    {
                        var rt = g.GetComponent<RectTransform>();
                        if (rt != null)
                        {
                            var r = rt.rect;
                            if (Mathf.Abs(r.width * r.height) > 80000f) return;
                        }
                        var pc = CachedProp(_pGraphicColor, g.GetType(), "color");
                        if (pc != null && pc.PropertyType == typeof(Color))
                            pc.SetValue(g, normal, null);
                    }
                }
            }
            catch { }
            TintChildTexts(btn.transform, new Color(1f, 0.95f, 0.98f, 1f));
        }

        static Color Accent()
        {
            switch (Plugin.GuiTheme)
            {
                case 1: return new Color(0.75f, 0.90f, 1f, 1f);   // Frost
                case 2: return new Color(0.95f, 0.95f, 0.98f, 1f); // Black
                case 3: return new Color(0.35f, 0.90f, 1f, 1f);   // Cyan
                case 4: return new Color(0.45f, 1f, 0.30f, 1f);   // Toxic
                case 5: return Color.HSVToRGB(Mathf.Repeat(Time.unscaledTime * 0.12f, 1f), 0.80f, 1f); // Rainbow
                case 6: return Plugin.CustomGuiAccent;
                default: return new Color(1f, 0.55f, 0.80f, 1f);  // Hellpink
            }
        }

        static Color BtnNormal()
        {
            switch (Plugin.GuiTheme)
            {
                case 1: return new Color(0.22f, 0.32f, 0.42f, 0.98f); // Frost
                case 2: return new Color(0.06f, 0.06f, 0.07f, 0.98f); // Black
                case 3: return new Color(0.08f, 0.20f, 0.26f, 0.98f); // Cyan
                case 4: return new Color(0.06f, 0.22f, 0.08f, 0.98f); // Toxic
                case 5: return new Color(0.10f, 0.05f, 0.16f, 0.98f); // Rainbow
                case 6: return Plugin.CustomGuiButton;
                default: return new Color(0.50f, 0.12f, 0.30f, 0.98f); // Hellpink
            }
        }

        static void SetButtonColors(Type btnType, Component btn, Color normal, Color highlight, Color pressed)
        {
            try
            {
                var p = CachedProp(_pColors, btnType, "colors");
                if (p == null) return;
                object block = p.GetValue(btn, null);
                if (block == null) return;
                var t = block.GetType();
                void setCol(string name, Color c)
                {
                    var key = t.FullName + "." + name;
                    MemberInfo m;
                    if (!_colorBlockMemberByKey.TryGetValue(key, out m))
                    {
                        m = (MemberInfo)AccessTools.Property(t, name) ?? AccessTools.Field(t, name);
                        _colorBlockMemberByKey[key] = m; // auch null cachen
                    }
                    if (m is PropertyInfo pr) pr.SetValue(block, c, null);
                    else if (m is FieldInfo f) f.SetValue(block, c);
                }
                setCol("normalColor", normal);
                setCol("highlightedColor", highlight);
                setCol("pressedColor", pressed);
                setCol("selectedColor", highlight);
                setCol("disabledColor", new Color(0.2f, 0.2f, 0.22f, 0.5f));
                p.SetValue(btn, block, null);
            }
            catch { }
        }
        static readonly Dictionary<string, MemberInfo> _colorBlockMemberByKey = new Dictionary<string, MemberInfo>();

        static Type[] _textTypeCache; // "UnityEngine.UI.Text" / TMP-Typen einmalig aufgeloest statt pro Aufruf per String

        static void TintChildTexts(Transform root, Color c)
        {
            if (root == null) return;
            if (_textTypeCache == null)
            {
                var names = new[] { "UnityEngine.UI.Text", "TMPro.TextMeshProUGUI", "TMPro.TMP_Text" };
                var list = new List<Type>(names.Length);
                foreach (var n in names) { var tt = AccessTools.TypeByName(n); if (tt != null) list.Add(tt); }
                _textTypeCache = list.ToArray();
            }
            for (int i = 0; i < root.childCount; i++)
            {
                var ch = root.GetChild(i);
                TintTextOn(ch);
                for (int j = 0; j < ch.childCount; j++)
                    TintTextOn(ch.GetChild(j));
            }
            void TintTextOn(Transform tr)
            {
                foreach (var tt in _textTypeCache)
                {
                    var comp = tr.GetComponent(tt) as Component;
                    if (comp == null) continue;
                    var pc = CachedProp(_pTextColor, comp.GetType(), "color");
                    if (pc != null && pc.PropertyType == typeof(Color))
                        try { pc.SetValue(comp, c, null); } catch { }
                }
            }
        }
    }

    internal static class Gfx
    {
        public static void ApplyMedium()
        {
            try
            {
                int levels = QualitySettings.names != null ? QualitySettings.names.Length : 3;
                int mid = Mathf.Clamp(levels / 2, 0, levels - 1);
                QualitySettings.SetQualityLevel(mid, true);
                QualitySettings.shadows = ShadowQuality.HardOnly;
                QualitySettings.shadowResolution = ShadowResolution.Medium;
                QualitySettings.shadowDistance = 80f;
                QualitySettings.antiAliasing = 2;
                QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;
                QualitySettings.softParticles = false;
                QualitySettings.pixelLightCount = 2;
                QualitySettings.lodBias = 1f;
            }
            catch { }
            ApplyFpsVsync();
        }

        public static void ApplyUltra()
        {
            try
            {
                int levels = QualitySettings.names != null ? QualitySettings.names.Length : 1;
                QualitySettings.SetQualityLevel(Mathf.Max(0, levels - 1), true);
                QualitySettings.shadows = ShadowQuality.All;
                QualitySettings.shadowResolution = ShadowResolution.VeryHigh;
                QualitySettings.shadowDistance = Plugin.GfxShadowDist;
                QualitySettings.antiAliasing = 8;
                QualitySettings.anisotropicFiltering = AnisotropicFiltering.ForceEnable;
                QualitySettings.softParticles = true;
                QualitySettings.particleRaycastBudget = 4096;
                QualitySettings.pixelLightCount = 8;
                try
                {
                    var mip = typeof(QualitySettings).GetProperty("globalTextureMipmapLimit")
                           ?? typeof(QualitySettings).GetProperty("masterTextureLimit");
                    if (mip != null) mip.SetValue(null, 0, null);
                }
                catch { }
                QualitySettings.lodBias = 2.5f;
                QualitySettings.maximumLODLevel = 0;
            }
            catch { }
            try
            {
                var cam = Camera.main;
                if (cam != null)
                {
                    cam.allowHDR = true;
                    cam.allowMSAA = true;
                    cam.depthTextureMode = DepthTextureMode.Depth | DepthTextureMode.DepthNormals;
                    cam.farClipPlane = Mathf.Max(cam.farClipPlane, 600f);
                }
            }
            catch { }
            ApplyFpsVsync();
        }

        public static void ApplyRealistic() => ApplyUltra();

        public static void ApplyFpsVsync()
        {
            try
            {
                QualitySettings.vSyncCount = Plugin.VSync ? 1 : 0;
                Application.targetFrameRate = Plugin.TargetFps <= 0 ? -1 : Plugin.TargetFps;
            }
            catch { }
        }

        public static void ApplyDefault()
        {
            try { QualitySettings.SetQualityLevel(QualitySettings.GetQualityLevel(), true); } catch { }
        }
    }

}
