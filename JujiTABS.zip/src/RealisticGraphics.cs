using System;
using System.Reflection;
using UnityEngine;
using HarmonyLib;

namespace JujiTABS
{
    internal static class RealisticGraphics
    {
        // ─── Einstellungen ────────────────────────────────────────────────────────
        public static bool  Enabled      = false;
        public static int   Preset       = 1;     // 0=Low 1=Medium 2=High 3=Ultra
        public static float ShadowDist   = 150f;
        public static float AmbientMult  = 1.0f;
        public static float Vignette     = 0.25f;
        public static float Bloom        = 0.50f;
        public static float Contrast     = 1.15f;
        public static float Saturation   = 1.20f;
        public static float Brightness   = 1.00f;
        public static bool  FogEnabled   = false;
        public static bool  Sharpen      = false;
        public static int   TargetFps    = 60;
        public static bool  VSync        = true;

        static readonly string[] PresetNames = { "Low","Medium","High","Ultra" };
        public static string PresetName => PresetNames[Mathf.Clamp(Preset, 0, 3)];

        // Vignette-Textur (IMGUI-Overlay, kein Shader nötig)
        static Texture2D _vigTex;
        static float     _vigBuiltFor = -1f;

        // FIX: LightShadowResolution ist im Unity-Stub nicht immer exportiert.
        // Deshalb via Reflection cachen → compiliert auf JEDEM Unity-Stub.
        static PropertyInfo _lightShadowResProp;
        static object       _lightShadowResVH;   // VeryHigh = enum-Wert 3

        static void EnsureLightRefl()
        {
            if (_lightShadowResProp != null) return;
            try
            {
                _lightShadowResProp = typeof(Light).GetProperty("shadowResolution");
                if (_lightShadowResProp != null)
                    _lightShadowResVH = Enum.ToObject(_lightShadowResProp.PropertyType, 3);
            }
            catch { }
        }

        // PostProcessing v2 Types (optional, falls TABS PPv2 hat)
        static bool   _ppChecked;
        static Type   _tPPVolume, _tBloom, _tColorGrade, _tVig;

        // ─── APPLY ────────────────────────────────────────────────────────────────
        public static void Apply()
        {
            if (!Enabled) return;
            ApplyQuality();
            ApplyCamera();
            ApplyRenderSettings();
            TryPPv2();
        }

        public static void SetEnabled(bool on)
        {
            Enabled = on;
            if (on)  Apply();
            else     Restore();
        }

        static void ApplyQuality()
        {
            try
            {
                switch (Preset)
                {
                    case 0: // Low
                        QualitySettings.shadows          = ShadowQuality.HardOnly;
                        QualitySettings.shadowResolution = ShadowResolution.Low;
                        QualitySettings.shadowDistance   = 60f;
                        QualitySettings.antiAliasing     = 0;
                        break;
                    case 1: // Medium
                        QualitySettings.shadows          = ShadowQuality.All;
                        QualitySettings.shadowResolution = ShadowResolution.Medium;
                        QualitySettings.shadowDistance   = ShadowDist;
                        QualitySettings.antiAliasing     = 2;
                        QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;
                        break;
                    case 2: // High
                        QualitySettings.shadows          = ShadowQuality.All;
                        QualitySettings.shadowResolution = ShadowResolution.High;
                        QualitySettings.shadowDistance   = ShadowDist;
                        QualitySettings.shadowCascades   = 4;
                        QualitySettings.antiAliasing     = 4;
                        QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;
                        QualitySettings.lodBias          = 2f;
                        break;
                    case 3: // Ultra
                        QualitySettings.shadows          = ShadowQuality.All;
                        QualitySettings.shadowResolution = ShadowResolution.VeryHigh;
                        QualitySettings.shadowDistance   = ShadowDist;
                        QualitySettings.shadowCascades   = 4;
                        QualitySettings.antiAliasing     = 8;
                        QualitySettings.anisotropicFiltering = AnisotropicFiltering.ForceEnable;
                        QualitySettings.softParticles    = true;
                        QualitySettings.realtimeReflectionProbes = true;
                        QualitySettings.lodBias          = 4f;
                        QualitySettings.maximumLODLevel  = 0;
                        try
                        {
                            var mip = typeof(QualitySettings).GetProperty("globalTextureMipmapLimit")
                                   ?? typeof(QualitySettings).GetProperty("masterTextureLimit");
                            if (mip != null) mip.SetValue(null, 0, null);
                        } catch { }
                        QualitySettings.pixelLightCount = 8;
                        break;
                }
                // FPS / VSync
                QualitySettings.vSyncCount    = VSync ? 1 : 0;
                Application.targetFrameRate   = TargetFps <= 0 ? -1 : TargetFps;
            }
            catch { }

            // Direktionale Lichter verbessern
            try
            {
                foreach (var l in UnityEngine.Object.FindObjectsOfType<Light>())
                {
                    if (l == null || l.type != LightType.Directional) continue;
                    l.shadowStrength   = Mathf.Lerp(0.6f, 0.95f, (float)Preset / 3f);
                    EnsureLightRefl();
                    if (_lightShadowResProp != null && _lightShadowResVH != null)
                        try { _lightShadowResProp.SetValue(l, _lightShadowResVH, null); } catch { }
                    l.shadowBias       = 0.015f;
                    l.shadowNormalBias    = 0.08f;
                    if (Preset >= 2) l.shadows = LightShadows.Soft;
                }
            }
            catch { }
        }

        static void ApplyCamera()
        {
            try
            {
                var cam = Camera.main;
                if (cam == null) return;
                cam.allowHDR   = Preset >= 2;
                cam.allowMSAA  = Preset >= 1;
                cam.farClipPlane = Mathf.Max(cam.farClipPlane, 500f);
                if (Preset >= 3)
                    cam.depthTextureMode = DepthTextureMode.Depth | DepthTextureMode.DepthNormals;
            }
            catch { }
        }

        static void ApplyRenderSettings()
        {
            try
            {
                RenderSettings.ambientIntensity = AmbientMult;
                RenderSettings.fog = FogEnabled;
                if (FogEnabled)
                {
                    RenderSettings.fogMode    = FogMode.ExponentialSquared;
                    RenderSettings.fogDensity = 0.008f;
                    RenderSettings.fogColor   = new Color(0.62f, 0.70f, 0.82f);
                }
            }
            catch { }
        }

        static void Restore()
        {
            try
            {
                QualitySettings.shadowDistance   = 100f;
                QualitySettings.shadowResolution = ShadowResolution.Medium;
                QualitySettings.antiAliasing     = 0;
                var cam = Camera.main;
                if (cam != null) { cam.allowHDR = false; }
            }
            catch { }
        }

        // ─── PostProcessing v2 Injektion ──────────────────────────────────────────
        static void TryPPv2()
        {
            if (!_ppChecked)
            {
                _ppChecked  = true;
                _tPPVolume  = AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.PostProcessVolume");
                _tBloom     = AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.Bloom");
                _tColorGrade= AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.ColorGrading");
                _tVig       = AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.Vignette");
            }
            if (_tPPVolume == null) return;
            try
            {
                // Globales Volume suchen oder erstellen
                object vol = FindOrCreatePPVolume();
                if (vol == null) return;
                var profile = GetPPField(vol, "profile") ?? GetPPProp(vol, "profile");
                if (profile == null) return;

                SetPPEffect(profile, _tBloom, "intensity", Bloom * 3f, "threshold", 0.85f);
                SetPPEffect(profile, _tColorGrade,
                    "contrast",   (Contrast   - 1f) * 100f,
                    "saturation", (Saturation - 1f) * 100f,
                    "brightness", (Brightness - 1f) * 100f);
                SetPPEffect(profile, _tVig, "intensity", Vignette, "smoothness", 0.5f);
            }
            catch { }
        }

        static object FindOrCreatePPVolume()
        {
            if (_tPPVolume == null) return null;
            try
            {
                var all = UnityEngine.Object.FindObjectsOfType(_tPPVolume);
                foreach (var v in all)
                {
                    var isGlobal = AccessTools.Property(v.GetType(), "isGlobal");
                    if (isGlobal != null && (bool)isGlobal.GetValue(v, null)) return v;
                }
                // Kein globales Volume → neu erstellen
                var go = new GameObject("JujiPPVolume");
                UnityEngine.Object.DontDestroyOnLoad(go);
                var vol = go.AddComponent(_tPPVolume);
                AccessTools.Property(vol.GetType(), "isGlobal")?.SetValue(vol, true, null);
                AccessTools.Property(vol.GetType(), "priority")?.SetValue(vol, 99f, null);
                var pt = AccessTools.TypeByName("UnityEngine.Rendering.PostProcessing.PostProcessProfile");
                if (pt != null)
                {
                    var pr = ScriptableObject.CreateInstance(pt);
                    AccessTools.Property(vol.GetType(), "profile")?.SetValue(vol, pr, null);
                }
                return vol;
            }
            catch { return null; }
        }

        static void SetPPEffect(object profile, Type effectType, params object[] nameValues)
        {
            if (effectType == null || profile == null) return;
            try
            {
                var hasM = AccessTools.Method(profile.GetType(), "HasSettings", new[] { typeof(Type) });
                var getM = AccessTools.Method(profile.GetType(), "GetSetting",  new[] { typeof(Type) });
                var addM = AccessTools.Method(profile.GetType(), "AddSettings", new[] { typeof(Type) });
                bool has = hasM != null && (bool)hasM.Invoke(profile, new object[] { effectType });
                object effect = has
                    ? getM?.Invoke(profile, new object[] { effectType })
                    : addM?.Invoke(profile, new object[] { effectType });
                if (effect == null) return;

                // enabled = true
                SetPPParam(effect, effectType, "enabled", Enabled);

                for (int i = 0; i < nameValues.Length - 1; i += 2)
                    SetPPParam(effect, effectType, (string)nameValues[i], nameValues[i + 1]);
            }
            catch { }
        }

        static void SetPPParam(object effect, Type effectType, string fieldName, object val)
        {
            try
            {
                var f = AccessTools.Field(effectType, fieldName);
                if (f == null) return;
                var param = f.GetValue(effect);
                if (param == null) return;
                AccessTools.Field(param.GetType(), "overrideState")?.SetValue(param, true);
                var vf = AccessTools.Field(param.GetType(), "value");
                if (vf != null) vf.SetValue(param, Convert.ChangeType(val, vf.FieldType));
            }
            catch { }
        }

        static object GetPPField(object o, string n)
        { try { return AccessTools.Field(o.GetType(), n)?.GetValue(o); } catch { return null; } }
        static object GetPPProp(object o, string n)
        { try { return AccessTools.Property(o.GetType(), n)?.GetValue(o, null); } catch { return null; } }

        // ─── IMGUI Vignette-Overlay (funktioniert IMMER, kein Shader) ─────────────
        static void BuildVigTex()
        {
            const int S = 128;
            if (_vigTex != null) UnityEngine.Object.Destroy(_vigTex);
            _vigTex = new Texture2D(S, S, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
            var pix = new Color[S * S];
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = (x - S * 0.5f) / (S * 0.5f);
                    float dy = (y - S * 0.5f) / (S * 0.5f);
                    float d  = Mathf.Sqrt(dx * dx + dy * dy);
                    float a  = Mathf.Pow(Mathf.Clamp01((d - 0.45f) / 0.55f), 1.6f);
                    pix[y * S + x] = new Color(0f, 0f, 0f, a);
                }
            _vigTex.SetPixels(pix);
            _vigTex.Apply();
            _vigBuiltFor = Vignette;
        }

        public static void DrawVignetteOverlay()
        {
            if (!Enabled || Vignette < 0.02f) return;
            if (_tPPVolume != null) return; // PPv2 übernimmt
            if (_vigTex == null || Math.Abs(_vigBuiltFor - Vignette) > 0.01f) BuildVigTex();
            Color prev = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, Vignette);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), _vigTex, ScaleMode.StretchToFill);
            GUI.color = prev;
        }

        // ─── GUI für Settings-Tab ─────────────────────────────────────────────────
        public static void DrawSettingsGUI()
        {
            GuiManager.Header("Realistische Grafik");

            // Plugin owns the shared FPS/shadow settings; keep this panel in sync.
            Enabled = GuiManager.Toggle(Enabled, "Realistische Grafik AN");
            Plugin.RealisticGfx = Enabled;

            if (!Enabled)
            {
                GuiManager.Info("Aktiviere um die Einstellungen zu sehen.");
                return;
            }

            GuiManager.Header("Qualitaets-Preset");
            GuiManager.Row(() =>
            {
                for (int i = 0; i < PresetNames.Length; i++)
                {
                    bool active = Preset == i;
                    Color p = GUI.color;
                    GUI.color = active ? GuiManager.Accent : GuiManager.TextDim;
                    if (GUILayout.Button(PresetNames[i]))
                    {
                        Preset = i;
                        Apply();
                    }
                    GUI.color = p;
                }
            });
            GuiManager.Info("Aktiv: " + PresetName);

            GuiManager.Header("Schatten & Reichweite");
            float sd = GuiManager.Slider(Plugin.GfxShadowDist, 30f, 300f,
                                         "Schatten-Distanz", "0");
            if (Math.Abs(sd - Plugin.GfxShadowDist) > 0.5f)
            {
                Plugin.GfxShadowDist = sd;
                ShadowDist = sd;
                ApplyQuality();
            }
            else
            {
                ShadowDist = Plugin.GfxShadowDist;
            }

            GuiManager.Header("Farbkorrektur");
            float nb = GuiManager.Slider(Brightness, 0.5f, 2.0f, "Helligkeit");
            float nc = GuiManager.Slider(Contrast,   0.5f, 2.0f, "Kontrast");
            float ns = GuiManager.Slider(Saturation, 0.0f, 3.0f, "Saettigung");
            if (Math.Abs(nb - Brightness) > 0.01f ||
                Math.Abs(nc - Contrast) > 0.01f ||
                Math.Abs(ns - Saturation) > 0.01f)
            {
                Brightness = nb;
                Contrast = nc;
                Saturation = ns;
                TryPPv2();
            }

            GuiManager.Header("Post-Processing Effekte");
            float nv = GuiManager.Slider(Vignette, 0f, 1f, "Vignette");
            float nl = GuiManager.Slider(Bloom,    0f, 1f, "Bloom / Glow");
            if (Math.Abs(nv - Vignette) > 0.01f ||
                Math.Abs(nl - Bloom) > 0.01f)
            {
                Vignette = nv;
                Bloom = nl;
                TryPPv2();
            }

            GuiManager.Header("Umgebung");
            float ai = GuiManager.Slider(AmbientMult, 0f, 3f, "Ambient Helligkeit");
            if (Math.Abs(ai - AmbientMult) > 0.01f)
            {
                AmbientMult = ai;
                ApplyRenderSettings();
            }
            bool oldFog = FogEnabled;
            FogEnabled = GuiManager.Toggle(FogEnabled, "Atmosphaerischer Nebel");
            if (oldFog != FogEnabled) ApplyRenderSettings();

            GuiManager.Header("Performance");
            bool oldVsync = Plugin.VSync;
            Plugin.VSync = GuiManager.Toggle(Plugin.VSync, "VSync");
            Plugin.TargetFps = GuiManager.SliderInt(
                Plugin.TargetFps, 0, 240, "FPS-Limit  (0 = Unbegrenzt)");
            VSync = Plugin.VSync;
            TargetFps = Plugin.TargetFps;
            if (oldVsync != Plugin.VSync) ApplyQuality();

            if (GuiManager.Button("ALLE EINSTELLUNGEN ANWENDEN"))
            {
                ShadowDist = Plugin.GfxShadowDist;
                Apply();
            }
        }
    }
}
