@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title JujiTABS - Auto Setup + Build + Install
color 0B

echo ========================================
echo   JujiTABS  -  Alles automatisch
echo ========================================
echo.

set "TABS="
if exist "C:\Program Files\Epic Games\TABS\TotallyAccurateBattleSimulator_Data" set "TABS=C:\Program Files\Epic Games\TABS"
if not defined TABS if exist "C:\Program Files\Epic Games\TABS\TotallyAccurateBattleSimulator.exe" set "TABS=C:\Program Files\Epic Games\TABS"
if not defined TABS (
  for %%P in (
    "C:\Program Files\Epic Games\TABS"
    "D:\Program Files\Epic Games\TABS"
    "E:\Program Files\Epic Games\TABS"
    "%ProgramFiles%\Epic Games\TABS"
    "%ProgramFiles(x86)%\Steam\steamapps\common\Totally Accurate Battle Simulator"
    "%ProgramFiles%\Steam\steamapps\common\Totally Accurate Battle Simulator"
    "%USERPROFILE%\SteamLibrary\steamapps\common\Totally Accurate Battle Simulator"
  ) do if exist "%%~P\TotallyAccurateBattleSimulator_Data" set "TABS=%%~P"
)

if not "%~1"=="" (
  if exist "%~1\TotallyAccurateBattleSimulator_Data" set "TABS=%~1"
  if exist "%~dp1TotallyAccurateBattleSimulator_Data" set "TABS=%~dp1"
)

if not defined TABS (
  echo [!] TABS Ordner nicht gefunden.
  pause
  exit /b 1
)
if "%TABS:~-1%"=="\" set "TABS=%TABS:~0,-1%"

echo [1] TABS: %TABS%
set "MANAGED=%TABS%\TotallyAccurateBattleSimulator_Data\Managed"
set "BEP=%TABS%\BepInEx"
set "PLUG=%BEP%\plugins"

echo [2] BepInEx...
if exist "%BEP%\core\BepInEx.dll" goto bep_ok

echo     Nicht gefunden - lade BepInEx 5.4.23.2 win x64...

REM Feste Pfade - KEINE leeren %% Variablen in PowerShell
set "ZIPFILE=%TEMP%\BepInEx_TABS_54232.zip"
if exist "%ZIPFILE%" del /f /q "%ZIPFILE%" >nul 2>&1

echo     Download...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.2/BepInEx_win_x64_5.4.23.2.zip' -OutFile ([System.IO.Path]::Combine($env:TEMP, 'BepInEx_TABS_54232.zip')) -UseBasicParsing"

if not exist "%TEMP%\BepInEx_TABS_54232.zip" (
  echo     [!] Download fehlgeschlagen - versuche curl...
  curl -L -o "%TEMP%\BepInEx_TABS_54232.zip" "https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.2/BepInEx_win_x64_5.4.23.2.zip"
)

if not exist "%TEMP%\BepInEx_TABS_54232.zip" (
  echo [!] Download komplett fehlgeschlagen.
  echo     Lade manuell:
  echo     https://github.com/BepInEx/BepInEx/releases/download/v5.4.23.2/BepInEx_win_x64_5.4.23.2.zip
  echo     Entpacke den Inhalt nach:
  echo     %TABS%
  pause
  exit /b 1
)

for %%A in ("%TEMP%\BepInEx_TABS_54232.zip") do echo     ZIP: %%~zA bytes

echo     Entpacke...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath ([System.IO.Path]::Combine($env:TEMP, 'BepInEx_TABS_54232.zip')) -DestinationPath '%TABS%' -Force"
if not exist "%BEP%\core\BepInEx.dll" (
  tar -xf "%TEMP%\BepInEx_TABS_54232.zip" -C "%TABS%" 2>nul
)

if not exist "%BEP%\core\BepInEx.dll" (
  echo [!] Entpacken fehlgeschlagen. BepInEx\core\BepInEx.dll fehlt.
  dir /b "%TABS%"
  pause
  exit /b 1
)

echo     BepInEx OK. Starte TABS kurz...
start "" "%TABS%\TotallyAccurateBattleSimulator.exe"
timeout /t 14 /nobreak >nul
taskkill /IM TotallyAccurateBattleSimulator.exe /F >nul 2>&1
timeout /t 2 /nobreak >nul

:bep_ok
if not exist "%BEP%\core\BepInEx.dll" (
  echo [!] BepInEx\core\BepInEx.dll fehlt.
  pause
  exit /b 1
)
echo     BepInEx gefunden.

echo [3] Referenzen nach lib\...
if not exist "lib" mkdir lib
copy /Y "%BEP%\core\BepInEx.dll" "lib\" >nul
if exist "%BEP%\core\0Harmony.dll" copy /Y "%BEP%\core\0Harmony.dll" "lib\" >nul
if exist "%MANAGED%\Assembly-CSharp.dll" copy /Y "%MANAGED%\Assembly-CSharp.dll" "lib\" >nul
if exist "%MANAGED%\UnityEngine.dll" copy /Y "%MANAGED%\UnityEngine.dll" "lib\" >nul
if exist "%MANAGED%\UnityEngine.CoreModule.dll" copy /Y "%MANAGED%\UnityEngine.CoreModule.dll" "lib\" >nul
if exist "%MANAGED%\UnityEngine.IMGUIModule.dll" copy /Y "%MANAGED%\UnityEngine.IMGUIModule.dll" "lib\" >nul
if exist "%MANAGED%\UnityEngine.InputLegacyModule.dll" copy /Y "%MANAGED%\UnityEngine.InputLegacyModule.dll" "lib\" >nul
if exist "%MANAGED%\UnityEngine.PhysicsModule.dll" copy /Y "%MANAGED%\UnityEngine.PhysicsModule.dll" "lib\" >nul

if not exist "lib\0Harmony.dll" (
  echo [!] 0Harmony.dll fehlt in BepInEx\core
  dir /b "%BEP%\core\"
  pause
  exit /b 1
)

echo [4] Build...
where dotnet >nul 2>&1
if errorlevel 1 (
  echo [!] dotnet SDK fehlt: https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

dotnet build "%~dp0JujiTABS.csproj" -c Release -v m
if errorlevel 1 (
  echo [!] Build fehlgeschlagen.
  pause
  exit /b 1
)

set "DLL="
for %%F in (
  "%~dp0bin\JujiTABS.dll"
  "%~dp0bin\Release\JujiTABS.dll"
  "%~dp0bin\Release\netstandard2.0\JujiTABS.dll"
) do if exist "%%~F" set "DLL=%%~F"

if not defined DLL (
  echo [!] JujiTABS.dll nicht gefunden.
  dir /s /b "%~dp0bin\*.dll" 2>nul
  pause
  exit /b 1
)

echo [5] Installiere Plugin...
if not exist "%PLUG%" mkdir "%PLUG%"
if exist "%PLUG%\JujiTABS.dll" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%PLUG%\JujiTABS.dll'; $b='%PLUG%\JujiTABS.dll.juji-original'; if (-not (Test-Path $b)) { try { $n=(Get-Item $p).VersionInfo.ProductName; if ($n -notlike '*JujiTABS*') { Copy-Item $p $b -Force } } catch {} }"
)
copy /Y "%DLL%" "%PLUG%\JujiTABS.dll" >nul
echo     -^> %PLUG%\JujiTABS.dll

echo.
echo ========================================
echo   FERTIG  -  Menue: INSERT oder F5
echo ========================================
choice /C YN /M "TABS jetzt starten"
if errorlevel 2 goto end
start "" "%TABS%\TotallyAccurateBattleSimulator.exe"
:end
pause
endlocal
