JujiTABS – externe Mods

1. Lege kompatible BepInEx-.dll-Dateien in diesen Ordner.
2. Öffne JujiTABS und gehe zu MODS.
3. Klicke auf „MODS INSTALLIEREN“.
4. Die Dateien werden in TABS\BepInEx\plugins kopiert. Unterordner werden beibehalten.

JujiTABS.dll kann hier ebenfalls liegen; sie wird beim „Mod beim Start“-Schalter als lokale Version gefunden.
Nur Mods verwenden, die für deine TABS-/BepInEx-Version gebaut wurden.
