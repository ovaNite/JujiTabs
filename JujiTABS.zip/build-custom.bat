@echo off
setlocal EnableExtensions
title JujiTABS - CUSTOM GUI BUILD
cd /d "%~dp0"

echo ==========================================
echo        JUJITABS CUSTOM GUI BUILD
echo ==========================================
echo.

where dotnet >nul 2>&1
if errorlevel 1 (
    echo [ERROR] .NET SDK nicht gefunden.
    pause
    exit /b 1
)

if not exist "JujiTABS.csproj" (
    echo [ERROR] JujiTABS.csproj fehlt.
    pause
    exit /b 2
)

echo [SYNC] Repository-Grafiken aktualisieren...
powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\sync-repo-assets.ps1"
if errorlevel 1 goto FAIL

if not exist "JujiTABSLauncher.csproj" (
    echo [ERROR] JujiTABSLauncher.csproj fehlt.
    pause
    exit /b 3
)

if not exist "Launcher\Program.cs" (
    echo [ERROR] Launcher\Program.cs fehlt.
    pause
    exit /b 4
)

if not exist "assets\build_commit.txt" (
    echo [ERROR] assets\build_commit.txt fehlt.
    pause
    exit /b 5
)
for %%F in (Background.png header_preview.png sidebar_preview.gif game_preview.png news_panel.png) do (
    if not exist "assets\%%F" (
        echo [ERROR] assets\%%F fehlt.
        pause
        exit /b 5
    )
)

echo [1/6] Plugin bauen...
dotnet build "JujiTABS.csproj" -c Release
if errorlevel 1 goto FAIL

if not exist "bin\JujiTABS.dll" (
    echo [ERROR] bin\JujiTABS.dll wurde nicht erzeugt.
    goto FAIL
)

echo.
echo [2/6] Launcher restore...
dotnet restore "JujiTABSLauncher.csproj"
if errorlevel 1 goto FAIL

echo.
echo [3/6] Launcher build...
dotnet build "JujiTABSLauncher.csproj" -c Release --no-restore
if errorlevel 1 goto FAIL

echo.
echo [4/6] Single-file EXE...
if exist "release" rmdir /s /q "release"

dotnet publish "JujiTABSLauncher.csproj" ^
    -c Release ^
    -r win-x64 ^
    --self-contained true ^
    -p:PublishSingleFile=true ^
    -p:IncludeNativeLibrariesForSelfExtract=true ^
    -p:EnableCompressionInSingleFile=true ^
    -p:PublishTrimmed=false ^
    -p:DebugType=None ^
    -p:DebugSymbols=false ^
    -o "release"
if errorlevel 1 goto FAIL

if not exist "release\JujiTABS.exe" goto FAIL

echo.
echo [5/6] Verify...
for %%A in ("release\JujiTABS.exe") do echo EXE-Groesse: %%~zA Bytes

echo.
echo [6/6] Fertig.
echo ==========================================
echo BUILD ERFOLGREICH
echo ==========================================
echo.
echo release\JujiTABS.exe
echo.
start "" explorer.exe "%CD%\release"
pause
exit /b 0

:FAIL
echo.
echo ==========================================
echo BUILD FEHLER
echo ==========================================
echo.
pause
exit /b 9
