using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JujiTABSLauncher;

internal static class Program
{
    private const string CurrentPluginVersion = "2.11.1";
    private const string GitHubRepoApi = "https://api.github.com/repos/ovaNite/JujiTabs";

    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.Run(new JujiWindow());
    }

    internal enum Tab
    {
        Home,
        Mods,
        Settings,
        Update,
        History,
        About
    }

    private enum WeatherKind
    {
        Clear,
        Rain,
        Snow
    }

    internal sealed class JujiWindow : Form
    {
        private static readonly string[] TabsProcessNames =
        {
            "TotallyAccurateBattleSimulator",
            "TotallyAccurateBattleSimulator-Win64-Shipping",
            "TABS"
        };

        private readonly HttpClient _http = new();
        private readonly System.Windows.Forms.Timer _animationTimer;
        private bool _animationDirty;
        private readonly System.Windows.Forms.Timer _updateTimer;
        private readonly SemaphoreSlim _githubGate = new(1, 1);

        private readonly Font _fontSmall = new("Segoe UI", 8.5f);
        private readonly Font _font = new("Segoe UI", 9.2f);
        private readonly Font _fontBold = new("Segoe UI", 10f, FontStyle.Bold);
        private readonly Font _fontTitle = new("Segoe UI", 13f, FontStyle.Bold);
        private readonly Font _fontHero = new("Segoe UI", 16f, FontStyle.Bold);
        private readonly Font _fontHuge = new("Segoe UI", 20f, FontStyle.Bold);

        private readonly Bitmap? _background;
        private readonly List<PreviewSequence> _backgroundSequences = new();
        private int _backgroundSequenceIndex;
        private int _backgroundFrameIndex;
        private DateTime _nextBackgroundSwap = DateTime.MinValue;
        private Bitmap? _backgroundFrameCache;
        private Bitmap? _backgroundCache;
        private Size _backgroundCacheSize;
        private readonly Bitmap? _headerPreview;
        private readonly List<PreviewSequence> _sidebarSequences = new();
        private int _sidebarSequenceIndex;
        private int _sidebarFrameIndex;
        private DateTime _nextSidebarSwap = DateTime.MinValue;
        private readonly List<PreviewSequence> _gamePreviewSequences = new();
        private int _gamePreviewIndex;
        private int _previousPreviewIndex;
        private float _gamePreviewFade = 1f;
        private DateTime _previewFadeStarted = DateTime.MinValue;
        private const int PreviewTransitionMs = 320;
        private DateTime _nextPreviewSwap = DateTime.MinValue;
        private Bitmap? _gamePreviewCurrent;
        private Bitmap? _gamePreviewPrevious;
        private DateTime _nextWeatherRefresh = DateTime.MinValue;
        private WeatherKind _weatherKind = WeatherKind.Clear;
        private readonly Bitmap? _newsPanel;
        private string _weatherLabel = "";

        private readonly LauncherSettings _settings;
        private readonly List<LocalVersion> _localVersions = new();
        private readonly List<string> _externalMods = new();
        private string? _selectedExternalMod;
        private readonly List<RepoUpdate> _repoUpdates = new();
        private CancellationTokenSource _shutdown = new();

        private Process? _tabsProcess;
        private string? _tabsExe;
        private Tab _activeTab = Tab.Home;
        private string _tabsStatus = "TABS NICHT ERKANNT";
        private string _installedText = "Nicht installiert";
        private string _updateStatus = "PRÜFE...";
        private string _remoteCommit = "—";
        private string _message = "Bereit.";
        private float _time;
        private bool _busy;

        private Rectangle _minRect, _closeRect;
        private Rectangle _launchRect, _removeRect, _updateRect, _folderRect;
        private Rectangle _installLatestRect, _restoreRect, _installFolderRect, _openModsRect, _injectSelectedRect;
        private Rectangle _languageRect, _argsRect, _windowModeRect, _resolutionRect, _autoInstallRect, _priorityRect, _exeRect;
        private Rectangle[] _tabRects = new Rectangle[6];
        private Rectangle _backRect;
        private readonly bool[] _hover = new bool[40];
        private readonly float[] _hoverAnim = new float[40];
        private int _pressedIndex = -1;

        private sealed record RepoUpdate(string Version, string Date, string Message, string Path, string Sha);
        private sealed record LocalVersion(string Version, string Path, DateTime Timestamp);
        private sealed class PreviewSequence : IDisposable
        {
            public readonly List<Bitmap> Frames = new();
            public readonly List<int> DurationsMs = new();
            public void Dispose() { foreach (var b in Frames) b.Dispose(); Frames.Clear(); DurationsMs.Clear(); }
        }
        private sealed class LauncherSettings
        {
            public string Language { get; set; } = "DE";
            public string TabsExe { get; set; } = "";
            public string LaunchArgs { get; set; } = "";
            public string WindowMode { get; set; } = "Windowed";
            public string Resolution { get; set; } = "1920x1080";
            public bool AutoInstallMod { get; set; } = false;
            public string SelectedMod { get; set; } = "";
            public bool HighPriority { get; set; } = false;
        }

        public JujiWindow()
        {
            Text = "JujiTABS";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1024, 720);
            MinimumSize = MaximumSize = ClientSize;
            BackColor = Color.FromArgb(1, 1, 1);
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);
            UpdateStyles();

            _settings = LoadSettings();
            _http.Timeout = TimeSpan.FromSeconds(12);
            _http.DefaultRequestHeaders.UserAgent.ParseAdd("JujiTABS-Launcher/" + CurrentPluginVersion);

            _background = LoadAsset("Background.png");
            LoadBackgroundAnimation();
            _headerPreview = LoadAsset("header_preview.png");
            LoadSidebarPreview();
            LoadGamePreviewFrames();
            _newsPanel = LoadAsset("news_panel.png");
            ScanExternalMods();

            _animationTimer = new System.Windows.Forms.Timer { Interval = 16 };
            _animationTimer.Tick += (_, _) => TickAnimation();
            _updateTimer = new System.Windows.Forms.Timer { Interval = 300000 };
            _updateTimer.Tick += async (_, _) => await BackgroundRefreshAsync();

            MouseMove += (_, e) => HandleMouseMove(e.Location);
            MouseLeave += (_, _) => SetHover(-1);
            MouseDown += (_, e) => HandleMouseDown(e);
            MouseUp += (_, e) => HandleMouseUp(e);

            Shown += async (_, _) =>
            {
                _animationTimer.Start();
                _updateTimer.Start();
                RefreshTabsProcessOnly();
                ScanInstalledVersions();
                await InitializeAsync();
            };

            FormClosed += (_, _) =>
            {
                _shutdown.Cancel();
                _animationTimer.Stop();
                _updateTimer.Stop();
                _http.Dispose();
                _githubGate.Dispose();
                _shutdown.Dispose();
                DisposeAssets();

                _fontSmall.Dispose();
                _font.Dispose();
                _fontBold.Dispose();
                _fontTitle.Dispose();
                _fontHero.Dispose();
                _fontHuge.Dispose();
            };
        }

        private async Task InitializeAsync()
        {
            try
            {
                _tabsExe = await ResolveTabsExecutableAsync();
                RefreshTabsProcessOnly();
                await CheckGitHubUpdateAsync(false);
                SetStatus(T("Bereit.", "Ready."));
            }
            catch (Exception ex)
            {
                SetStatus(ex.Message);
            }
        }

        private async Task BackgroundRefreshAsync()
        {
            if (_busy || IsDisposed) return;
            try
            {
                RefreshTabsProcessOnly();
                _tabsExe ??= await ResolveTabsExecutableAsync();
                if (!_shutdown.IsCancellationRequested) await CheckGitHubUpdateAsync(false);
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { SetStatus(ex.Message); }
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_NCHITTEST = 0x84;
            const int HTCLIENT = 1;
            const int HTCAPTION = 2;

            if (m.Msg == WM_NCHITTEST)
            {
                base.WndProc(ref m);
                if ((int)m.Result == HTCLIENT)
                {
                    Point p = PointToClient(Cursor.Position);
                    Rectangle drag = new(0, 0, ClientSize.Width, 70);
                    if (drag.Contains(p) && !_minRect.Contains(p) && !_closeRect.Contains(p))
                        m.Result = (IntPtr)HTCAPTION;
                }
                return;
            }
            base.WndProc(ref m);
        }

        private Bitmap? LoadAsset(string name)
        {
            try
            {
                using Stream? stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name);
                if (stream != null)
                {
                    using var decoded = new Bitmap(stream);
                    return new Bitmap(decoded);
                }
            }
            catch { }

            try
            {
                string path = Path.Combine(AppContext.BaseDirectory, "assets", name);
                if (!File.Exists(path)) return null;
                using var decoded = new Bitmap(path);
                return new Bitmap(decoded);
            }
            catch { return null; }
        }

        private void DisposeAssets()
        {
            _background?.Dispose();
            _backgroundCache?.Dispose();
            _backgroundFrameCache?.Dispose();
            foreach (var seq in _backgroundSequences) seq.Dispose();
            _headerPreview?.Dispose();
            foreach (var seq in _sidebarSequences) seq.Dispose();
            foreach (var seq in _gamePreviewSequences) seq.Dispose();
            _newsPanel?.Dispose();
        }

        private void TickAnimation()
        {
            _time += 0.020f;
            _animationDirty = false;
            AdvanceBackgroundAnimation();
            AdvanceSidebarAnimation();
            AdvancePreviewAnimation();
            if (DateTime.UtcNow >= _nextWeatherRefresh && !_busy)
            {
                _nextWeatherRefresh = DateTime.UtcNow.AddMinutes(10);
                _ = RefreshWeatherAsync();
            }
            bool redraw = false;
            for (int i = 0; i < _hoverAnim.Length; i++)
            {
                float target = _hover[i] ? 1f : 0f;
                float next = _hoverAnim[i] + (target - _hoverAnim[i]) * 0.28f;
                if (Math.Abs(next - _hoverAnim[i]) > 0.0006f) redraw = true;
                _hoverAnim[i] = next;
            }
            if (_animationDirty || redraw || _pressedIndex >= 0 || _gamePreviewFade < 1f) Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Bitmap? bgFrame = GetBackgroundFrame();
            if (bgFrame == null) { e.Graphics.Clear(Color.FromArgb(1, 1, 1)); return; }
            if (_backgroundCache == null || _backgroundCacheSize != ClientSize)
            {
                _backgroundCache?.Dispose();
                _backgroundCache = new Bitmap(Math.Max(1, ClientSize.Width), Math.Max(1, ClientSize.Height), PixelFormat.Format32bppPArgb);
                _backgroundCacheSize = ClientSize;
            }
            if (_backgroundFrameCache == null || _backgroundFrameCache.Width != Math.Max(1, ClientSize.Width) || _backgroundFrameCache.Height != Math.Max(1, ClientSize.Height))
            {
                _backgroundFrameCache?.Dispose();
                _backgroundFrameCache = new Bitmap(Math.Max(1, ClientSize.Width), Math.Max(1, ClientSize.Height), PixelFormat.Format32bppPArgb);
            }
            using (var bg = Graphics.FromImage(_backgroundFrameCache))
            {
                bg.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                bg.CompositingQuality = CompositingQuality.HighSpeed;
                bg.InterpolationMode = InterpolationMode.Bilinear;
                bg.PixelOffsetMode = PixelOffsetMode.HighSpeed;
                DrawImageCover(bg, bgFrame, new Rectangle(Point.Empty, ClientSize));
            }
            e.Graphics.DrawImageUnscaled(_backgroundFrameCache, 0, 0);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.Bilinear;
            g.PixelOffsetMode = PixelOffsetMode.HighSpeed;
            g.CompositingQuality = CompositingQuality.HighSpeed;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            DrawTopbar(g);
            DrawSidebar(g);
            if (_activeTab == Tab.Home) DrawHome(g);
            else DrawTabPage(g);
            DrawFooter(g);
            DrawWeatherOverlay(g);
            if (!string.IsNullOrWhiteSpace(_weatherLabel)) DrawText(g, _weatherLabel, _fontSmall, Color.FromArgb(170, 190, 180, 200), 300, 682);
        }

        private void DrawTopbar(Graphics g)
        {
            if (_headerPreview != null)
                DrawImageContain(g, _headerPreview, new Rectangle(8, 6, 188, 46));

            _minRect = new Rectangle(ClientSize.Width - 78, 12, 30, 24);
            _closeRect = new Rectangle(ClientSize.Width - 42, 12, 30, 24);
            DrawWindowButton(g, _minRect, 11, false);
            DrawWindowButton(g, _closeRect, 12, true);
        }

        private void DrawWindowButton(Graphics g, Rectangle r, int idx, bool close)
        {
            float a = Smooth(idx);
            Rectangle rr = AnimateRect(r, idx, 1);
            if (a > .01f) DrawGlow(g, rr, Pink, 8, 1.6f + 2f * a);
            FillRound(g, rr, Color.FromArgb(12, 10, 18, 230), 7);
            StrokeRound(g, rr, PinkBright, 7, 1f + .25f * a);
            using var pen = new Pen(Color.White, 1.8f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            if (!close)
            {
                g.DrawLine(pen, rr.Left + 8, rr.Top + 12, rr.Right - 8, rr.Top + 12);
            }
            else
            {
                g.DrawLine(pen, rr.Left + 8, rr.Top + 7, rr.Right - 8, rr.Bottom - 7);
                g.DrawLine(pen, rr.Right - 8, rr.Top + 7, rr.Left + 8, rr.Bottom - 7);
            }
        }

        private void DrawSidebar(Graphics g)
        {
            Rectangle side = new(16, 78, 252, 624);
            FillRound(g, side, Color.FromArgb(8, 7, 13, 238), 16);
            StrokeRound(g, side, Color.FromArgb(116, 31, 104), 16, 1f);

            Bitmap? sidebarFrame = GetSidebarFrame();
            if (sidebarFrame != null)
                DrawPreviewFast(g, sidebarFrame, new Rectangle(26, 88, 232, 158));

            _tabRects[0] = new Rectangle(40, 224, 204, 42);
            DrawHomeTabButton(g, _tabRects[0], 0);

            string[] names = { L("MODS", "MODS"), L("EINSTELLUNGEN", "SETTINGS"), L("UPDATE", "UPDATE"), L("HISTORY", "HISTORY"), L("ABOUT", "ABOUT") };
            int[] ys = { 275, 323, 371, 419, 467 };
            for (int i = 1; i < 6; i++)
            {
                _tabRects[i] = new Rectangle(36, ys[i - 1], 212, 40);
                DrawNavButton(g, _tabRects[i], names[i - 1], (Tab)i, i);
            }

            DrawText(g, "v" + CurrentPluginVersion, _fontSmall, PinkBright, 32, 658);
            DrawText(g, L("Made with ♥ by Juji", "Made with ♥ by Juji"), _fontSmall, Color.FromArgb(188, 173, 189), 32, 680);
        }

        private void DrawHomeTabButton(Graphics g, Rectangle r, int idx)
        {
            float a = Smooth(idx);
            Rectangle rr = AnimateRect(r, idx, 2);
            bool active = _activeTab == Tab.Home;
            FillRound(g, rr, active ? Color.FromArgb(223, 54, 156) : Color.FromArgb(13, 11, 20, 190), 9);
            StrokeRound(g, rr, active ? Color.FromArgb(255, 102, 193) : Color.FromArgb(97 + (int)(35 * a), 28, 84), 9, active ? 1.1f : 1f + .2f * a);
            if (active || a > .01f) DrawGlow(g, rr, Pink, 10, active ? 2.4f : 1.4f + 2.2f * a);
            DrawText(g, "⌂", _fontHero, active ? Color.White : PinkBright, rr.X + 13, rr.Y + 7);
            DrawText(g, "HOME", _fontBold, Color.White, rr.X + 47, rr.Y + 9);
        }

        private void DrawNavButton(Graphics g, Rectangle r, string text, Tab tab, int idx)
        {
            float a = Smooth(idx);
            bool active = _activeTab == tab;
            Rectangle rr = AnimateRect(r, idx, 2);

            if (active)
            {
                DrawGlow(g, rr, Pink, 10, 2f + 3f * a);
                FillGradientRound(g, rr, Color.FromArgb(216, 50, 151), Color.FromArgb(145, 20, 103), 9);
                StrokeRound(g, rr, PinkBright, 9, 1.15f);
            }
            else
            {
                FillRound(g, rr, Color.FromArgb(13, 11, 20, 190), 9);
                StrokeRound(g, rr, Color.FromArgb(97 + (int)(35 * a), 28, 84), 9, 1f + .2f * a);
                if (a > .01f) DrawGlow(g, rr, Pink, 10, 1.4f + 2.2f * a);
            }

            DrawNavIcon(g, idx, rr.X + 12, rr.Y + 10, active ? Color.White : PinkBright);
            DrawText(g, text, _fontBold, Color.White, rr.X + 45, rr.Y + 9);
        }

        private void DrawHome(Graphics g)
        {
            const int x = 286;
            const int w = 722;
            Rectangle hero = new(x, 70, w, 182);
            FillRound(g, hero, Color.FromArgb(1, 1, 1, 245), 16);
            StrokeRound(g, hero, Color.FromArgb(92, 27, 82), 16, 1f);

            DrawStatusDot(g, x + 18, 113, _tabsProcess != null ? Color.LimeGreen : Color.Orange);
            DrawText(g, _tabsStatus, _fontTitle, Color.FromArgb(224, 216, 226), x + 32, 96);
            DrawText(g, _tabsExe == null ? "TotallyAccurateBattleSimulator.exe" : Path.GetFileName(_tabsExe), _font, PinkBright, x + 32, 127);
            DrawText(g, L("STATUS:", "STATUS:"), _fontSmall, Color.FromArgb(150, 142, 158), x + 18, 161);
            DrawText(g, _tabsProcess != null ? L("SPIEL LÄUFT", "GAME RUNNING") : L("WARTET AUF TABS", "WAITING FOR TABS"), _fontBold,
                _tabsProcess != null ? Color.LimeGreen : PinkBright, x + 72, 158);

            Rectangle art = new(586, 96, 392, 114);
            DrawGamePreviewCover(g, art);
            _launchRect = new Rectangle(651, 194, 306, 48);
            DrawMainButton(g, _launchRect, 6, L("SPIEL STARTEN", "START GAME"), 0);

            Rectangle modCard = new(x, 278, 347, 168);
            Rectangle updateCard = new(x + 361, 278, 361, 168);
            DrawCard(g, modCard, true);
            DrawCard(g, updateCard, false);

            DrawText(g, "JujiTABS.dll", _fontBold, PinkBright, x + 20, 317);
            DrawText(g, _installedText, _fontSmall, _installedText == L("Installiert", "Installed") ? Color.LimeGreen : Color.White, x + 20, 339);
            DrawText(g, L("Version: ", "Version: ") + GetLocalPluginVersion(), _fontSmall, Color.White, x + 20, 359);
            _removeRect = new Rectangle(x + 28, 392, 279, 48);
            DrawMainButton(g, _removeRect, 7, L("MOD ENTFERNEN", "REMOVE MOD"), 1);

            DrawText(g, L("UPDATE CHECK", "UPDATE CHECK"), _fontBold, PinkBright, x + 382, 317);
            DrawText(g, L("Remote: ", "Remote: ") + _remoteCommit, _fontSmall, Color.White, x + 382, 339);
            string state = _updateStatus == "AKTUELL" ? L("AKTUELL", "UP TO DATE") : _updateStatus;
            DrawText(g, state, _fontBold, _updateStatus == "AKTUELL" ? Color.LimeGreen : PinkBright, x + 382, 359);
            _updateRect = new Rectangle(x + 395, 392, 279, 48);
            DrawMainButton(g, _updateRect, 8, L("JETZT PRÜFEN", "CHECK NOW"), 2);

            Rectangle news = new(300, 462, 708, 126);
            DrawNewsPanel(g, news);
            _folderRect = new Rectangle(306, 598, 176, 34);
            DrawSecondaryButton(g, _folderRect, L("ORDNER", "FOLDER"), 3);
        }

        private void DrawCard(Graphics g, Rectangle r, bool mod)
        {
            FillRound(g, r, Color.FromArgb(7, 7, 12, 244), 14);
            StrokeRound(g, r, Color.FromArgb(91, 27, 83), 14, 1f);
            DrawNavIcon(g, mod ? 1 : 3, r.X + 18, r.Y + 15, PinkBright);
            DrawText(g, mod ? L("MOD STATUS", "MOD STATUS") : L("UPDATE CHECK", "UPDATE CHECK"), _fontBold, PinkBright, r.X + 43, r.Y + 13);
            if (mod) DrawPill(g, new Rectangle(r.Right - 74, r.Y + 12, 54, 26), L("AKTIV", "ACTIVE"), Color.LimeGreen);
            else if (_updateStatus == "AKTUELL") DrawPill(g, new Rectangle(r.Right - 89, r.Y + 12, 69, 26), L("AKTUELL", "CURRENT"), Color.LimeGreen);
        }

        private void DrawNewsPanel(Graphics g, Rectangle dest)
        {
            // Intentionally transparent: the repository image is decorative only; it must never paint a black card.
            if (_repoUpdates.Count == 0)
            {
                DrawText(g, _message, _fontSmall, Color.FromArgb(200, 188, 204), dest.X + 8, dest.Y + 10);
                return;
            }

            int y = dest.Y + 8;
            foreach (RepoUpdate item in _repoUpdates.Take(4))
            {
                DrawStatusDot(g, dest.X + 5, y + 6, PinkBright);
                string version = string.IsNullOrWhiteSpace(item.Version) ? "" : "  " + item.Version;
                DrawText(g, item.Message + version, _fontSmall, Color.FromArgb(220, 205, 221), dest.X + 17, y);
                DrawTextRight(g, item.Date, _fontSmall, Color.FromArgb(165, 150, 170), dest.Right - 2, y);
                y += 18;
            }
        }

        private void DrawGamePreviewCover(Graphics g, Rectangle dest)
        {
            using GraphicsPath clip = RoundedRect(dest, 14);
            GraphicsState state = g.Save();
            g.SetClip(clip);
            if (_gamePreviewCurrent != null)
            {
                if (_gamePreviewFade >= 1f || _gamePreviewPrevious == null)
                    DrawImageCover(g, _gamePreviewCurrent, dest);
                else
                {
                    DrawImageAlphaCover(g, _gamePreviewPrevious, dest, 1f - _gamePreviewFade);
                    DrawImageAlphaCover(g, _gamePreviewCurrent, dest, _gamePreviewFade);
                }
            }
            g.Restore(state);
        }

        private static void DrawImageAlphaCover(Graphics g, Bitmap image, Rectangle dest, float alpha)
        {
            float sx = dest.Width / (float)Math.Max(1, image.Width);
            float sy = dest.Height / (float)Math.Max(1, image.Height);
            float scale = Math.Max(sx, sy);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale));
            int x = dest.X + (dest.Width - w) / 2;
            int y = dest.Y + (dest.Height - h) / 2;
            var matrix = new ColorMatrix { Matrix33 = Math.Max(0f, Math.Min(1f, alpha)) };
            using var attrs = new ImageAttributes();
            attrs.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            g.DrawImage(image, new Rectangle(x, y, w, h), 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, attrs);
        }

        private void LoadBackgroundAnimation()
        {
            // Prefer Background.gif / Background*.gif. Fall back to the legacy PNG.
            foreach (string source in EnumerateAssetCandidates("Background", "gif"))
                TryLoadPreviewSequence(source, _backgroundSequences);

            if (_backgroundSequences.Count > 0)
            {
                _backgroundSequenceIndex = 0;
                _backgroundFrameIndex = 0;
                _nextBackgroundSwap = DateTime.UtcNow.AddMilliseconds(GetDuration(_backgroundSequences[0], 0));
            }
        }

        private Bitmap? GetBackgroundFrame()
        {
            if (_backgroundSequences.Count == 0) return _background;
            PreviewSequence seq = _backgroundSequences[Math.Clamp(_backgroundSequenceIndex, 0, _backgroundSequences.Count - 1)];
            return seq.Frames.Count == 0 ? _background : seq.Frames[Math.Clamp(_backgroundFrameIndex, 0, seq.Frames.Count - 1)];
        }

        private void AdvanceBackgroundAnimation()
        {
            if (_backgroundSequences.Count == 0) return;
            DateTime now = DateTime.UtcNow;
            if (now < _nextBackgroundSwap) return;
            PreviewSequence seq = _backgroundSequences[_backgroundSequenceIndex];
            _backgroundFrameIndex++;
            if (_backgroundFrameIndex >= seq.Frames.Count)
            {
                _backgroundFrameIndex = 0;
                _backgroundSequenceIndex = (_backgroundSequenceIndex + 1) % _backgroundSequences.Count;
                seq = _backgroundSequences[_backgroundSequenceIndex];
            }
            _nextBackgroundSwap = now.AddMilliseconds(GetDuration(seq, _backgroundFrameIndex));
            _backgroundFrameCache?.Dispose();
            _backgroundFrameCache = null;
            _backgroundCache?.Dispose();
            _backgroundCache = null;
            _animationDirty = true;
        }

        private void LoadSidebarPreview()
        {
            foreach (string candidate in EnumerateAssetCandidates("sidebar_preview", "gif"))
                TryLoadPreviewSequence(candidate, _sidebarSequences);

            if (_sidebarSequences.Count > 0)
            {
                _sidebarSequenceIndex = 0;
                _sidebarFrameIndex = 0;
                _nextSidebarSwap = DateTime.UtcNow.AddMilliseconds(GetDuration(_sidebarSequences[0], 0));
            }
        }

        private IEnumerable<string> EnumerateAssetCandidates(string stem, string extension)
        {
            var yielded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string name in Assembly.GetExecutingAssembly().GetManifestResourceNames()
                         .Where(n => Path.GetExtension(n).Equals("." + extension, StringComparison.OrdinalIgnoreCase)
                                  && Path.GetFileNameWithoutExtension(n).StartsWith(stem, StringComparison.OrdinalIgnoreCase)))
            {
                if (yielded.Add(name)) yield return name;
            }

            string dir = Path.Combine(AppContext.BaseDirectory, "assets");
            if (Directory.Exists(dir))
            {
                foreach (string path in Directory.EnumerateFiles(dir, stem + "*." + extension, SearchOption.TopDirectoryOnly)
                             .OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
                {
                    if (yielded.Add(path)) yield return path;
                }
            }
        }

        private void TryLoadPreviewSequence(string source, List<PreviewSequence> destination)
        {
            try
            {
                if (File.Exists(source))
                {
                    using var src = new Bitmap(source);
                    AddDecodedSequence(src, destination);
                    return;
                }

                using Stream? stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(source);
                if (stream == null) return;
                using var embedded = new Bitmap(stream);
                // The resource stream stays alive while every GIF frame is decoded.
                AddDecodedSequence(embedded, destination);
            }
            catch { }
        }

        private static void AddDecodedSequence(Bitmap src, List<PreviewSequence> destination)
        {
            var seq = new PreviewSequence();
            ExtractBitmapFrames(src, seq);
            if (seq.Frames.Count > 0) destination.Add(seq);
            else seq.Dispose();
        }

        private Bitmap? GetSidebarFrame()
        {
            if (_sidebarSequences.Count == 0) return null;
            var seq = _sidebarSequences[_sidebarSequenceIndex];
            return seq.Frames.Count == 0 ? null : seq.Frames[Math.Clamp(_sidebarFrameIndex, 0, seq.Frames.Count - 1)];
        }

        private void AdvanceSidebarAnimation()
        {
            if (_sidebarSequences.Count == 0) return;
            DateTime now = DateTime.UtcNow;
            if (now < _nextSidebarSwap) return;
            var seq = _sidebarSequences[_sidebarSequenceIndex];
            _sidebarFrameIndex++;
            _animationDirty = true;
            if (_sidebarFrameIndex >= seq.Frames.Count)
            {
                _sidebarFrameIndex = 0;
                _sidebarSequenceIndex = (_sidebarSequenceIndex + 1) % _sidebarSequences.Count;
                seq = _sidebarSequences[_sidebarSequenceIndex];
            }
            _nextSidebarSwap = now.AddMilliseconds(GetDuration(seq, _sidebarFrameIndex));
        }

        private void LoadGamePreviewFrames()
        {
            foreach (string source in EnumerateAssetCandidates("game_preview", "gif"))
                TryLoadPreviewSequence(source, _gamePreviewSequences);

            // Keep the PNG preview as a final fallback when no animated assets exist.
            if (_gamePreviewSequences.Count == 0)
            {
                Bitmap? png = LoadAsset("game_preview.png");
                if (png != null)
                {
                    var seq = new PreviewSequence();
                    seq.Frames.Add(png);
                    seq.DurationsMs.Add(2500);
                    _gamePreviewSequences.Add(seq);
                }
            }

            if (_gamePreviewSequences.Count == 0) return;
            _gamePreviewIndex = 0;
            _previousPreviewIndex = 0;
            _gamePreviewCurrent = _gamePreviewSequences[0].Frames[0];
            _gamePreviewFade = 1f;
            _nextPreviewSwap = DateTime.UtcNow.AddMilliseconds(GetDuration(_gamePreviewSequences[0], 0));
        }

        private static int PreviewNumber(string name)
        {
            var m = Regex.Match(Path.GetFileNameWithoutExtension(name), @"game_preview(\d+)?", RegexOptions.IgnoreCase);
            return m.Success && int.TryParse(m.Groups[1].Value, out int n) ? n : 0;
        }

        private static void ExtractBitmapFrames(Bitmap src, PreviewSequence seq)
        {
            FrameDimension? dim = null;
            try
            {
                Guid[] dims = src.FrameDimensionsList;
                if (dims.Length > 0) dim = new FrameDimension(dims[0]);
                int count = dim == null ? 1 : src.GetFrameCount(dim);
                if (count <= 0) count = 1;
                int[] delays = new int[count];
                Array.Fill(delays, 100);
                if (src.PropertyIdList.Contains(0x5100))
                {
                    try
                    {
                        PropertyItem pi = src.GetPropertyItem(0x5100);
                        for (int i = 0; i < count && i * 4 + 4 <= pi.Value.Length; i++)
                        {
                            int cs = BitConverter.ToInt32(pi.Value, i * 4);
                            delays[i] = Math.Max(40, cs * 10);
                        }
                    }
                    catch { }
                }

                // Decode each GIF frame once. Painting then uses a ready-made bitmap
                // instead of resampling the full GIF frame on every UI tick.
                for (int i = 0; i < count; i++)
                {
                    if (dim != null) src.SelectActiveFrame(dim, i);
                    Bitmap frame = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppPArgb);
                    using (var g = Graphics.FromImage(frame))
                    {
                        g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                        g.InterpolationMode = InterpolationMode.NearestNeighbor;
                        g.PixelOffsetMode = PixelOffsetMode.HighSpeed;
                        g.DrawImageUnscaled(src, 0, 0);
                    }
                    seq.Frames.Add(frame);
                    seq.DurationsMs.Add(delays[i]);
                }
            }
            catch { }
        }

        private static int GetDuration(PreviewSequence seq, int index) =>
            seq.DurationsMs.Count == 0 ? 100 : Math.Max(40, seq.DurationsMs[Math.Clamp(index, 0, seq.DurationsMs.Count - 1)]);

        private void AdvancePreviewAnimation()
        {
            if (_gamePreviewSequences.Count == 0) return;
            DateTime now = DateTime.UtcNow;

            // Fade only when switching from one preview asset to the next.
            // GIF frames themselves are shown directly to avoid per-frame cross-fading/flicker.
            if (_gamePreviewFade < 1f)
            {
                double elapsed = (now - _previewFadeStarted).TotalMilliseconds;
                _gamePreviewFade = (float)Math.Clamp(elapsed / PreviewTransitionMs, 0d, 1d);
            }

            if (now < _nextPreviewSwap) return;

            PreviewSequence currentSeq = _gamePreviewSequences[_gamePreviewIndex];
            _previousPreviewIndex++;
            if (_previousPreviewIndex < currentSeq.Frames.Count)
            {
                // Same GIF: no fade, no recreation. Just advance the frame.
                _gamePreviewCurrent = currentSeq.Frames[_previousPreviewIndex];
                _animationDirty = true;
                _gamePreviewFade = 1f;
                _nextPreviewSwap = now.AddMilliseconds(GetDuration(currentSeq, _previousPreviewIndex));
                return;
            }

            // End of this GIF: transition once to the next GIF.
            _previousPreviewIndex = 0;
            _gamePreviewIndex = (_gamePreviewIndex + 1) % _gamePreviewSequences.Count;
            PreviewSequence next = _gamePreviewSequences[_gamePreviewIndex];
            _gamePreviewPrevious = _gamePreviewCurrent;
            _gamePreviewCurrent = next.Frames[0];
            _animationDirty = true;
            _previewFadeStarted = now;
            _gamePreviewFade = 0f;
            _nextPreviewSwap = now.AddMilliseconds(GetDuration(next, 0));
        }

        private void DrawTabPage(Graphics g)
        {
            Rectangle panel = new(286, 116, 722, 552);
            FillRound(g, panel, Color.FromArgb(7, 7, 12, 242), 16);
            StrokeRound(g, panel, Color.FromArgb(92, 27, 82), 16, 1f);

            switch (_activeTab)
            {
                case Tab.Mods:
                    DrawModsPage(g, panel);
                    break;
                case Tab.Settings:
                    DrawSettingsPage(g, panel);
                    break;
                case Tab.Update:
                    DrawUpdatePage(g, panel);
                    break;
                case Tab.History:
                    DrawHistoryPage(g, panel);
                    break;
                default:
                    DrawAboutPage(g, panel);
                    break;
            }
        }

        private string GetModsFolder() => Path.Combine(AppContext.BaseDirectory, "Mods");

        private void ScanExternalMods()
        {
            try
            {
                _externalMods.Clear();
                string dir = GetModsFolder();
                Directory.CreateDirectory(dir);
                foreach (string dll in Directory.EnumerateFiles(dir, "*.dll", SearchOption.AllDirectories))
                {
                    if (string.Equals(Path.GetFileName(dll), "JujiTABS.dll", StringComparison.OrdinalIgnoreCase)) continue;
                    _externalMods.Add(dll);
                }
                _externalMods.Sort(StringComparer.OrdinalIgnoreCase);
                string? configured = _settings.SelectedMod;
                if (!string.IsNullOrWhiteSpace(configured))
                {
                    string candidate = Path.Combine(GetModsFolder(), configured);
                    _selectedExternalMod = _externalMods.FirstOrDefault(x => string.Equals(x, candidate, StringComparison.OrdinalIgnoreCase));
                }
                if (_selectedExternalMod == null && _externalMods.Count > 0)
                    _selectedExternalMod = _externalMods[0];
            }
            catch { }
        }

        private async Task InstallExternalModsAsync(bool showDialog)
        {
            if (_busy) return;
            _busy = true;
            try
            {
                ScanExternalMods();
                _tabsExe ??= await ResolveTabsExecutableAsync();
                if (_tabsExe == null) throw new InvalidOperationException(L("TABS wurde nicht gefunden.", "TABS was not found."));
                if (_externalMods.Count == 0) throw new InvalidOperationException(L("Im Mods-Ordner liegen keine DLL-Mods.", "No DLL mods were found in the Mods folder."));
                if (string.IsNullOrWhiteSpace(_selectedExternalMod) || !File.Exists(_selectedExternalMod))
                    throw new InvalidOperationException(L("Bitte zuerst eine DLL im Mods-Ordner auswählen.", "Select a DLL in the Mods folder first."));

                string target = InstallExternalModFile(_selectedExternalMod, _tabsExe);
                _settings.SelectedMod = Path.GetRelativePath(GetModsFolder(), _selectedExternalMod);
                SaveSettings(_settings);
                _message = L("Mod geladen: " + Path.GetFileName(target), "Mod loaded: " + Path.GetFileName(target));
                if (showDialog) MessageBox.Show(this, _message, "JujiTABS Mods", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                _message = ex.Message;
                if (showDialog) MessageBox.Show(this, ex.Message, "JujiTABS Mods", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { _busy = false; Invalidate(); }
        }

        private string InstallExternalModFile(string source, string tabsExe)
        {
            string plugins = Path.Combine(Path.GetDirectoryName(tabsExe)!, "BepInEx", "plugins");
            Directory.CreateDirectory(plugins);
            string fileName = Path.GetFileName(source);
            string target = Path.Combine(plugins, fileName);
            File.Copy(source, target, true);
            return target;
        }

        private void OpenModsFolder()
        {
            try
            {
                string dir = GetModsFolder();
                Directory.CreateDirectory(dir);
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true });
            }
            catch (Exception ex) { SetStatus(ex.Message); }
        }

        private void DrawModsPage(Graphics g, Rectangle panel)
        {
            DrawText(g, L("MODS", "MODS"), _fontHero, PinkBright, panel.X + 22, panel.Y + 20);
            DrawText(g, L("Installierte / gespeicherte Versionen", "Installed / archived versions"), _fontBold, Color.FromArgb(216, 208, 220), panel.X + 22, panel.Y + 58);
            ScanExternalMods();
            DrawText(g, L($"Mods-Ordner: {_externalMods.Count} DLL", $"Mods folder: {_externalMods.Count} DLL"), _fontSmall, Color.FromArgb(190, 178, 196), panel.X + 22, panel.Y + 80);
            DrawText(g, _selectedExternalMod == null ? L("Keine DLL ausgewählt", "No DLL selected") : L("Ausgewählt: " + Path.GetFileName(_selectedExternalMod), "Selected: " + Path.GetFileName(_selectedExternalMod)), _fontSmall, PinkBright, panel.X + 22, panel.Y + 98);
            int y = panel.Y + 124;
            if (_localVersions.Count == 0)
            {
                DrawText(g, L("Noch keine Version archiviert.", "No archived version yet."), _font, Color.FromArgb(195, 183, 199), panel.X + 22, y);
            }
            if (_externalMods.Count == 0)
            {
                DrawText(g, L("Lege eine .dll in Mods\\. Klicke anschließend auf die DLL, um sie auszuwählen.", "Put a .dll into Mods\\ and click it to select it."), _font, Color.FromArgb(195, 183, 199), panel.X + 22, y);
            }
            else
            {
                foreach (string mod in _externalMods.Take(9))
                {
                    Rectangle row = new(panel.X + 20, y - 3, panel.Width - 40, 30);
                    bool selected = string.Equals(mod, _selectedExternalMod, StringComparison.OrdinalIgnoreCase);
                    FillRound(g, row, selected ? Color.FromArgb(54, 14, 43, 235) : Color.FromArgb(11, 10, 17, 220), 7);
                    StrokeRound(g, row, selected ? PinkBright : Color.FromArgb(56, 31, 53), 7, selected ? 1.1f : 0.8f);
                    DrawText(g, selected ? "✓" : "○", _fontBold, selected ? Color.LimeGreen : Color.FromArgb(120, 110, 125), row.X + 10, row.Y + 5);
                    DrawText(g, Path.GetRelativePath(GetModsFolder(), mod), _fontSmall, selected ? PinkBright : Color.FromArgb(200, 190, 205), row.X + 34, row.Y + 5);
                    y += 34;
                }
            }
            _installLatestRect = new Rectangle(panel.X + 22, panel.Bottom - 88, 250, 46);
            DrawMainButton(g, _installLatestRect, 14, L("NEUESTE INSTALLIEREN", "INSTALL LATEST"), 14);
            _restoreRect = new Rectangle(panel.X + 290, panel.Bottom - 88, 210, 46);
            DrawSecondaryButton(g, _restoreRect, L("ORIGINAL WIEDERHERSTELLEN", "RESTORE ORIGINAL DLL"), 15);
            _installFolderRect = new Rectangle(panel.X + 22, panel.Bottom - 38, 190, 28);
            DrawSecondaryButton(g, _installFolderRect, L("MODS SCANNEN", "SCAN MODS"), 23);
            _injectSelectedRect = new Rectangle(panel.X + 224, panel.Bottom - 38, 190, 28);
            DrawSecondaryButton(g, _injectSelectedRect, L("DLL LADEN", "LOAD DLL"), 25);
            _openModsRect = new Rectangle(panel.X + 436, panel.Bottom - 38, 200, 28);
            DrawSecondaryButton(g, _openModsRect, L("MODS-ORDNER", "OPEN MODS"), 24);
        }

        private void DrawSettingsPage(Graphics g, Rectangle panel)
        {
            DrawText(g, L("EINSTELLUNGEN", "SETTINGS"), _fontHero, PinkBright, panel.X + 22, panel.Y + 20);
            DrawText(g, L("TotallyAccurateBattleSimulator.exe", "TotallyAccurateBattleSimulator.exe"), _fontBold, Color.FromArgb(216, 208, 220), panel.X + 22, panel.Y + 60);

            _exeRect = new Rectangle(panel.X + 22, panel.Y + 92, 618, 40);
            FillRound(g, _exeRect, Color.FromArgb(13, 11, 20, 225), 9);
            StrokeRound(g, _exeRect, Color.FromArgb(111, 30, 97), 9, 1f);
            DrawText(g, L("TABS EXE: ", "TABS EXE: ") + (_tabsExe ?? L("Nicht gefunden", "Not found")), _fontSmall, Color.White, _exeRect.X + 12, _exeRect.Y + 12);

            _languageRect = new Rectangle(panel.X + 22, panel.Y + 148, 300, 40);
            _windowModeRect = new Rectangle(panel.X + 340, panel.Y + 148, 300, 40);
            _resolutionRect = new Rectangle(panel.X + 22, panel.Y + 204, 300, 40);
            _autoInstallRect = new Rectangle(panel.X + 340, panel.Y + 204, 300, 40);
            _priorityRect = new Rectangle(panel.X + 22, panel.Y + 260, 300, 40);
            DrawSettingButton(g, _languageRect, L("SPRACHE: ", "LANGUAGE: ") + (_settings.Language == "DE" ? "Deutsch" : "English"), 16);
            DrawSettingButton(g, _windowModeRect, L("MODUS: ", "MODE: ") + _settings.WindowMode, 17);
            DrawSettingButton(g, _resolutionRect, L("AUFLÖSUNG: ", "RESOLUTION: ") + _settings.Resolution, 18);
            DrawSettingButton(g, _autoInstallRect, L("MOD BEIM START: ", "LOAD MOD ON START: ") + (_settings.AutoInstallMod ? L("AN", "ON") : L("AUS", "OFF")), 19);
            DrawSettingButton(g, _priorityRect, L("HOHE PRIORITÄT: ", "HIGH PRIORITY: ") + (_settings.HighPriority ? L("AN", "ON") : L("AUS", "OFF")), 20);

            _argsRect = new Rectangle(panel.X + 22, panel.Y + 330, 618, 44);
            FillRound(g, _argsRect, Color.FromArgb(13, 11, 20, 225), 9);
            StrokeRound(g, _argsRect, Color.FromArgb(111, 30, 97), 9, 1f);
            DrawText(g, L("Startparameter: ", "Launch args: ") + (string.IsNullOrWhiteSpace(_settings.LaunchArgs) ? L("keine", "none") : _settings.LaunchArgs), _fontSmall, Color.White, _argsRect.X + 12, _argsRect.Y + 13);

            DrawText(g, L("Klick auf EXE oder Startparameter zum Bearbeiten. LOAD MOD ON START lädt die ausgewählte DLL vor dem TABS-Start nach BepInEx\plugins.", "Click EXE or launch args to edit them. LOAD MOD ON START loads the selected DLL into BepInEx/plugins before TABS starts."), _fontSmall, Color.FromArgb(166, 155, 172), panel.X + 22, panel.Y + 400);
            _backRect = new Rectangle(panel.X + 22, panel.Bottom - 64, 210, 40);
            DrawSecondaryButton(g, _backRect, L("ZURÜCK ZU HOME", "BACK HOME"), 10);
        }

        private void DrawUpdatePage(Graphics g, Rectangle panel)
        {
            DrawText(g, L("UPDATE", "UPDATE"), _fontHero, PinkBright, panel.X + 22, panel.Y + 20);
            DrawText(g, L("GitHub: veröffentlichte JujiTABS-Versionen", "GitHub: published JujiTABS versions"), _fontBold, Color.FromArgb(216, 208, 220), panel.X + 22, panel.Y + 58);
            DrawText(g, _updateStatus, _fontBold, _updateStatus == "AKTUELL" ? Color.LimeGreen : PinkBright, panel.X + 22, panel.Y + 84);
            int y = panel.Y + 118;
            var updates = _repoUpdates.Where(x => !string.IsNullOrWhiteSpace(x.Version)).Take(10).ToArray();
            if (updates.Length == 0)
            {
                DrawText(g, L("Noch keine Versionsdaten geladen. Klicke auf Home → JETZT PRÜFEN.", "No version data loaded yet. Use Home → CHECK NOW."), _font, Color.FromArgb(195, 183, 199), panel.X + 22, y + 8);
            }
            foreach (var v in updates)
            {
                FillRound(g, new Rectangle(panel.X + 20, y - 2, panel.Width - 40, 31), Color.FromArgb(11, 10, 17, 220), 7);
                DrawText(g, v.Version, _fontBold, PinkBright, panel.X + 31, y + 4);
                DrawText(g, v.Message, _fontSmall, Color.FromArgb(205, 192, 208), panel.X + 110, y + 5);
                DrawTextRight(g, v.Date, _fontSmall, Color.FromArgb(150, 140, 155), panel.Right - 30, y + 5);
                y += 36;
            }
            _installLatestRect = new Rectangle(panel.X + 22, panel.Bottom - 64, 250, 40);
            DrawMainButton(g, _installLatestRect, 14, L("NEUESTE INSTALLIEREN", "INSTALL LATEST"), 14);
            _backRect = new Rectangle(panel.X + 290, panel.Bottom - 64, 210, 40);
            DrawSecondaryButton(g, _backRect, L("ZURÜCK ZU HOME", "BACK HOME"), 10);
        }

        private void DrawHistoryPage(Graphics g, Rectangle panel)
        {
            DrawText(g, L("HISTORY", "HISTORY"), _fontHero, PinkBright, panel.X + 22, panel.Y + 20);
            int y = panel.Y + 64;
            foreach (var v in _repoUpdates.Take(14))
            {
                DrawStatusDot(g, panel.X + 20, y + 8, PinkBright);
                DrawText(g, (string.IsNullOrWhiteSpace(v.Version) ? "REPO" : v.Version) + " — " + v.Message, _fontSmall, Color.FromArgb(211, 198, 214), panel.X + 34, y);
                DrawTextRight(g, v.Date, _fontSmall, Color.FromArgb(150, 140, 155), panel.Right - 30, y);
                y += 30;
            }
            _backRect = new Rectangle(panel.X + 22, panel.Bottom - 64, 210, 40);
            DrawSecondaryButton(g, _backRect, L("ZURÜCK ZU HOME", "BACK HOME"), 10);
        }

        private void DrawAboutPage(Graphics g, Rectangle panel)
        {
            DrawText(g, L("ABOUT", "ABOUT"), _fontHero, PinkBright, panel.X + 22, panel.Y + 20);
            DrawText(g, L("JujiTABS Anleitung", "JujiTABS Guide"), _fontBold, Color.FromArgb(216, 208, 220), panel.X + 22, panel.Y + 64);
            string[] lines = _settings.Language == "DE"
                ? new[]
                {
                    "1. START: startet Totally Accurate Battle Simulator.",
                    "2. MODS: verwaltet installierte und archivierte JujiTABS-Versionen.",
                    "3. UPDATE: prüft GitHub nach veröffentlichten JujiTABS-Versionen.",
                    "4. ENTFERNEN: entfernt die Mod und stellt die gesicherte Original-DLL wieder her.",
                    "5. EINSTELLUNGEN: Sprache und TABS-Startoptionen ändern."
                }
                : new[]
                {
                    "1. START: launches Totally Accurate Battle Simulator.",
                    "2. MODS: manages installed and archived JujiTABS versions.",
                    "3. UPDATE: checks GitHub for published JujiTABS versions.",
                    "4. REMOVE: removes the mod and restores the saved original DLL.",
                    "5. SETTINGS: change language and TABS launch options."
                };
            int y = panel.Y + 108;
            foreach (string line in lines)
            {
                DrawText(g, line, _font, Color.FromArgb(210, 198, 213), panel.X + 24, y);
                y += 34;
            }
            _backRect = new Rectangle(panel.X + 22, panel.Bottom - 64, 210, 40);
            DrawSecondaryButton(g, _backRect, L("ZURÜCK ZU HOME", "BACK HOME"), 10);
        }

        private void DrawFooter(Graphics g)
        {
            DrawText(g, "JUJI TABS LAUNCHER", _fontBold, PinkBright, 575, 688);
            DrawText(g, _tabsProcess != null ? L("STATUS: TABS LÄUFT", "STATUS: GAME RUNNING") : L("STATUS: ALLES BEREIT", "STATUS: READY"), _fontSmall, Color.LimeGreen, 775, 689);
            DrawStatusDot(g, 996, 694, Color.LimeGreen);
        }

        private void DrawMainButton(Graphics g, Rectangle r, int idx, string text, int iconKind)
        {
            float a = Smooth(idx);
            Rectangle rr = AnimateRect(r, idx, 2);
            if (a > .01f) DrawGlow(g, rr, Pink, 9, 1.7f + 2.8f * a);
            FillGradientRound(g, rr, Color.FromArgb(218, 52, 151), Color.FromArgb(151, 20, 104), 9);
            StrokeRound(g, rr, Color.FromArgb(255, 103, 193), 9, 1.1f + .2f * a);
            DrawActionIcon(g, iconKind, rr.X + 15, rr.Y + 14, Color.White);
            DrawCentered(g, text, _fontBold, Color.White, new Rectangle(rr.X + 42, rr.Y, rr.Width - 48, rr.Height));
        }

        private void DrawSecondaryButton(Graphics g, Rectangle r, string text, int idx)
        {
            float a = Smooth(idx);
            Rectangle rr = AnimateRect(r, idx, 1);
            if (a > .01f) DrawGlow(g, rr, Pink, 8, 1.3f + 2f * a);
            FillRound(g, rr, Color.FromArgb(27, 24, 36, 228), 9);
            StrokeRound(g, rr, Color.FromArgb(125, 31, 103), 9, 1f + .2f * a);
            DrawCentered(g, text, _fontSmall, Color.White, rr);
        }

        private void DrawSettingButton(Graphics g, Rectangle r, string text, int idx)
        {
            float a = Smooth(idx);
            Rectangle rr = AnimateRect(r, idx, 1);
            FillRound(g, rr, Color.FromArgb(12, 10, 18, 220), 9);
            StrokeRound(g, rr, Color.FromArgb(106 + (int)(35 * a), 31, 95), 9, 1f + .2f * a);
            DrawText(g, text, _fontSmall, Color.White, rr.X + 12, rr.Y + 12);
        }

        private void DrawPill(Graphics g, Rectangle r, string text, Color c)
        {
            FillRound(g, r, Color.FromArgb(10, 40, 23), 12);
            StrokeRound(g, r, Color.FromArgb(35, 190, 81), 12, 1f);
            DrawCentered(g, text, _fontSmall, c, r);
        }

        private string GetLocalPluginVersion()
        {
            string path = GetInstalledPluginPath();
            if (!File.Exists(path) || !LooksLikeJujiTabs(path)) return "—";
            try
            {
                string fileVersion = FileVersionInfo.GetVersionInfo(path).FileVersion ?? "";
                if (!string.IsNullOrWhiteSpace(fileVersion)) return fileVersion.Split('+')[0];
                string name = Path.GetFileNameWithoutExtension(path);
                string n = ExtractVersion(name);
                if (!string.IsNullOrWhiteSpace(n)) return n;
            }
            catch { }
            return "—";
        }

        private async Task LaunchTabsAsync()
        {
            if (_busy) return;
            _busy = true;
            try
            {
                _tabsExe ??= await ResolveTabsExecutableAsync();
                if (_tabsExe == null)
                {
                    SetStatus(L("TABS wurde nicht gefunden.", "TABS was not found."));
                    return;
                }

                if (_settings.AutoInstallMod)
                {
                    ScanExternalMods();
                    if (!string.IsNullOrWhiteSpace(_selectedExternalMod) && File.Exists(_selectedExternalMod))
                    {
                        string loaded = InstallExternalModFile(_selectedExternalMod, _tabsExe);
                        _message = L("Mod beim Start geladen: " + Path.GetFileName(loaded), "Mod loaded on start: " + Path.GetFileName(loaded));
                    }
                    else
                    {
                        // No external selection: make sure the bundled JujiTABS plugin is present.
                        await InstallEmbeddedModAsync(false);
                    }
                }

                string tabsPath = _tabsExe;
                if (!File.Exists(tabsPath))
                    throw new FileNotFoundException(L("TABS-EXE nicht gefunden", "TABS executable not found"), tabsPath);
                var psi = new ProcessStartInfo
                {
                    FileName = tabsPath,
                    WorkingDirectory = Path.GetDirectoryName(tabsPath) ?? AppContext.BaseDirectory,
                    UseShellExecute = true,
                    Arguments = BuildLaunchArguments()
                };
                using var started = Process.Start(psi);
                if (started == null) throw new InvalidOperationException(L("TABS konnte nicht gestartet werden.", "TABS could not be started."));
                _ = PostDiscordUsageAsync("game_started");
                if (_settings.HighPriority)
                {
                    _ = Task.Run(async () =>
                    {
                        await Task.Delay(1200);
                        try
                        {
                            var p = Process.GetProcesses().FirstOrDefault(IsTabs);
                            if (p != null) p.PriorityClass = ProcessPriorityClass.High;
                        }
                        catch { }
                    });
                }
                await Task.Delay(800);
                RefreshTabsProcessOnly();
                SetStatus(L("TABS wird gestartet.", "TABS is starting."));
            }
            catch (Exception ex)
            {
                SetStatus(ex.Message);
            }
            finally { _busy = false; }
        }

        private string? ResolveLocalPluginSource()
        {
            string[] candidates =
            {
                Path.Combine(AppContext.BaseDirectory, "bin", "JujiTABS.dll"),
                Path.Combine(AppContext.BaseDirectory, "Mods", "JujiTABS.dll"),
                Path.Combine(AppContext.BaseDirectory, "JujiTABS.dll")
            };
            foreach (string pth in candidates)
                if (File.Exists(pth)) return pth;

            try
            {
                string mods = Path.Combine(AppContext.BaseDirectory, "Mods");
                if (Directory.Exists(mods))
                {
                    string? discovered = Directory.EnumerateFiles(mods, "*.dll", SearchOption.AllDirectories)
                        .FirstOrDefault(x => Path.GetFileName(x).Contains("JujiTABS", StringComparison.OrdinalIgnoreCase));
                    if (!string.IsNullOrWhiteSpace(discovered)) return discovered;
                }
            }
            catch { }
            return null;
        }

        private async Task InstallEmbeddedModAsync(bool showDialog)
        {
            _busy = true;
            try
            {
                _tabsExe ??= await ResolveTabsExecutableAsync();
                if (_tabsExe == null) throw new InvalidOperationException(L("TABS wurde nicht gefunden.", "TABS was not found."));
                string dir = Path.GetDirectoryName(_tabsExe)!;
                string plugins = Path.Combine(dir, "BepInEx", "plugins");
                Directory.CreateDirectory(plugins);
                string target = Path.Combine(plugins, "JujiTABS.dll");
                BackupOriginalIfNeeded(target);
                ArchiveExistingMod(target);

                string? external = ResolveLocalPluginSource();
                if (!string.IsNullOrWhiteSpace(external))
                {
                    File.Copy(external, target, true);
                }
                else
                {
                    using Stream? resource = Assembly.GetExecutingAssembly().GetManifestResourceStream("JujiTABS.dll");
                    if (resource == null) throw new InvalidOperationException(L("JujiTABS.dll wurde nicht gefunden. Lege sie nach Mods\\ oder bin\\.", "JujiTABS.dll was not found. Put it into Mods\\ or bin\\."));
                    using var output = File.Create(target);
                    await resource.CopyToAsync(output, _shutdown.Token);
                }
                RecordInstalledVersion(target);

                ScanInstalledVersions();
                _installedText = L("Installiert", "Installed");
                SetStatus(L("JujiTABS wurde installiert.", "JujiTABS installed."));
                if (showDialog) MessageBox.Show(this, _message, "JujiTABS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                SetStatus(ex.Message);
                if (showDialog) MessageBox.Show(this, ex.Message, "JujiTABS", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { _busy = false; }
        }

        private void RemoveMod()
        {
            if (_busy) return;
            _busy = true;
            try
            {
                string path = GetInstalledPluginPath();
                if (File.Exists(path))
                {
                    ArchiveExistingMod(path);
                    File.Delete(path);
                }

                string original = GetOriginalPluginBackupPath();
                if (File.Exists(original))
                {
                    File.Copy(original, path, true);
                    File.Delete(original);
                    _message = L("Mod entfernt und Original-DLL wiederhergestellt.", "Mod removed and original DLL restored.");
                }
                else
                {
                    _message = L("Mod entfernt. Keine gesicherte Original-DLL vorhanden.", "Mod removed. No saved original DLL was available.");
                }
                _installedText = File.Exists(path) && !LooksLikeJujiTabs(path) ? L("Original", "Original") : L("Nicht installiert", "Not installed");
                ScanInstalledVersions();
            }
            catch (Exception ex) { _message = ex.Message; }
            finally
            {
                _busy = false;
                Invalidate();
            }
        }

        private void BackupOriginalIfNeeded(string target)
        {
            if (!File.Exists(target)) return;
            if (LooksLikeJujiTabs(target)) return;
            string backup = GetOriginalPluginBackupPath();
            if (!File.Exists(backup)) File.Copy(target, backup, true);
        }

        private bool LooksLikeJujiTabs(string path)
        {
            try
            {
                string name = FileVersionInfo.GetVersionInfo(path).ProductName ?? "";
                if (name.Contains("JujiTABS", StringComparison.OrdinalIgnoreCase)) return true;
                return Path.GetFileName(path).StartsWith("JujiTABS", StringComparison.OrdinalIgnoreCase);
            }
            catch { return true; }
        }

        private void RecordInstalledVersion(string path)
        {
            try
            {
                if (!File.Exists(path) || !LooksLikeJujiTabs(path)) return;
                string version = GetVersionFromFile(path);
                if (string.IsNullOrWhiteSpace(version) || version == "—") return;
                string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "JujiTABS", "versions");
                Directory.CreateDirectory(root);
                string dst = Path.Combine(root, $"JujiTABS{version}.dll");
                File.Copy(path, dst, true);
            }
            catch { }
        }

        private void ArchiveExistingMod(string path)
        {
            if (!File.Exists(path)) return;
            if (!LooksLikeJujiTabs(path)) return;
            try
            {
                string version = GetVersionFromFile(path);
                string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "JujiTABS", "versions");
                Directory.CreateDirectory(root);
                string safeVersion = string.IsNullOrWhiteSpace(version) ? "unknown" : version;
                string dst = Path.Combine(root, $"JujiTABS{safeVersion}.dll");
                File.Copy(path, dst, true);
            }
            catch { }
        }

        private string GetVersionFromFile(string path)
        {
            try
            {
                string fv = FileVersionInfo.GetVersionInfo(path).FileVersion ?? "";
                if (!string.IsNullOrWhiteSpace(fv)) return fv.Split('+')[0];
            }
            catch { }
            return ExtractVersion(Path.GetFileNameWithoutExtension(path));
        }

        private void ScanInstalledVersions()
        {
            try
            {
                _localVersions.Clear();
                string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "JujiTABS", "versions");
                if (Directory.Exists(root))
                {
                    foreach (string p in Directory.EnumerateFiles(root, "*.dll", SearchOption.TopDirectoryOnly))
                    {
                        string v = GetVersionFromFile(p);
                        _localVersions.Add(new LocalVersion(string.IsNullOrWhiteSpace(v) ? "unknown" : v, p, File.GetLastWriteTimeUtc(p)));
                    }
                }
                string current = GetInstalledPluginPath();
                if (File.Exists(current) && LooksLikeJujiTabs(current))
                {
                    _localVersions.Insert(0, new LocalVersion(GetLocalPluginVersion(), current, File.GetLastWriteTimeUtc(current)));
                }
                string? pluginDir = GetTabsDirectory() == null ? null : Path.Combine(GetTabsDirectory()!, "BepInEx", "plugins");
                if (pluginDir != null && Directory.Exists(pluginDir))
                {
                    foreach (string p in Directory.EnumerateFiles(pluginDir, "JujiTABS*.dll", SearchOption.TopDirectoryOnly))
                    {
                        if (string.Equals(p, current, StringComparison.OrdinalIgnoreCase)) continue;
                        if (!LooksLikeJujiTabs(p)) continue;
                        string v = GetVersionFromFile(p);
                        _localVersions.Add(new LocalVersion(string.IsNullOrWhiteSpace(v) ? "unknown" : v, p, File.GetLastWriteTimeUtc(p)));
                    }
                }
                var sorted = _localVersions
                    .GroupBy(x => x.Path, StringComparer.OrdinalIgnoreCase)
                    .Select(g => g.OrderByDescending(x => x.Timestamp).First())
                    .OrderByDescending(x => ParseVersionSafe(x.Version))
                    .ThenByDescending(x => x.Timestamp).ToList();
                _localVersions.Clear(); _localVersions.AddRange(sorted);
            }
            catch { }
        }

        private async Task InstallLatestRemoteAsync(bool showDialog)
        {
            if (_busy) return;
            _busy = true;
            try
            {
                RepoUpdate? latest = _repoUpdates.Where(x => !string.IsNullOrWhiteSpace(x.Version)).OrderByDescending(x => ParseVersionSafe(x.Version)).FirstOrDefault();
                if (latest == null) throw new InvalidOperationException(L("Keine veröffentlichte JujiTABS-Version im Repository gefunden.", "No published JujiTABS version was found in the repository."));
                _tabsExe ??= await ResolveTabsExecutableAsync();
                if (_tabsExe == null) throw new InvalidOperationException(L("TABS wurde nicht gefunden.", "TABS was not found."));
                string target = Path.Combine(Path.GetDirectoryName(_tabsExe)!, "BepInEx", "plugins", "JujiTABS.dll");
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                BackupOriginalIfNeeded(target);
                ArchiveExistingMod(target);

                string url = "https://raw.githubusercontent.com/ovaNite/JujiTabs/main/" + latest.Path.Replace(" ", "%20");
                byte[] data = await _http.GetByteArrayAsync(url, _shutdown.Token);
                await File.WriteAllBytesAsync(target, data, _shutdown.Token);
                RecordInstalledVersion(target);
                ScanInstalledVersions();
                _installedText = L("Installiert", "Installed");
                _message = L("Version " + latest.Version + " installiert.", "Version " + latest.Version + " installed.");
                if (showDialog) MessageBox.Show(this, _message, "JujiTABS Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                _message = ex.Message;
                if (showDialog) MessageBox.Show(this, ex.Message, "JujiTABS Update", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { _busy = false; Invalidate(); }
        }

        private void RestoreOriginalDll()
        {
            RemoveMod();
        }

        private void OpenTabsFolder()
        {
            _ = OpenTabsFolderAsync();
        }

        private async Task OpenTabsFolderAsync()
        {
            string? dir = _tabsExe != null ? Path.GetDirectoryName(_tabsExe) : await ResolveTabsExecutableAsync();
            if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir)) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true }); }
            catch { }
        }

        private string BuildLaunchArguments()
        {
            var args = new List<string>();
            if (!string.IsNullOrWhiteSpace(_settings.LaunchArgs)) args.Add(_settings.LaunchArgs.Trim());
            switch (_settings.WindowMode)
            {
                case "Fullscreen": args.Add("-screen-fullscreen 1"); break;
                case "Borderless": args.Add("-popupwindow -screen-fullscreen 0"); break;
                default: args.Add("-screen-fullscreen 0"); break;
            }
            var parts = _settings.Resolution.Split('x');
            if (parts.Length == 2 && int.TryParse(parts[0], out int w) && int.TryParse(parts[1], out int h))
                args.Add($"-screen-width {w} -screen-height {h}");
            return string.Join(" ", args);
        }

        private void EditTabsExe()
        {
            using var dlg = new OpenFileDialog
            {
                Filter = "TABS executable|TotallyAccurateBattleSimulator.exe|Executable|*.exe",
                FileName = File.Exists(_settings.TabsExe) ? _settings.TabsExe : ""
            };
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                _settings.TabsExe = dlg.FileName;
                _tabsExe = dlg.FileName;
                SaveSettings(_settings);
                Invalidate();
            }
        }

        private void EditLaunchArgs()
        {
            using var dlg = new Form
            {
                Text = L("Startparameter", "Launch arguments"),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                ClientSize = new Size(560, 130),
                MinimizeBox = false, MaximizeBox = false
            };
            dlg.BackColor = Color.FromArgb(16, 13, 22);
            var box = new TextBox { Left = 16, Top = 18, Width = 528, Text = _settings.LaunchArgs ?? "" };
            var ok = new Button { Left = 434, Top = 65, Width = 110, Text = "OK", DialogResult = DialogResult.OK };
            dlg.Controls.Add(box); dlg.Controls.Add(ok); dlg.AcceptButton = ok;
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                _settings.LaunchArgs = box.Text.Trim();
                SaveSettings(_settings);
                Invalidate();
            }
        }

        private void RefreshTabsProcessOnly()
        {
            try
            {
                _tabsProcess = Process.GetProcesses().FirstOrDefault(IsTabs);
                if (_tabsProcess != null) _tabsExe ??= SafePath(_tabsProcess);
                _tabsStatus = _tabsProcess != null ? L("TABS ERKANNT", "TABS DETECTED") : L("TABS NICHT ERKANNT", "TABS NOT DETECTED");
                string path = GetInstalledPluginPath();
                _installedText = File.Exists(path) ? (LooksLikeJujiTabs(path) ? L("Installiert", "Installed") : L("Original", "Original")) : L("Nicht installiert", "Not installed");
                Invalidate();
            }
            catch { }
        }

        private static bool IsTabs(Process p)
        {
            try { return TabsProcessNames.Any(n => string.Equals(p.ProcessName, n, StringComparison.OrdinalIgnoreCase)); }
            catch { return false; }
        }

        private static string? SafePath(Process p)
        {
            try { return p.MainModule?.FileName; } catch { return null; }
        }

        private async Task<string?> ResolveTabsExecutableAsync()
        {
            if (!string.IsNullOrWhiteSpace(_settings.TabsExe) && File.Exists(_settings.TabsExe)) return _settings.TabsExe;
            if (File.Exists(_tabsExe)) return _tabsExe;
            string local = Path.Combine(AppContext.BaseDirectory, "TotallyAccurateBattleSimulator.exe");
            if (File.Exists(local)) return local;
            string found = await Task.Run(FindTabsExecutableBlocking);
            if (!string.IsNullOrWhiteSpace(found))
            {
                _settings.TabsExe = found;
                SaveSettings(_settings);
            }
            return found;
        }

        private static string? FindTabsExecutableBlocking()
        {
            string[] roots =
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs"),
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            };
            foreach (string root in roots.Where(Directory.Exists))
            {
                try
                {
                    string? file = Directory.EnumerateFiles(root, "TotallyAccurateBattleSimulator.exe", SearchOption.AllDirectories).FirstOrDefault();
                    if (file != null) return file;
                }
                catch { }
            }
            return null;
        }

        private string? GetTabsDirectory()
        {
            if (!string.IsNullOrWhiteSpace(_tabsExe) && File.Exists(_tabsExe)) return Path.GetDirectoryName(_tabsExe);
            return null;
        }

        private string GetInstalledPluginPath()
        {
            string? dir = GetTabsDirectory();
            return dir == null ? string.Empty : Path.Combine(dir, "BepInEx", "plugins", "JujiTABS.dll");
        }

        private string GetOriginalPluginBackupPath()
        {
            string? dir = GetTabsDirectory();
            return dir == null ? string.Empty : Path.Combine(dir, "BepInEx", "plugins", "JujiTABS.dll.juji-original");
        }

        private async Task CheckGitHubUpdateAsync(bool showDialog)
        {
            if (!await _githubGate.WaitAsync(0)) return;
            try
            {
                string treeJson = await _http.GetStringAsync(GitHubRepoApi + "/git/trees/main?recursive=1", _shutdown.Token);
                using JsonDocument treeDoc = JsonDocument.Parse(treeJson);
                List<(string Path, string Version, string Sha)> dlls = new();
                foreach (JsonElement node in treeDoc.RootElement.GetProperty("tree").EnumerateArray())
                {
                    string path = node.GetProperty("path").GetString() ?? "";
                    if (!path.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)) continue;
                    string name = Path.GetFileNameWithoutExtension(path);
                    string version = ExtractJujiDllVersion(name);
                    if (string.IsNullOrWhiteSpace(version)) continue;
                    string sha = node.TryGetProperty("sha", out var sh) ? (sh.GetString() ?? "") : "";
                    dlls.Add((path, version, sha));
                }

                string commitsJson = await _http.GetStringAsync(GitHubRepoApi + "/commits?per_page=20", _shutdown.Token);
                using JsonDocument commitsDoc = JsonDocument.Parse(commitsJson);
                string latestCommit = commitsDoc.RootElement.EnumerateArray().Select(x => x.GetProperty("sha").GetString() ?? "").FirstOrDefault() ?? "";
                string buildCommit = LoadBuildCommit();
                _remoteCommit = latestCommit.Length >= 8 ? latestCommit[..8] : latestCommit;

                _repoUpdates.Clear();
                foreach (var item in dlls.OrderByDescending(x => ParseVersionSafe(x.Version)).Take(12))
                {
                    string pathUrl = GitHubRepoApi + "/commits?path=" + Uri.EscapeDataString(item.Path) + "&per_page=1";
                    string pjson = await _http.GetStringAsync(pathUrl, _shutdown.Token);
                    using JsonDocument pd = JsonDocument.Parse(pjson);
                    JsonElement arr = pd.RootElement;
                    if (arr.GetArrayLength() == 0) continue;
                    JsonElement c = arr[0];
                    string dateRaw = c.GetProperty("commit").GetProperty("committer").GetProperty("date").GetString() ?? "";
                    DateTime dt = DateTime.TryParse(dateRaw, out var d) ? d.ToLocalTime() : DateTime.MinValue;
                    string msg = c.GetProperty("commit").GetProperty("message").GetString() ?? "JujiTABS Update";
                    _repoUpdates.Add(new RepoUpdate(item.Version, dt == DateTime.MinValue ? dateRaw : dt.ToString("dd.MM.yyyy"), msg.Split('\n')[0], item.Path, item.Sha));
                }

                string currentLocalVersion = GetLocalPluginVersion();
                Version latestVersion = _repoUpdates.Count > 0
                    ? ParseVersionSafe(_repoUpdates.OrderByDescending(x => ParseVersionSafe(x.Version)).First().Version)
                    : new Version(0, 0);
                Version installedVersion = ParseVersionSafe(currentLocalVersion);
                bool current = _repoUpdates.Count > 0 && installedVersion >= latestVersion;
                _updateStatus = current || (_repoUpdates.Count == 0 && !string.IsNullOrEmpty(buildCommit) && string.Equals(buildCommit, latestCommit, StringComparison.OrdinalIgnoreCase))
                    ? "AKTUELL" : (_repoUpdates.Count > 0 ? L("UPDATE VERFÜGBAR", "UPDATE AVAILABLE") : "REPO");
                _message = _repoUpdates.Count == 0 ? L("Keine neue veröffentlichte Version gefunden.", "No newly published version found.") : _repoUpdates[0].Message;

                if (showDialog)
                {
                    string body = _repoUpdates.Count == 0
                        ? L("Keine neue Version im Repository veröffentlicht.", "No new version has been published in the repository.")
                        : L("Neueste Version: ", "Latest version: ") + _repoUpdates.OrderByDescending(x => ParseVersionSafe(x.Version)).First().Version;
                    if (_repoUpdates.Count > 0) body += "\n" + _repoUpdates.OrderByDescending(x => ParseVersionSafe(x.Version)).First().Date;
                    MessageBox.Show(this, body, "JujiTABS Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Invalidate();
            }
            catch (Exception ex)
            {
                _updateStatus = "CHECK FAILED";
                _message = ex.Message;
                Invalidate();
                if (showDialog) MessageBox.Show(this, ex.Message, "JujiTABS Update", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally { _githubGate.Release(); }
        }

        private string LoadBuildCommit()
        {
            try
            {
                Stream? stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("build_commit.txt");
                if (stream == null) return "";
                using var reader = new StreamReader(stream);
                return reader.ReadToEnd().Trim();
            }
            catch { return ""; }
        }

        private static string ExtractJujiDllVersion(string text)
        {
            if (!text.Contains("JujiTABS", StringComparison.OrdinalIgnoreCase)) return "";
            var m = Regex.Match(text, @"JujiTABS(?:[-_ ]?v)(\d+(?:\.\d+){1,3})", RegexOptions.IgnoreCase);
            return m.Success ? "v" + m.Groups[1].Value : "";
        }

        private static string ExtractVersion(string text)
        {
            var m = Regex.Match(text ?? "", @"v?(\d+(?:\.\d+){1,3})", RegexOptions.IgnoreCase);
            return m.Success ? "v" + m.Groups[1].Value : "";
        }

        private static Version ParseVersionSafe(string s)
        {
            string t = (s ?? "").Trim().TrimStart('v', 'V');
            return Version.TryParse(t, out var v) ? v : new Version(0, 0);
        }

        private void HandleMouseMove(Point p)
        {
            int hit = HitTest(p);
            SetHover(hit);
            Cursor = hit >= 0 ? Cursors.Hand : Cursors.Default;
        }

        private void HandleMouseDown(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            _pressedIndex = HitTest(e.Location);
            Invalidate();
        }

        private void HandleMouseUp(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            int hit = HitTest(e.Location);
            int pressed = _pressedIndex;
            _pressedIndex = -1;
            Invalidate();
            if (hit < 0 || hit != pressed || _busy) return;

            if (hit >= 100 && hit < 109)
            {
                int index = hit - 100;
                if (index >= 0 && index < _externalMods.Count)
                {
                    _selectedExternalMod = _externalMods[index];
                    _settings.SelectedMod = Path.GetRelativePath(GetModsFolder(), _selectedExternalMod);
                    SaveSettings(_settings);
                    _message = L("Ausgewählt: " + Path.GetFileName(_selectedExternalMod), "Selected: " + Path.GetFileName(_selectedExternalMod));
                    Invalidate();
                }
                return;
            }

            if (hit < 6)
            {
                _activeTab = (Tab)hit;
                Invalidate();
                return;
            }

            switch (hit)
            {
                case 6: _ = LaunchTabsAsync(); break;
                case 7: RemoveMod(); break;
                case 8: _ = CheckGitHubUpdateAsync(true); break;
                case 9: OpenTabsFolder(); break;
                case 10: _activeTab = Tab.Home; Invalidate(); break;
                case 11: WindowState = FormWindowState.Minimized; break;
                case 12: Close(); break;
                case 14: _ = InstallLatestRemoteAsync(true); break;
                case 15: RestoreOriginalDll(); break;
                case 23: _ = InstallExternalModsAsync(true); break;
                case 24: OpenModsFolder(); break;
                case 25: _ = InstallExternalModsAsync(true); break;
                case 16: CycleLanguage(); break;
                case 17: CycleWindowMode(); break;
                case 18: CycleResolution(); break;
                case 19: _settings.AutoInstallMod = !_settings.AutoInstallMod; SaveSettings(_settings); Invalidate(); break;
                case 20: _settings.HighPriority = !_settings.HighPriority; SaveSettings(_settings); Invalidate(); break;
                case 21: EditTabsExe(); break;
                case 22: EditLaunchArgs(); break;
            }
        }

        private int HitTest(Point p)
        {
            for (int i = 0; i < _tabRects.Length; i++) if (_tabRects[i].Contains(p)) return i;
            if (_minRect.Contains(p)) return 11;
            if (_closeRect.Contains(p)) return 12;

            if (_activeTab == Tab.Home)
            {
                if (_launchRect.Contains(p)) return 6;
                if (_removeRect.Contains(p)) return 7;
                if (_updateRect.Contains(p)) return 8;
                if (_folderRect.Contains(p)) return 9;
            }
            else
            {
                if (_backRect.Contains(p)) return 10;
                if (_installLatestRect.Contains(p) && (_activeTab == Tab.Mods || _activeTab == Tab.Update)) return 14;
                if (_restoreRect.Contains(p) && _activeTab == Tab.Mods) return 15;
                if (_installFolderRect.Contains(p) && _activeTab == Tab.Mods) return 23;
                if (_injectSelectedRect.Contains(p) && _activeTab == Tab.Mods) return 25;
                if (_openModsRect.Contains(p) && _activeTab == Tab.Mods) return 24;
                if (_exeRect.Contains(p) && _activeTab == Tab.Settings) return 21;
                if (_argsRect.Contains(p) && _activeTab == Tab.Settings) return 22;
                if (_languageRect.Contains(p) && _activeTab == Tab.Settings) return 16;
                if (_windowModeRect.Contains(p) && _activeTab == Tab.Settings) return 17;
                if (_resolutionRect.Contains(p) && _activeTab == Tab.Settings) return 18;
                if (_autoInstallRect.Contains(p) && _activeTab == Tab.Settings) return 19;
                if (_priorityRect.Contains(p) && _activeTab == Tab.Settings) return 20;
                if (_activeTab == Tab.Mods)
                {
                    int rowY = 116 + 124;
                    for (int i = 0; i < Math.Min(_externalMods.Count, 9); i++)
                    {
                        Rectangle row = new(286 + 20, rowY + i * 34 - 3, 722 - 40, 30);
                        if (row.Contains(p)) return 100 + i;
                    }
                }
            }
            return -1;
        }

        private void CycleLanguage()
        {
            _settings.Language = _settings.Language == "DE" ? "EN" : "DE";
            SaveSettings(_settings);
            Invalidate();
        }

        private void CycleWindowMode()
        {
            _settings.WindowMode = _settings.WindowMode switch
            {
                "Windowed" => "Fullscreen",
                "Fullscreen" => "Borderless",
                _ => "Windowed"
            };
            SaveSettings(_settings);
            Invalidate();
        }

        private void CycleResolution()
        {
            _settings.Resolution = _settings.Resolution switch
            {
                "1920x1080" => "2560x1440",
                "2560x1440" => "1280x720",
                _ => "1920x1080"
            };
            SaveSettings(_settings);
            Invalidate();
        }

        private async Task RefreshWeatherAsync()
        {
            try
            {
                using var c = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
                c.DefaultRequestHeaders.UserAgent.ParseAdd("JujiTABS-Launcher/Weather");
                string geo = await c.GetStringAsync("https://ipapi.co/json/", _shutdown.Token);
                using var gd = JsonDocument.Parse(geo);
                if (!gd.RootElement.TryGetProperty("latitude", out var latEl) || !gd.RootElement.TryGetProperty("longitude", out var lonEl)) return;
                double lat = latEl.GetDouble(), lon = lonEl.GetDouble();
                string json = await c.GetStringAsync($"https://api.open-meteo.com/v1/forecast?latitude={lat.ToString(System.Globalization.CultureInfo.InvariantCulture)}&longitude={lon.ToString(System.Globalization.CultureInfo.InvariantCulture)}&current=weather_code", _shutdown.Token);
                using var wd = JsonDocument.Parse(json);
                int code = wd.RootElement.GetProperty("current").GetProperty("weather_code").GetInt32();
                WeatherKind kind = (code >= 71 && code <= 77) ? WeatherKind.Snow : ((code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code == 95 || code == 96 || code == 99) ? WeatherKind.Rain : WeatherKind.Clear;
                _weatherKind = kind;
                _weatherLabel = kind == WeatherKind.Rain ? "RAIN · raindrops.frag" : kind == WeatherKind.Snow ? "WINTER · winter.frag" : "CLEAR · shimmer_effect.frag";
                BeginInvoke((Action)(() => Invalidate()));
            }
            catch { }
        }

        private void DrawWeatherOverlay(Graphics g)
        {
            if (_weatherKind == WeatherKind.Clear) return;
            GraphicsState state = g.Save();
            g.SetClip(ClientRectangle);
            bool rain = _weatherKind == WeatherKind.Rain;
            int count = rain ? 56 : 42;
            using var pen = new Pen(rain ? Color.FromArgb(80, 190, 205, 230) : Color.FromArgb(110, 235, 235, 255), rain ? 1.0f : 1.4f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            for (int i = 0; i < count; i++)
            {
                double seed = i * 12.9898 + 0.123;
                float x = (float)((Math.Sin(seed) * 0.5 + 0.5) * ClientSize.Width);
                float speed = rain ? 520f : 42f;
                float y = (float)(((_time * speed) + (i * 73f)) % (ClientSize.Height + 80)) - 40f;
                if (rain) g.DrawLine(pen, x, y, x - 6, y + 16);
                else g.DrawEllipse(pen, x, y, 3, 3);
            }
            g.Restore(state);
        }

        private async Task PostDiscordUsageAsync(string action)
        {
            try
            {
                // Optional: set JUJI_DISCORD_WEBHOOK_URL in the environment.
                // No webhook URL or machine/user identifiers are embedded in the app.
                string? webhook = Environment.GetEnvironmentVariable("JUJI_DISCORD_WEBHOOK_URL");
                if (string.IsNullOrWhiteSpace(webhook)) return;
                var payload = new
                {
                    username = "JujiTABS",
                    embeds = new[]
                    {
                        new
                        {
                            title = "JujiTABS Nutzung",
                            description = action == "game_started" ? "TABS wurde über den Launcher gestartet." : action,
                            fields = new[]
                            {
                                new { name = "Launcher", value = "JujiTABS", inline = true },
                                new { name = "Version", value = CurrentPluginVersion, inline = true },
                                new { name = "Zeit", value = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss zzz"), inline = true }
                            }
                        }
                    }
                };
                string json = JsonSerializer.Serialize(payload);
                using var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                await _http.PostAsync(webhook, content, _shutdown.Token);
            }
            catch { /* Usage reporting must never block or crash the launcher. */ }
        }

        private LauncherSettings LoadSettings()
        {
            try
            {
                string path = SettingsPath();
                if (File.Exists(path))
                {
                    var s = JsonSerializer.Deserialize<LauncherSettings>(File.ReadAllText(path));
                    if (s != null) return s;
                }
            }
            catch { }
            return new LauncherSettings();
        }

        private void SaveSettings(LauncherSettings settings)
        {
            try
            {
                string path = SettingsPath();
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                File.WriteAllText(path, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }

        private static string SettingsPath() => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "JujiTABS", "launcher-settings.json");

        private string T(string de, string en) => _settings.Language == "DE" ? de : en;
        private string L(string de, string en) => _settings.Language == "DE" ? de : en;
        private static Color Pink => Color.FromArgb(238, 48, 158);
        private static Color PinkBright => Color.FromArgb(255, 88, 184);
        private float Smooth(int idx) => idx >= 0 && idx < _hoverAnim.Length ? _hoverAnim[idx] : 0f;

        private void SetStatus(string text)
        {
            _message = text;
            try
            {
                if (!IsDisposed && IsHandleCreated) BeginInvoke((Action)(() => Invalidate()));
            }
            catch { }
        }

        private void SetHover(int idx)
        {
            bool changed = false;
            for (int i = 0; i < _hover.Length; i++)
            {
                bool v = i == idx;
                if (_hover[i] != v) { _hover[i] = v; changed = true; }
            }
            if (changed) Invalidate();
        }

        private Rectangle AnimateRect(Rectangle r, int idx, int lift)
        {
            float a = Smooth(idx);
            int dy = (int)Math.Round(-lift * a);
            int press = _pressedIndex == idx ? 1 : 0;
            return new Rectangle(r.X, r.Y + dy + press, r.Width, r.Height - press * 2);
        }

        private static void DrawImageCover(Graphics g, Bitmap image, Rectangle dest)
        {
            if (image.Width <= 0 || image.Height <= 0) return;
            float sx = dest.Width / (float)image.Width;
            float sy = dest.Height / (float)image.Height;
            float scale = Math.Max(sx, sy);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale));
            int x = dest.X + (dest.Width - w) / 2;
            int y = dest.Y + (dest.Height - h) / 2;
            g.DrawImage(image, new Rectangle(x, y, w, h));
        }

        private static void DrawPreviewFast(Graphics g, Bitmap image, Rectangle dest)
        {
            if (image.Width <= 0 || image.Height <= 0) return;
            float sx = dest.Width / (float)image.Width;
            float sy = dest.Height / (float)image.Height;
            float scale = Math.Min(sx, sy);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale));
            int x = dest.X + (dest.Width - w) / 2;
            int y = dest.Y + (dest.Height - h) / 2;
            GraphicsState state = g.Save();
            g.InterpolationMode = InterpolationMode.Bilinear;
            g.PixelOffsetMode = PixelOffsetMode.HighSpeed;
            g.CompositingQuality = CompositingQuality.HighSpeed;
            g.DrawImage(image, new Rectangle(x, y, w, h));
            g.Restore(state);
        }

        private static void DrawImageContain(Graphics g, Bitmap image, Rectangle dest)
        {
            float sx = dest.Width / (float)image.Width;
            float sy = dest.Height / (float)image.Height;
            float scale = Math.Min(sx, sy);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale));
            int x = dest.X + (dest.Width - w) / 2;
            int y = dest.Y + (dest.Height - h) / 2;
            g.DrawImage(image, new Rectangle(x, y, w, h));
        }

        private static void DrawText(Graphics g, string text, Font font, Color color, float x, float y)
        {
            using var brush = new SolidBrush(color);
            g.DrawString(text, font, brush, x, y);
        }

        private static void DrawTextRight(Graphics g, string text, Font font, Color color, int right, int y)
        {
            SizeF size = g.MeasureString(text, font);
            DrawText(g, text, font, color, right - size.Width, y);
        }

        private static void DrawCentered(Graphics g, string text, Font font, Color color, Rectangle r)
        {
            using var brush = new SolidBrush(color);
            SizeF size = g.MeasureString(text, font);
            g.DrawString(text, font, brush, r.X + (r.Width - size.Width) / 2f, r.Y + (r.Height - size.Height) / 2f - 1f);
        }

        private static void FillRound(Graphics g, Rectangle r, Color color, int radius)
        {
            using var path = RoundedRect(r, radius);
            using var brush = new SolidBrush(color);
            g.FillPath(brush, path);
        }

        private static void FillGradientRound(Graphics g, Rectangle r, Color c1, Color c2, int radius)
        {
            using var path = RoundedRect(r, radius);
            using var brush = new LinearGradientBrush(r, c1, c2, LinearGradientMode.Vertical);
            g.FillPath(brush, path);
        }

        private static void StrokeRound(Graphics g, Rectangle r, Color color, int radius, float width)
        {
            using var path = RoundedRect(r, radius);
            using var pen = new Pen(color, width) { LineJoin = LineJoin.Round };
            g.DrawPath(pen, path);
        }

        private static void DrawGlow(Graphics g, Rectangle r, Color color, int radius, float width)
        {
            using var path = RoundedRect(r, radius);
            using var pen = new Pen(Color.FromArgb(95, color), width) { LineJoin = LineJoin.Round };
            g.DrawPath(pen, path);
        }

        private static GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            int d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        private static void DrawStatusDot(Graphics g, int x, int y, Color color)
        {
            using var brush = new SolidBrush(color);
            g.FillEllipse(brush, x - 4, y - 4, 8, 8);
        }

        private static void DrawNavIcon(Graphics g, int kind, int x, int y, Color c)
        {
            using var pen = new Pen(c, 1.8f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
            using var brush = new SolidBrush(c);
            switch (kind)
            {
                case 1:
                    g.DrawPolygon(pen, new[] { new Point(x + 9, y), new Point(x + 18, y + 5), new Point(x + 9, y + 10), new Point(x, y + 5), new Point(x + 9, y) });
                    g.DrawLine(pen, x + 9, y + 10, x + 9, y + 19);
                    g.DrawLine(pen, x, y + 5, x, y + 14);
                    g.DrawLine(pen, x, y + 14, x + 9, y + 19);
                    g.DrawLine(pen, x + 18, y + 5, x + 18, y + 14);
                    g.DrawLine(pen, x + 18, y + 14, x + 9, y + 19);
                    break;
                case 2:
                    g.DrawEllipse(pen, x + 1, y + 1, 17, 17);
                    g.FillEllipse(brush, x + 7, y + 7, 5, 5);
                    break;
                case 3:
                    g.DrawArc(pen, x + 1, y + 1, 17, 17, -50, 245);
                    g.DrawLine(pen, x + 15, y + 2, x + 17, y + 7);
                    break;
                case 4:
                    g.DrawArc(pen, x + 2, y + 2, 16, 16, 40, 260);
                    g.DrawLine(pen, x + 2, y + 8, x + 6, y + 8);
                    break;
                default:
                    g.FillEllipse(brush, x + 2, y + 2, 15, 15);
                    break;
            }
        }

        private static void DrawActionIcon(Graphics g, int kind, int x, int y, Color c)
        {
            using var pen = new Pen(c, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
            using var brush = new SolidBrush(c);
            switch (kind)
            {
                case 0:
                    g.FillPolygon(brush, new[] { new Point(x, y), new Point(x, y + 18), new Point(x + 15, y + 9) });
                    break;
                case 1:
                    g.DrawRectangle(pen, x + 3, y + 5, 11, 12);
                    g.DrawLine(pen, x + 1, y + 3, x + 16, y + 3);
                    g.DrawLine(pen, x + 6, y + 1, x + 11, y + 1);
                    break;
                case 2:
                    g.DrawArc(pen, x + 1, y + 2, 16, 16, -45, 250);
                    g.DrawLine(pen, x + 15, y + 2, x + 17, y + 7);
                    break;
                case 14:
                    g.DrawLine(pen, x + 9, y + 1, x + 9, y + 13);
                    g.DrawLine(pen, x + 4, y + 9, x + 9, y + 14);
                    g.DrawLine(pen, x + 14, y + 9, x + 9, y + 14);
                    g.DrawArc(pen, x + 2, y + 11, 14, 7, 0, 180);
                    break;
            }
        }
    }
}
