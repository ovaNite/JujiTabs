param(
    [ValidateSet('launch','game_started','update_check','shutdown')]
    [string]$Action = 'launch',
    [string]$Version = 'unknown',
    [string]$WebhookUrl = $env:JUJI_DISCORD_WEBHOOK_URL
)

if ([string]::IsNullOrWhiteSpace($WebhookUrl)) {
    throw 'Setze zuerst die Umgebungsvariable JUJI_DISCORD_WEBHOOK_URL auf deine Discord-Webhook-URL.'
}

$description = switch ($Action) {
    'launch'       { 'JujiTABS Launcher gestartet.' }
    'game_started' { 'TABS über JujiTABS gestartet.' }
    'update_check' { 'JujiTABS Update-Check ausgeführt.' }
    'shutdown'     { 'JujiTABS Launcher beendet.' }
}

$body = @{
    username = 'JujiTABS'
    embeds = @(@{
        title = 'JujiTABS Nutzung'
        description = $description
        fields = @(
            @{ name = 'Version'; value = $Version; inline = $true },
            @{ name = 'Zeit'; value = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz'); inline = $true }
        )
    })
} | ConvertTo-Json -Depth 6

Invoke-RestMethod -Uri $WebhookUrl -Method Post -ContentType 'application/json' -Body $body | Out-Null
Write-Host "Discord-Nutzungsereignis gesendet: $Action"
