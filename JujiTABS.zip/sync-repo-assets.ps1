$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$assets = Join-Path $root 'assets'
New-Item -ItemType Directory -Force -Path $assets | Out-Null

$repo = 'ovaNite/JujiTabs'
$rawBase = "https://raw.githubusercontent.com/$repo/main/"
$headers = @{ 'User-Agent' = 'JujiTABS-Build/2.11.1' }

# GitHub REST API is intentionally not used here. Unauthenticated API requests can
# hit the rate limit and must never make a local build fail. Existing local assets
# are always preferred; missing assets are fetched directly from raw.githubusercontent.com.
$core = @(
  'Background.png',
  'Background.gif',
  'game_preview.png',
  'header_preview.png',
  'sidebar_preview.gif',
  'news_panel.png',
  'raindrops.frag',
  'winter.frag',
  'shimmer_effect.frag'
)

function Try-DownloadRaw([string]$repoPath, [string]$dest) {
  if (Test-Path $dest) {
    Write-Host "[SYNC] Cache vorhanden: $([IO.Path]::GetFileName($dest))"
    return $true
  }
  try {
    Write-Host "[SYNC] $repoPath"
    Invoke-WebRequest -Uri ($rawBase + $repoPath) -Headers $headers -OutFile $dest -UseBasicParsing -TimeoutSec 20
    return (Test-Path $dest)
  } catch {
    Write-Warning "Repo-Datei konnte nicht geladen werden: $repoPath"
    return $false
  }
}

$ok = $true
foreach ($f in $core) {
  $dst = Join-Path $assets ([IO.Path]::GetFileName($f))
  if (-not (Try-DownloadRaw $f $dst)) {
    # Background.gif and shader files are optional because the app has fallbacks.
    if ($f -notin @('Background.gif','raindrops.frag','winter.frag','shimmer_effect.frag')) {
      $ok = $false
    }
  }
}

# Keep already downloaded preview GIFs. We no longer need the GitHub tree API to discover them.
$previewGifs = Get-ChildItem -Path $assets -Filter 'game_preview*.gif' -File -ErrorAction SilentlyContinue |
  Sort-Object Name |
  Select-Object -ExpandProperty Name

$commitFile = Join-Path $assets 'build_commit.txt'
if (-not (Test-Path $commitFile)) {
  'local-cache' | Set-Content -NoNewline -Encoding ascii $commitFile
}

Remove-Item (Join-Path $assets 'topbar.png') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $assets 'tabs_subtitle.png') -Force -ErrorAction SilentlyContinue

if (-not $ok) {
  Write-Warning '[SYNC] Nicht alle optionalen Remote-Assets konnten geladen werden.'
  Write-Warning '[SYNC] Bereits vorhandene lokale Assets werden verwendet.'
}

Write-Host '[SYNC] Asset-Synchronisierung abgeschlossen (rate-limit-sicher, local-first).'
Write-Host ("[SYNC] Cached Game preview GIFs: " + ($previewGifs -join ', '))
exit 0
