@echo off
setlocal EnableExtensions
title JujiTABS - Full Build

cd /d "%~dp0"

echo ==========================================
echo         JUJITABS FULL WINDOWS BUILD
echo ==========================================
echo.

where dotnet >nul 2>&1
if errorlevel 1 (
    echo [FEHLER] dotnet.exe wurde nicht gefunden.
    pause
    exit /b 1
)

echo [1/7] Clean...
if exist "obj" rmdir /s /q "obj"
if exist "bin" rmdir /s /q "bin"
if exist "release" rmdir /s /q "release"

echo.
echo [1.5/7] Repository-Grafiken synchronisieren...
powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\sync-repo-assets.ps1"
if errorlevel 1 goto FAIL

echo.
echo [2/7] Plugin Restore...
dotnet restore "JujiTABS.csproj"
if errorlevel 1 goto FAIL

echo.
echo [3/7] Plugin Build...
dotnet build "JujiTABS.csproj" -c Release --no-restore
if errorlevel 1 goto FAIL

if not exist "bin\JujiTABS.dll" (
    echo [FEHLER] bin\JujiTABS.dll wurde nicht erzeugt.
    goto FAIL
)

echo.
echo [4/7] Launcher Restore...
dotnet restore "JujiTABSLauncher.csproj"
if errorlevel 1 goto FAIL

echo.
echo [5/7] Launcher Build...
dotnet build "JujiTABSLauncher.csproj" -c Release --no-restore
if errorlevel 1 goto FAIL

echo.
echo [6/7] SINGLE-FILE EXE...
dotnet publish "JujiTABSLauncher.csproj" ^
  -c Release ^
  -r win-x64 ^
  --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true ^
  -p:DebugType=None ^
  -p:DebugSymbols=false ^
  -o "release"

if errorlevel 1 goto FAIL

if not exist "release\JujiTABS.exe" (
    echo [FEHLER] release\JujiTABS.exe fehlt.
    goto FAIL
)

echo.
echo ==========================================
echo BUILD ERFOLGREICH
echo ==========================================
echo.
echo %CD%\release\JujiTABS.exe
echo.
start "" explorer.exe "%CD%\release"
pause
exit /b 0

:FAIL
echo.
echo ==========================================
echo BUILD FEHLER
echo ==========================================
echo.
pause
exit /b 2
